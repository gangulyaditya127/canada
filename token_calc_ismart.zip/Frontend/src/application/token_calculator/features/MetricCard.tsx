import { Card, CardContent } from "@/components/ui/card";
import { ReactNode } from "react";
import { cn } from "@/lib/utils";

type MetricCardProps = {
    title: string;
    value: string | number;
    icon: ReactNode;
    subtitle?: string;
    className?: string;
    valueClassName?: string;
};

export function MetricCard({
    title,
    value,
    icon,
    subtitle,
    className,
    valueClassName,
}: MetricCardProps) {
    return (
        <Card
            className={cn(
                "border-border  rounded-lg",
                className
            )}
        >
            <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                        {title}
                    </span>

                    {icon}
                </div>

                <div
                    className={cn(
                        "mt-2 text-3xl font-bold",
                        valueClassName
                    )}
                >
                    {value}
                </div>

                {subtitle && (
                    <p className="mt-2 text-sm opacity-80">
                        {subtitle}
                    </p>
                )}
            </CardContent>
        </Card>
    );
}