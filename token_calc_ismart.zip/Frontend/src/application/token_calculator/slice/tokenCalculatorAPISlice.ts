import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export type Service = {
    id: number;
    app_id: number;
    name: string;
    input_words: number;
    output_words: number;
    ratio: number;
};

export type Application = {
    id: number;
    name: string;
    description: string | null;
    services: Service[];
};

export type ModelPricing = {
    id: number;
    model_name: string;
    input_price: number;
    output_price: number;
};

type ApiPricing = {
    id: number;
    model: string;
    input_price: number;
    output_price: number;
};

export const tokenCalculatorAPISlice = createApi({
    reducerPath: 'tokenCalculatorAPISlice',
    baseQuery: fetchBaseQuery({
        baseUrl: `${import.meta.env.VITE_API_PYTHON_BASE_URL}/token_calc`,
    }),
    tagTypes: ['Applications', 'Services', 'Pricing'],
    endpoints: (builder) => ({
        // Applications
        getApplications: builder.query<Application[], void>({
            query: () => ({
                url: 'applications',
                method: 'GET',
            }),
            transformResponse: (response: {
                success: boolean;
                applications: Application[];
            }) => response.applications,
            providesTags: ['Applications'],
        }),

        createApplication: builder.mutation<
            Application,
            { name: string; description: string }
        >({
            query: (body) => ({
                url: 'applications',
                method: 'POST',
                body,
            }),
            transformResponse: (response: {
                success: boolean;
                application: Application;
            }) => response.application,
            invalidatesTags: ['Applications'],
        }),

        deleteApplication: builder.mutation<void, number>({
            query: (id) => ({
                url: `applications/${id}`,
                method: 'DELETE',
            }),
            invalidatesTags: ['Applications'],
        }),

        // Services
        createService: builder.mutation<
            Service,
            {
                app_id: number;
                name: string;
                input_words: number;
                output_words: number;
            }
        >({
            query: ({ app_id, ...body }) => ({
                url: `applications/${app_id}/services`,
                method: 'POST',
                body,
            }),
            transformResponse: (response: {
                success: boolean;
                service: Service;
            }) => response.service,
            invalidatesTags: ['Services', 'Applications'],
        }),

        updateService: builder.mutation<
            Service,
            {
                id: number;
                name: string;
                input_words: number;
                output_words: number;
            }
        >({
            query: ({ id, ...body }) => ({
                url: `services/${id}`,
                method: 'PUT',
                body,
            }),
            transformResponse: (response: {
                success: boolean;
                service: Service;
            }) => response.service,
            invalidatesTags: ['Services', 'Applications'],
        }),

        deleteService: builder.mutation<void, number>({
            query: (id) => ({
                url: `services/${id}`,
                method: 'DELETE',
            }),
            invalidatesTags: ['Services', 'Applications'],
        }),

        // Pricing
        getPricing: builder.query<ModelPricing[], void>({
            query: () => ({
                url: 'pricing',
                method: 'GET',
            }),
            transformResponse: (response: {
                success: boolean;
                pricing: ApiPricing[];
            }) =>
                response.pricing
                    .map((p) => ({
                        id: p.id,
                        model_name: p.model,
                        input_price: p.input_price,
                        output_price: p.output_price,
                    }))
                    .sort((a, b) =>
                        a.model_name.localeCompare(b.model_name)
                    ),
            providesTags: ['Pricing'],
        }),

        createPricing: builder.mutation<
            ModelPricing,
            {
                model_name: string;
                input_price: number;
                output_price: number;
            }
        >({
            query: (body) => ({
                url: 'pricing',
                method: 'POST',
                body: {
                    model: body.model_name,
                    input_price: body.input_price,
                    output_price: body.output_price,
                },
            }),
            transformResponse: (response: {
                success: boolean;
                model: ApiPricing;
            }) => ({
                id: response.model.id,
                model_name: response.model.model,
                input_price: response.model.input_price,
                output_price: response.model.output_price,
            }),
            invalidatesTags: ['Pricing'],
        }),

        updatePricing: builder.mutation<
            ModelPricing,
            {
                id: number;
                model_name: string;
                input_price: number;
                output_price: number;
            }
        >({
            query: ({ id, ...body }) => ({
                url: `pricing/${id}`,
                method: 'PUT',
                body: {
                    model: body.model_name,
                    input_price: body.input_price,
                    output_price: body.output_price,
                },
            }),
            transformResponse: (response: {
                success: boolean;
                model: ApiPricing;
            }) => ({
                id: response.model.id,
                model_name: response.model.model,
                input_price: response.model.input_price,
                output_price: response.model.output_price,
            }),
            invalidatesTags: ['Pricing'],
        }),

        deletePricing: builder.mutation<void, number>({
            query: (id) => ({
                url: `pricing/${id}`,
                method: 'DELETE',
            }),
            invalidatesTags: ['Pricing'],
        }),
        syncPricing: builder.mutation<{ success: boolean; updated: number }, void>({
            query: () => ({
                url: 'pricing/sync',
                method: 'POST',
            }),
            invalidatesTags: ['Pricing'],
        }),
        bulkPricing: builder.mutation<{ success: boolean; added: number; updated: number }, { models: { model_name: string; input_price: number; output_price: number }[] }>({
            query: (body) => ({
                url: 'pricing/bulk',
                method: 'POST',
                body,
            }),
            invalidatesTags: ['Pricing'],
        }),
        getLitellmModels: builder.query<{ success: boolean; categories: Record<string, ModelPricing[]> }, void>({
            query: () => ({
                url: 'litellm_models',
                method: 'GET',
            }),
        }),
    }),
});

export const {
    // Applications
    useGetApplicationsQuery,
    useCreateApplicationMutation,
    useDeleteApplicationMutation,

    // Services
    useCreateServiceMutation,
    useUpdateServiceMutation,
    useDeleteServiceMutation,

    // Pricing
    useGetPricingQuery,
    useCreatePricingMutation,
    useUpdatePricingMutation,
    useDeletePricingMutation,
    useSyncPricingMutation,
    useBulkPricingMutation,
    useGetLitellmModelsQuery,
} = tokenCalculatorAPISlice;

export const TOKEN_WORD_RATIO = 1.5;