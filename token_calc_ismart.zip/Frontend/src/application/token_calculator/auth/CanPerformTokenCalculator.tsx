import { useAppSelector } from "@/lib/redux/hooks";
import { Navigate, Outlet, useLocation } from "react-router-dom";

const CanPerformTokenCalculatorRouteGuard = ({ unauthorizedRoute }: { unauthorizedRoute: string }) => {
    const userDetails = useAppSelector((state) => state.keyClockAuthSlice.user);
    const location = useLocation();
    const canExecute = userDetails?.["ARE_TOKEN_CALCULATOR"]?.includes("edit") || userDetails?.["ARE_TOKEN_CALCULATOR"]?.includes("execute")
    if (!userDetails) return <Navigate to={`/login?_r=${location.pathname}`} replace={true} />
    return canExecute ? (
        <Outlet />
    ) : (
        <Navigate to={`/${unauthorizedRoute}`} replace={true} />
    );
    // return <Outlet />;
};

export default CanPerformTokenCalculatorRouteGuard;
