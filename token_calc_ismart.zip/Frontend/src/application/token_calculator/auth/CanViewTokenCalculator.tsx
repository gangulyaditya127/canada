import { useUserinfoQuery } from "@/auth/slice/keyClockAPISlice";
import ErrorAuthentication from "@/components/ui/ErrorAuthentication";
import LoadingAuthentication from "@/components/ui/LoadingAuthentication";
import { useAppSelector } from "@/lib/redux/hooks";
import { Navigate, Outlet, useLocation } from "react-router-dom";

const CanViewTokenCalculator = ({ unauthorizedRoute }: { unauthorizedRoute: string }) => {
    const {
        isLoading,
        isError,
        data
    } = useUserinfoQuery()
    const token = useAppSelector((state) => state.keyClockAuthSlice.accessToken)
    const location = useLocation();
    const canView = data?.["ARE_TOKEN_CALCULATOR"]?.includes("view")
    if (!token) return <Navigate to={`/login?_r=${location.pathname}`} replace={true} />
    if (isLoading) return <LoadingAuthentication />
    if (isError) return <ErrorAuthentication />
    return canView ? (
        <Outlet />
    ) : (
        <Navigate to={`/${unauthorizedRoute}`} replace={true} />
    );
    // return <Outlet />;
};

export default CanViewTokenCalculator;