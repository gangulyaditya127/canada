import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { Outlet } from "react-router-dom";
import SIDEBAR_DATA from "./data/sidebar.data";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { TOP_NAV_LIST } from "./data/topnav.data";
import { useAppSelector } from "@/lib/redux/hooks";

export default function TokenCalculatorLayout() {
    const dispatch = useDispatch();

    const userDetails = useAppSelector(
        (state) => state.keyClockAuthSlice.user
    );

    const canExecute =
        userDetails?.["ARE_TOKEN_CALCULATOR"]?.includes("edit") ||
        userDetails?.["ARE_TOKEN_CALCULATOR"]?.includes("execute");
    // const canExecute = true; // Forced to true to show Developer tab

    useEffect(() => {
        dispatch(
            updateTopNavigation({
                navList: TOP_NAV_LIST,
                isHome: false,
                isAMS: false,
            })
        );

        const sidebarData = {
            ...SIDEBAR_DATA,
            sideBarNavList: SIDEBAR_DATA.sideBarNavList.map((group) => ({
                ...group,
                groupList: group.groupList.filter(
                    (item) =>
                        item.content !== "Developer" || canExecute
                ),
            })),
        };

        dispatch(updateSideBarNavigation(sidebarData));
    }, [dispatch, canExecute]);

    return <Outlet />;
}