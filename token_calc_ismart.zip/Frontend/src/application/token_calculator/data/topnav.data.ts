import { TopNavItem } from "@/components/layout/slice/topbar-navigation";

export const TOP_NAV_LIST: TopNavItem[] = [
    {
        content: "Token Estimator",
        route: "/",
        key: "1",
    },
];
