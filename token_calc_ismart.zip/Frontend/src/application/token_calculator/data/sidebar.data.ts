import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";

const SIDEBAR_DATA: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "group-1",
      groupList: [
        {
          key: "1",
          content: "Calculator",
          icon: "calculator",
          route: "/",
        },
        {
          key: "2",
          content: "Pricing",
          icon: "dollar-sign",
          route: "/pricing",
        },
        {
          key: "3",
          content: "Developer",
          icon: "wrench",
          route: "/developer",
        },
        {
          key: "4",
          content: "Model Selection",
          icon: "database",
          route: "/model-selection",
        },
      ],
    },
  ],
  bottomNavList: [
  ],
};

export default SIDEBAR_DATA;
