import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";
import Container from "@/components/ui/container";
import { updateSideBarNavigation } from "@/components/layout/slice/sidebar-navigation";
import { updateTopNavigation } from "@/components/layout/slice/topbar-navigation";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";

export default function TokenUnauthorized() {
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(updateSideBarNavigation([]));
        dispatch(
            updateTopNavigation({ navList: [], isIsmartHome: true, isAMS: false, className: '' }),
        );
    }, []);
    return (
        <Container className="h-[90vh] grid place-items-center">
            <div className="mt-12 text-center space-y-2 max-w-[500px] flex flex-col items-center">
                <NavigateBackButton />
                <p className="font-medium text-3xl">Oops! You are unauthorized</p>
                <p className="text-muted-foreground text-sm">It seems you are not authorized to access this module. Please contact sebl-ismart@tcscomprod.onmicrosoft.com for more details</p>
            </div>
        </Container>
    )
}