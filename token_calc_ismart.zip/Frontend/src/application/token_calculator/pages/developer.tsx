// import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
// import {
//   createApplication,
//   createService,
//   deleteApplication,
//   deleteService,
//   fetchApplications,
//   updateService,
//   type Application,
//   type Service,
// } from "../lib/api";
import {
  useGetApplicationsQuery,
  useCreateApplicationMutation,
  useDeleteApplicationMutation,
  useCreateServiceMutation,
  useUpdateServiceMutation,
  useDeleteServiceMutation,
  Application,
  Service,
} from "../slice/tokenCalculatorAPISlice";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Pencil, Plus, Trash2, X } from "lucide-react";
import { cn } from "@/lib/utils";
// import { AppShell } from "../features/AppShell";
import Container from "@/components/ui/container";
import { ConfirmDialog } from "../features/ConfirmDialog";
import { Badge } from "@/components/ui/badge";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { FolderOpen, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import ErrorContainer from "@/components/ui/error-container";
import { Skeleton } from "@/components/ui/skeleton";

type ServiceForm = {
  id: number | null;
  name: string;
  input_words: string;
  output_words: string;
};
const emptyService: ServiceForm = { id: null, name: "", input_words: "", output_words: "" };

export default function DeveloperPage() {
  // const qc = useQueryClient();
  const {
    data: applications,
    isFetching: applicationsLoading,
    isError: applicationsError,
  } = useGetApplicationsQuery();

  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [appForm, setAppForm] = useState({ name: "", description: "" });
  const [svcForm, setSvcForm] = useState<ServiceForm>(emptyService);
  const { toast } = useToast()
  // const invalidate = () => qc.invalidateQueries({ queryKey: ["applications"] });
  const selected: Application | undefined =
    applications?.find((a) => a.id === selectedId);

  const [createApplication, { isLoading: creatingApplication }] =
    useCreateApplicationMutation();

  const handleCreateApplication = async () => {
    try {
      const app = await createApplication({
        name: appForm.name,
        description: appForm.description,
      }).unwrap();

      toast({
        title: "Application Created",
      });

      setAppForm({
        name: "",
        description: "",
      });

      setSelectedId(app.id);
    } catch (error: any) {
      toast({
        title: "Failed to create application",
        variant: "destructive"
      });
    }
  };

  const [deleteApplication] =
    useDeleteApplicationMutation();


  const [createService, { isLoading: creatingService }] =
    useCreateServiceMutation();

  const [updateService, { isLoading: updatingService }] =
    useUpdateServiceMutation();


  const handleSaveService = async () => {
    if (!selected) {
      toast({
        title: "Select Application First",
        variant: "destructive"
      });
      return;
    }

    try {
      const payload = {
        name: svcForm.name.trim(),
        input_words: Number(svcForm.input_words),
        output_words: Number(svcForm.output_words),
      };

      if (svcForm.id) {
        await updateService({
          id: svcForm.id,
          ...payload,
        }).unwrap();

        toast({
          title: "Service Updated",
        });
      } else {
        await createService({
          app_id: selected.id,
          ...payload,
        }).unwrap();

        toast({
          title: "Service Added",
        });
      }

      setSvcForm(emptyService);
    } catch (error: any) {
      toast({
        title: "Failed to save service",
        variant: "destructive"
      });
    }
  };

  const [deleteService] =
    useDeleteServiceMutation();

  const editService = (s: Service) =>
    setSvcForm({
      id: s.id,
      name: s.name,
      input_words: String(s.input_words),
      output_words: String(s.output_words),
    });

  const ratioPreview =
    svcForm.input_words && svcForm.output_words && Number(svcForm.input_words) > 0
      ? (Number(svcForm.output_words) / Number(svcForm.input_words)).toFixed(4)
      : null;

  return (
    <Container className="space-y-6 my-6">
      <header className="space-y-2 ml-6">
        <h1 className="text-3xl font-semibold tracking-tight" >
          Applications & Services
        </h1 >

        <p className="text-sm text-muted-foreground max-w-2xl">
          Manage applications and their services used to estimate token
          consumption and costs.
        </p>
      </header >

      <div className="flex flex-col">
        <div className="grid gap-8 lg:grid-cols-[420px_1fr]">
          <Card className="border-none">
            <CardHeader className="">
              <CardTitle>New Application</CardTitle>

              <CardDescription>
                Create a new application and add services to it.
              </CardDescription>
            </CardHeader>

            <CardContent className="">
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  handleCreateApplication();
                }}
              >
                <div className="space-y-2">
                  <Label>Name</Label>

                  <Input
                    required
                    value={appForm.name}
                    onChange={(e) =>
                      setAppForm({
                        ...appForm,
                        name: e.target.value,
                      })
                    }
                    placeholder="Customer Support Bot"
                  />
                </div>

                <div className="space-y-4">
                  <Label>Description</Label>
                  <Textarea
                    rows={9}
                    value={appForm.description}
                    onChange={(e) =>
                      setAppForm({
                        ...appForm,
                        description: e.target.value,
                      })
                    }
                    placeholder="What this app does..."
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={creatingApplication}
                >
                  {creatingApplication ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" />
                      Create Application
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
          {
            applicationsLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 6 }).map((_, index) => (
                  <Skeleton
                    key={index}
                    className="h-[72px] w-full rounded-lg"
                  />
                ))}
              </div>
            ) : applicationsError ? (
              <ErrorContainer />
            ) : (
              <Card className="border-border">
                <CardHeader className="">
                  <div className="flex items-center justify-between">
                    <CardTitle>
                      Existing Applications
                    </CardTitle>

                    <Badge variant="outline">
                      {applications?.length ?? 0}
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="">
                  {applications?.length ? (
                    <ScrollArea className="h-[400px] pr-4">
                      <div className="space-y-2">
                        {applications.map((a: any) => (
                          <button
                            key={a.id}
                            onClick={() => {
                              setSelectedId(a.id);
                              setSvcForm(emptyService);
                            }}
                            className={cn(
                              "w-full rounded-lg p-4 text-left transition-all",
                              selectedId === a.id
                                ? "bg-primary/5"
                                : "hover:bg-muted"
                            )}
                          >
                            <div className="flex items-center justify-between">
                              <h4 className="text-sm font-medium">
                                {a.name}
                              </h4>

                              <Badge variant="secondary">
                                {a.services.length}
                              </Badge>
                            </div>

                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                              {a.description || "No description"}
                            </p>
                          </button>
                        ))}
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-10">
                      <FolderOpen className="h-10 w-10 text-muted-foreground mb-3" />

                      <p className="font-medium">
                        No Applications
                      </p>

                      <p className="text-sm text-muted-foreground">
                        Create your first application.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          }

        </div>

        {selected ? (
          <div className=" min-w-0">
            <Card className="border-none">
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-2xl">
                        {selected.name}
                      </CardTitle>

                      <Badge variant="outline">
                        ID {selected.id}
                      </Badge>
                    </div>

                    <CardDescription className="mt-2">
                      {selected.description ||
                        "No description provided."}
                    </CardDescription>
                  </div>

                  <ConfirmDialog
                    title="Delete Application"
                    description={`This will permanently delete "${selected.name}" and all its services.`}
                    successMessage={`${selected.name} deleted successfully`}
                    onConfirm={async () => {
                      await deleteApplication(selected.id).unwrap();
                      setSelectedId(null);
                    }}
                    trigger={
                      <Button variant="destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete App
                      </Button>
                    }
                  />
                </div>
              </CardHeader>
            </Card>
            <div className="grid gap-8 lg:grid-cols-[420px_1fr]">
              <Card className="border-none">
                <CardHeader>
                  <CardTitle>
                    {svcForm.id
                      ? "Edit Service"
                      : "Add Service"}
                  </CardTitle>

                  <CardDescription>
                    Configure average input and output word counts.
                  </CardDescription>
                </CardHeader>

                <CardContent>
                  <form
                    className="space-y-4"
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleSaveService();
                    }}
                  >
                    <div className="space-y-2">
                      <Label>Service Name</Label>

                      <Input
                        required
                        value={svcForm.name}
                        onChange={(e) =>
                          setSvcForm({
                            ...svcForm,
                            name: e.target.value,
                          })
                        }
                        placeholder="Summarize ticket"
                      />
                    </div>

                    <div className="flex flex-col gap-4">
                      <div className="space-y-2">
                        <Label>
                          Avg. Input Word Count
                        </Label>

                        <Input
                          required
                          type="number"
                          min={0}
                          value={svcForm.input_words}
                          onChange={(e) =>
                            setSvcForm({
                              ...svcForm,
                              input_words: e.target.value,
                            })
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>
                          Avg. Output Word Count
                        </Label>

                        <Input
                          required
                          type="number"
                          min={0}
                          value={svcForm.output_words}
                          onChange={(e) =>
                            setSvcForm({
                              ...svcForm,
                              output_words: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>

                    {ratioPreview && (
                      <Card className="bg-primary/5 border-none">
                        <CardContent className="pt-4">
                          <p className="text-sm text-muted-foreground">
                            Output / Input Ratio
                          </p>

                          <p className="text-2xl font-bold text-primary">
                            {ratioPreview}
                          </p>
                        </CardContent>
                      </Card>
                    )}

                    <div className="flex gap-2">
                      <Button
                        type="submit"
                        disabled={
                          creatingService ||
                          updatingService
                        }
                      >
                        {creatingService ||
                          updatingService ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : svcForm.id ? (
                          "Update Service"
                        ) : (
                          "Add Service"
                        )}
                      </Button>

                      {svcForm.id && (
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() =>
                            setSvcForm(emptyService)
                          }
                        >
                          <X className="mr-2 h-4 w-4" />
                          Cancel
                        </Button>
                      )}
                    </div>
                  </form>
                </CardContent>
              </Card>

              <Card className="border-none">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>
                        Services
                      </CardTitle>

                      <CardDescription>
                        Configured services for this application.
                      </CardDescription>
                    </div>

                    <Badge variant="outline">
                      {selected.services.length}
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent>
                  {selected.services.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Service</TableHead>

                          <TableHead className="text-right">
                            Input
                          </TableHead>

                          <TableHead className="text-right">
                            Output
                          </TableHead>

                          <TableHead className="text-right">
                            Ratio
                          </TableHead>

                          <TableHead className="w-[120px]">
                            Actions
                          </TableHead>
                        </TableRow>
                      </TableHeader>

                      <TableBody>
                        {selected.services.map((s) => (
                          <TableRow key={s.id}>
                            <TableCell>
                              <Badge variant="secondary">
                                {s.name}
                              </Badge>
                            </TableCell>

                            <TableCell className="text-right font-mono">
                              {s.input_words}
                            </TableCell>

                            <TableCell className="text-right font-mono">
                              {s.output_words}
                            </TableCell>

                            <TableCell className="text-right">
                              <Badge>
                                {s.ratio.toFixed(4)}
                              </Badge>
                            </TableCell>

                            <TableCell>
                              <div className="flex justify-end gap-2">
                                <Button
                                  size="icon"
                                  variant="outline"
                                  onClick={() =>
                                    editService(s)
                                  }
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>

                                <ConfirmDialog
                                  title="Delete Service"
                                  description={`This will permanently delete the service "${s.name}".`}
                                  successMessage={`${s.name} deleted successfully`}
                                  onConfirm={async () => {
                                    await deleteService(s.id).unwrap();
                                  }}
                                  trigger={
                                    <Button
                                      size="icon"
                                      variant="destructive"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  }
                                />
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-16">
                      <FolderOpen className="h-10 w-10 text-muted-foreground mb-3" />

                      <p className="font-medium">
                        No Services Configured
                      </p>

                      <p className="text-sm text-muted-foreground">
                        Add a service to this application.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

          </div>
        ) : (
          <Card className="mt-4">
            <CardContent className="flex flex-col items-center justify-center py-20">
              <FolderOpen className="h-12 w-12 text-muted-foreground mb-4" />

              <h3 className="font-semibold">
                No Application Selected
              </h3>

              <p className="text-sm text-muted-foreground mt-2">
                Select an application from the right panel to manage services.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </Container >
  );
}
