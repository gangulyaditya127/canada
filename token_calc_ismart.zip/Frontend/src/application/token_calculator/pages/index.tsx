// import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
// import { AppShell } from "../features/AppShell";
// import {
//   // fetchApplications,
//   // fetchPricing,
//   // TOKEN_WORD_RATIO,
//   type Application,
//   type ModelPricing,
// } from "../lib/api";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Coins, Zap, Wallet, Download, Loader2 } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import Container from "@/components/ui/container";
// import { MetricCard } from "../features/MetricCard";


import {
  useGetApplicationsQuery,
  useGetPricingQuery,
  TOKEN_WORD_RATIO,
  Application,
  ModelPricing,
} from "../slice/tokenCalculatorAPISlice";

import ErrorContainer from "@/components/ui/error-container";
import { Skeleton } from "@/components/ui/skeleton";


import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { Badge } from "@/components/ui/badge";


import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/seperator";
import { useToast } from "@/components/ui/use-toast";
import { MetricCard } from "../features/MetricCard";


export default function CalculatorPage() {
  // const apps = useQuery({ queryKey: ["applications"], queryFn: fetchApplications });
  // const pricing = useQuery({ queryKey: ["pricing"], queryFn: fetchPricing });


  const {
    data: applications,
    isFetching: applicationsLoading,
    isError: applicationsError,
  } = useGetApplicationsQuery();

  const {
    data: pricing,
    isFetching: pricingLoading,
    isError: pricingError,
  } = useGetPricingQuery();

  const [selectedAppId, setSelectedAppId] = useState<string>("");
  const [selectedModel, setSelectedModel] = useState<string>("");
  const [numRequests, setNumRequests] = useState<number>(100);
  const [serviceInputs, setServiceInputs] = useState<Record<number, string>>({});
  const [serviceOutputs, setServiceOutputs] = useState<Record<number, string>>({});
  const [showAllModels, setShowAllModels] = useState<boolean>(false);

  const [isDownloading, setIsDownloading] = useState(false);

  const { toast } = useToast();


  useEffect(() => {
    if (pricing && pricing.length > 0 && !selectedModel) {
      setSelectedModel(pricing[0].model_name);
    }
  }, [pricing, selectedModel]);

  const selectedApp: Application | undefined = useMemo(
    () => applications?.find((a) => a.id === Number(selectedAppId)),
    [applications, selectedAppId],
  );

  useEffect(() => {
    if (selectedApp) {
      const inputs: Record<number, string> = {};

      selectedApp.services.forEach((s) => {
        inputs[s.id] = String(s.input_words);
      });

      setServiceInputs(inputs);
    } else {
      setServiceInputs({});
      setServiceOutputs({});
    }
  }, [selectedApp]);

  useEffect(() => {
    if (selectedApp) {
      const outputs: Record<number, string> = {};

      selectedApp.services.forEach((s) => {
        const input = Number(serviceInputs[s.id]) || 0;
        outputs[s.id] = String(input * s.ratio);
      });

      setServiceOutputs(outputs);
    }
  }, [serviceInputs, selectedApp]);


  const modelData: ModelPricing | undefined = pricing?.find(
    (m) => m.model_name === selectedModel,
  );

  const rows =
    selectedApp?.services.map((s) => {
      const inputWords = Number(serviceInputs[s.id]) || 0;
      const outputWords = Number(serviceOutputs[s.id]) || 0;
      const inputTokens = inputWords * TOKEN_WORD_RATIO;
      const outputTokens = outputWords * TOKEN_WORD_RATIO;
      return { ...s, inputWords, outputWords, inputTokens, outputTokens };
    }) ?? [];

  const totals = rows.reduce(
    (acc, r) => {
      acc.inputTokens += r.inputTokens;
      acc.outputTokens += r.outputTokens;
      return acc;
    },
    { inputTokens: 0, outputTokens: 0 },
  );

  const totalInputTokens = totals.inputTokens * numRequests;
  const totalOutputTokens = totals.outputTokens * numRequests;
  const inputCost = modelData ? totalInputTokens * modelData.input_price : 0;
  const outputCost = modelData ? totalOutputTokens * modelData.output_price : 0;
  const totalCost = inputCost + outputCost;

  const modelBreakdown = (pricing ?? []).map((m) => {
    const ic = totalInputTokens * m.input_price;
    const oc = totalOutputTokens * m.output_price;
    return {
      id: m.id,
      model_name: m.model_name,
      input_price: m.input_price,
      output_price: m.output_price,
      inputCost: ic,
      outputCost: oc,
      totalCost: ic + oc,
    };
  }).sort((a, b) => a.totalCost - b.totalCost);


  const downloadReport = async () => {
    if (!selectedApp) return;

    try {
      setIsDownloading(true);

      const esc = (v: string | number) => {
        const s = String(v);
        return /[",\n]/.test(s)
          ? `"${s.replace(/"/g, '""')}"`
          : s;
      };

      const lines: string[] = [];

      lines.push("Token & Cost Estimation Report");
      lines.push(`Application,${esc(selectedApp.name)}`);
      lines.push(`Number of requests,${numRequests}`);
      lines.push(`Token-to-word ratio,${TOKEN_WORD_RATIO}`);
      lines.push("");

      lines.push("Service breakdown (per request)");
      lines.push(
        "Service,Input words,Output words,Input tokens,Output tokens"
      );

      rows.forEach((r) =>
        lines.push(
          [
            r.name,
            r.inputWords,
            r.outputWords.toFixed(0),
            Math.round(r.inputTokens),
            Math.round(r.outputTokens),
          ]
            .map(esc)
            .join(",")
        )
      );

      lines.push("");
      lines.push(
        `Total input tokens (x${numRequests}),${Math.round(
          totalInputTokens
        )}`
      );
      lines.push(
        `Total output tokens (x${numRequests}),${Math.round(
          totalOutputTokens
        )}`
      );

      lines.push("");

      lines.push("Model-wise estimated cost");

      lines.push(
        "Model,Input $/token,Output $/token,Input cost,Output cost,Total cost"
      );

      modelBreakdown.forEach((m) =>
        lines.push(
          [
            m.model_name,
            m.input_price,
            m.output_price,
            m.inputCost.toFixed(6),
            m.outputCost.toFixed(6),
            m.totalCost.toFixed(6),
          ]
            .map(esc)
            .join(",")
        )
      );

      const blob = new Blob(
        [lines.join("\n")],
        {
          type: "text/csv;charset=utf-8",
        }
      );

      const url = URL.createObjectURL(blob);

      const fileName = `cost-report-${selectedApp.name.replace(
        /\s+/g,
        "_"
      )}-${Date.now()}.csv`;

      const a = document.createElement("a");
      a.href = url;
      a.download = fileName;
      a.click();

      URL.revokeObjectURL(url);

      toast({
        title: "Download Successful",
        description: `${fileName} has been downloaded.`,
        variant: "default"
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Download Failed",
        description:
          error instanceof Error
            ? error.message
            : "Something went wrong while generating the report.",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  if (applicationsLoading || pricingLoading) {
    return (
      <Container className="my-6 mb-12">
        <div className="space-y-6">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-[450px] w-full" />
        </div>
      </Container>
    );
  }

  if (applicationsError || pricingError) {
    return (
      <Container className="my-6 mb-12">
        <ErrorContainer />
      </Container>
    );
  }


  return (
    <Container className="my-6 mb-12">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
            Estimate LLM Token Usage & Cost
          </h1>

          <p className="text-muted-foreground mt-2 max-w-2xl">
            Pick an application, choose a model, and tweak input/output volumes
            to instantly estimate token consumption and overall spend.
          </p>
        </div>

        <Card className="border-border rounded-xl">
          <CardHeader>
            <CardTitle>Configuration</CardTitle>
            <CardDescription>
              Select application, model and request volume.
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="grid gap-5 md:grid-cols-3">
              <div className="space-y-2">
                <Label>Application</Label>

                <Select
                  value={selectedAppId}
                  onValueChange={setSelectedAppId}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select application" />
                  </SelectTrigger>

                  <SelectContent>
                    {applications?.map((a) => (
                      <SelectItem
                        key={a.id}
                        value={String(a.id)}
                      >
                        {a.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Model</Label>

                <Select
                  value={selectedModel}
                  onValueChange={setSelectedModel}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select model" />
                  </SelectTrigger>

                  <SelectContent>
                    {pricing?.map((m) => (
                      <SelectItem
                        key={m.id}
                        value={m.model_name}
                      >
                        {m.model_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Number of Requests</Label>

                <Input
                  type="number"
                  min={1}
                  value={numRequests}
                  onChange={(e) =>
                    setNumRequests(Number(e.target.value) || 100)
                  }
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {selectedApp ? (
          <>
            <Card>
              <CardHeader>
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <CardTitle>{selectedApp.name}</CardTitle>

                      <Badge variant="secondary">
                        {selectedModel}
                      </Badge>
                    </div>

                    <CardDescription>
                      {selectedApp.services.length} service(s)
                    </CardDescription>
                  </div>

                  <Badge variant="outline">
                    1 word ≈ {TOKEN_WORD_RATIO} tokens
                  </Badge>
                </div>
              </CardHeader>

              <CardContent>
                {rows.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16">
                    <p className="font-medium">
                      No services configured
                    </p>

                    <p className="text-muted-foreground text-sm">
                      This application does not have any services yet.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="grid gap-4 md:grid-cols-3 mb-8">

                      <MetricCard
                        title="Input Tokens"
                        value={Math.round(totalInputTokens).toLocaleString()}
                        icon={<Zap className="h-4 w-4 text-primary" />}
                      />

                      <MetricCard
                        title="Output Tokens"
                        value={Math.round(totalOutputTokens).toLocaleString()}
                        icon={<Coins className="h-4 w-4 text-primary" />}
                      />

                      <MetricCard
                        title="Estimated Cost"
                        value={`$${totalCost.toFixed(4)}`}
                        subtitle={`${numRequests.toLocaleString()} request(s)`}
                        icon={<Wallet className="h-5 w-5 text-white" />}
                        className="overflow-hidden border-0 bg-gradient-to-br from-blue-600 via-indigo-600 to-violet-700 text-white shadow-xl"
                        valueClassName="text-4xl tracking-tight"
                      />

                    </div>

                    <Separator className="mb-6" />

                    <div className="space-y-4">
                      <div>
                        <h3 className="font-semibold">
                          Service Breakdown
                        </h3>

                        <p className="text-sm text-muted-foreground">
                          Token estimation by service.
                        </p>
                      </div>

                      <ScrollArea className="w-full">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Service</TableHead>
                              <TableHead>Input Words</TableHead>
                              <TableHead>Output Words</TableHead>
                              <TableHead className="text-right">
                                Input Tokens
                              </TableHead>
                              <TableHead className="text-right">
                                Output Tokens
                              </TableHead>
                            </TableRow>
                          </TableHeader>

                          <TableBody>
                            {rows.map((r) => (
                              <TableRow key={r.id}>
                                <TableCell className="font-medium">
                                  {r.name}
                                </TableCell>

                                <TableCell>
                                  <Input
                                    type="number"
                                    min={0}
                                    value={serviceInputs[r.id] ?? ""}
                                    onChange={(e) =>
                                      setServiceInputs((prev) => ({
                                        ...prev,
                                        [r.id]: e.target.value,
                                      }))
                                    }
                                  />
                                </TableCell>

                                <TableCell>
                                  <Input
                                    type="number"
                                    min={0}
                                    value={serviceOutputs[r.id] ?? ""}
                                    onChange={(e) =>
                                      setServiceOutputs((prev) => ({
                                        ...prev,
                                        [r.id]: e.target.value,
                                      }))
                                    }
                                  />
                                </TableCell>

                                <TableCell className="text-right">
                                  {Math.round(
                                    r.inputTokens
                                  ).toLocaleString()}
                                </TableCell>

                                <TableCell className="text-right">
                                  {Math.round(
                                    r.outputTokens
                                  ).toLocaleString()}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <CardTitle>Model Cost Comparison</CardTitle>

                    <CardDescription>
                      Compare costs across all configured models.
                    </CardDescription>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Switch
                        id="show-all-models"
                        checked={showAllModels}
                        onCheckedChange={setShowAllModels}
                      />

                      <Label htmlFor="show-all-models">
                        Show Comparison
                      </Label>
                    </div>

                    <Button
                      variant="outline"
                      onClick={downloadReport}
                      disabled={isDownloading}
                    >
                      {isDownloading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Downloading...
                        </>
                      ) : (
                        <>
                          <Download className="mr-2 h-4 w-4" />
                          Download CSV
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardHeader>

              {showAllModels && (
                <CardContent>
                  {modelBreakdown.length === 0 ? (
                    <div className="text-center py-10">
                      <p className="text-muted-foreground">
                        No pricing model configured.
                      </p>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Model</TableHead>
                          <TableHead className="text-right">
                            Input Cost
                          </TableHead>
                          <TableHead className="text-right">
                            Output Cost
                          </TableHead>
                          <TableHead className="text-right">
                            Total Cost
                          </TableHead>
                        </TableRow>
                      </TableHeader>

                      <TableBody>
                        {modelBreakdown.map((m) => (
                          <TableRow
                            key={m.id}
                            className={
                              m.model_name === selectedModel
                                ? "bg-primary/5"
                                : ""
                            }
                          >
                            <TableCell>
                              <div className="flex items-center gap-2">
                                {m.model_name}

                                {m.model_name === selectedModel && (
                                  <Badge>
                                    Selected
                                  </Badge>
                                )}
                              </div>
                            </TableCell>

                            <TableCell className="text-right">
                              ${m.inputCost.toFixed(4)}
                            </TableCell>

                            <TableCell className="text-right">
                              ${m.outputCost.toFixed(4)}
                            </TableCell>

                            <TableCell className="text-right font-semibold">
                              ${m.totalCost.toFixed(4)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              )}
            </Card>
          </>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Wallet className="h-10 w-10 text-muted-foreground mb-4" />

              <h3 className="font-semibold">
                Select an Application
              </h3>

              <p className="text-sm text-muted-foreground mt-2">
                Choose an application to begin estimating token usage.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </Container>
  );
}
