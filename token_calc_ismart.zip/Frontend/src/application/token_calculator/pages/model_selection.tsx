import { useState, useMemo } from "react";
import {
  useGetLitellmModelsQuery,
  useBulkPricingMutation,
} from "../slice/tokenCalculatorAPISlice";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Container from "@/components/ui/container";
import { Skeleton } from "@/components/ui/skeleton";
import ErrorContainer from "@/components/ui/error-container";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Search, Save } from "lucide-react";

export default function ModelSelectionPage() {
  const { toast } = useToast();
  const { data, isLoading, isError } = useGetLitellmModelsQuery();
  const [bulkPricing, { isLoading: isSaving }] = useBulkPricingMutation();

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedModels, setSelectedModels] = useState<
    Record<string, { model_name: string; input_price: number; output_price: number }>
  >({});

  // Filter models based on search query
  const filteredCategories = useMemo(() => {
    if (!data?.categories) return {};

    const filtered: Record<string, any[]> = {};
    const query = searchQuery.toLowerCase();

    Object.entries(data.categories).forEach(([category, models]) => {
      const matchedModels = models.filter((m: any) =>
        m.model_name.toLowerCase().includes(query)
      );
      if (matchedModels.length > 0) {
        filtered[category] = matchedModels;
      }
    });
    return filtered;
  }, [data, searchQuery]);

  const toggleModelSelection = (model: any) => {
    setSelectedModels((prev) => {
      const next = { ...prev };
      if (next[model.model_name]) {
        delete next[model.model_name];
      } else {
        next[model.model_name] = {
          model_name: model.model_name,
          input_price: model.input_price,
          output_price: model.output_price,
        };
      }
      return next;
    });
  };

  const handleSaveToEstimator = async () => {
    const modelsToSave = Object.values(selectedModels);
    if (modelsToSave.length === 0) {
      toast({ title: "No models selected", variant: "destructive" });
      return;
    }

    try {
      const res = await bulkPricing({ models: modelsToSave }).unwrap();
      toast({
        title: "Models Saved",
        description: `Successfully added ${res.added} and updated ${res.updated} models.`,
      });
      // clear selection on success
      setSelectedModels({});
    } catch (error) {
      toast({ title: "Failed to save models", variant: "destructive" });
    }
  };

  if (isError) {
    return (
      <Container>
        <ErrorContainer />
      </Container>
    );
  }

  return (
    <Container className="my-6 mb-12">
      <header className="flex items-start justify-between">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">
            LiteLLM Model Selection
          </h1>
          <p className="text-muted-foreground mt-2 max-w-2xl">
            Select the models you want to use in the Token Estimator. Models will be synced from the community LiteLLM database.
          </p>
        </div>
        <Button onClick={handleSaveToEstimator} disabled={isSaving}>
          {isSaving ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Save className="mr-2 h-4 w-4" />
          )}
          Save to Estimator ({Object.keys(selectedModels).length})
        </Button>
      </header>

      <div className="mt-6 space-y-4">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search models..."
            className="pl-8 max-w-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : (
          <Accordion type="multiple" className="w-full space-y-3">
            {Object.entries(filteredCategories).map(([category, models]) => (
              <AccordionItem value={category} key={category} className="border rounded-lg shadow-sm px-1 bg-card">
                <AccordionTrigger className="hover:no-underline px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className="text-lg font-semibold tracking-tight">{category}</span>
                    <Badge variant="secondary" className="font-mono text-xs rounded-full px-2.5 py-0.5">
                      {models.length} models
                    </Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 pt-2">
                    {models.map((m: any) => {
                      const isSelected = !!selectedModels[m.model_name];
                      return (
                        <div
                          key={m.id}
                          className={`flex items-start space-x-3 p-4 border rounded-lg transition-all duration-200 ${
                            isSelected 
                              ? "border-primary bg-primary/5 shadow-sm ring-1 ring-primary/20" 
                              : "hover:border-primary/40 hover:bg-accent/40"
                          }`}
                        >
                          <Checkbox
                            id={m.id}
                            checked={isSelected}
                            onCheckedChange={() => toggleModelSelection(m)}
                            className="mt-0.5 flex-shrink-0"
                          />
                          <div className="grid gap-1.5 leading-none cursor-pointer w-full" onClick={() => toggleModelSelection(m)}>
                            <label
                              htmlFor={m.id}
                              className="text-sm font-semibold leading-tight peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer break-all"
                            >
                              {m.model_name}
                            </label>
                            <div className="flex flex-col gap-1 mt-1.5">
                                <span className="text-xs text-muted-foreground font-mono bg-muted w-fit px-1.5 py-0.5 rounded">
                                  In:  ${m.input_price.toFixed(8)}
                                </span>
                                <span className="text-xs text-muted-foreground font-mono bg-muted w-fit px-1.5 py-0.5 rounded">
                                  Out: ${m.output_price.toFixed(8)}
                                </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
            {Object.keys(filteredCategories).length === 0 && (
              <div className="py-8 text-center text-muted-foreground">
                No models match your search.
              </div>
            )}
          </Accordion>
        )}
      </div>
    </Container>
  );
}
