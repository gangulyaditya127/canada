// import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
// import {
//   createPricing,
//   deletePricing,
//   fetchPricing,
//   updatePricing,
//   type ModelPricing,
// } from "../lib/api";
import {
  useGetPricingQuery,
  useCreatePricingMutation,
  useUpdatePricingMutation,
  useDeletePricingMutation,
  useSyncPricingMutation,
} from "../slice/tokenCalculatorAPISlice";

import type { ModelPricing } from "../slice/tokenCalculatorAPISlice";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import Container from "@/components/ui/container";
import { Skeleton } from "@/components/ui/skeleton";
import ErrorContainer from "@/components/ui/error-container";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { Badge } from "@/components/ui/badge";

import {
  Loader2,
  Save,
  Pencil,
  Trash2,
  X,
  Database,
  RefreshCw,
} from "lucide-react";
import { ConfirmDialog } from "../features/ConfirmDialog";
import { useToast } from "@/components/ui/use-toast";

type FormState = {
  id: number | null;
  model_name: string;
  input_price: string;
  output_price: string;
};
const empty: FormState = { id: null, model_name: "", input_price: "", output_price: "" };

export default function PricingPage() {
  // const qc = useQueryClient();
  // const pricing = useQuery({ queryKey: ["pricing"], queryFn: fetchPricing });
  const [form, setForm] = useState<FormState>(empty);

  // const invalidate = () => qc.invalidateQueries({ queryKey: ["pricing"] });
  const { toast } = useToast()
  const {
    data: pricing,
    isFetching: pricingLoading,
    isError: pricingError,
  } = useGetPricingQuery();


  const [createPricing, { isLoading: creating }] =
    useCreatePricingMutation();

  const [updatePricing, { isLoading: updating }] =
    useUpdatePricingMutation();

  const [deletePricing] =
    useDeletePricingMutation();

  const [syncPricing, { isLoading: syncing }] = useSyncPricingMutation();

  const handleSync = async () => {
    try {
      const res = await syncPricing().unwrap();
      toast({
        title: "Prices Synced",
        description: `Successfully updated ${res.updated} models.`
      });
    } catch (error) {
      toast({
        title: "Sync Failed",
        variant: "destructive"
      });
    }
  };

  const handleSave = async () => {
    try {
      const payload = {
        model_name: form.model_name.trim(),
        input_price: Number(form.input_price),
        output_price: Number(form.output_price),
      };

      if (form.id) {
        await updatePricing({
          id: form.id,
          ...payload,
        }).unwrap();
        toast({
          title: "Model Updated",
        });
      } else {
        await createPricing(payload).unwrap();

        toast({
          title: "Model Added",
        });
      }

      setForm(empty);
    } catch (error: any) {
      toast({
        title: "Failed to save",
        variant: "destructive"
      });
    }
  };


  const edit = (m: ModelPricing) =>
    setForm({
      id: m.id,
      model_name: m.model_name,
      input_price: String(m.input_price),
      output_price: String(m.output_price),
    });



  if (pricingError) {
    return (
      <Container>
        <ErrorContainer />
      </Container>
    );
  }


  return (
    <Container className="my-6 mb-12">
      <header className="flex items-start justify-between">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">
            Model Pricing Console
          </h1>

          <p className="text-muted-foreground mt-2 max-w-2xl">
            Configure token pricing for AI models used across the token cost
            calculator.
          </p>
        </div>
        <Button onClick={handleSync} disabled={syncing} variant="outline">
          {syncing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
          Sync Prices
        </Button>
      </header>
      <div className="grid gap-6 lg:grid-cols-[400px_1fr] mt-6">
        <Card className="border-border rounded-lg">
          <CardHeader>
            <CardTitle>
              {form.id ? "Edit Model" : "Add New Model"}
            </CardTitle>

            <CardDescription>
              Input and output token prices are stored per token in USD.
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                handleSave();
              }}
            >
              <div className="space-y-2">
                <Label>Model Name</Label>

                <Input
                  required
                  value={form.model_name}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      model_name: e.target.value,
                    })
                  }
                  placeholder="gpt-5-mini"
                />
              </div>

              <div className="space-y-2">
                <Label>Input Price (per token)</Label>

                <Input
                  required
                  type="number"
                  step="0.00000001"
                  value={form.input_price}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      input_price: e.target.value,
                    })
                  }
                  placeholder="0.00000025"
                />
              </div>

              <div className="space-y-2">
                <Label>Output Price (per token)</Label>

                <Input
                  required
                  type="number"
                  step="0.00000001"
                  value={form.output_price}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      output_price: e.target.value,
                    })
                  }
                  placeholder="0.000002"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <Button
                  type="submit"
                  disabled={creating || updating}
                >
                  {creating || updating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      {form.id
                        ? "Update Model"
                        : "Add Model"}
                    </>
                  )}
                </Button>

                {form.id && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setForm(empty)}
                  >
                    <X className="mr-2 h-4 w-4" />
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        <Card className="border-none">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>
                Available Models
              </CardTitle>

              <CardDescription>
                Manage configured pricing models.
              </CardDescription>
            </div>

            <Badge variant="outline">
              {pricing?.length ?? 0} Models
            </Badge>
          </CardHeader>

          <CardContent>
            {pricingLoading ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Model</TableHead>
                    <TableHead>Input / Token</TableHead>
                    <TableHead>Output / Token</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>

                <TableBody>
                  {Array.from({ length: 6 }).map((_, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <Skeleton className="h-6 w-32" />
                      </TableCell>

                      <TableCell>
                        <Skeleton className="h-6 w-24 ml-auto" />
                      </TableCell>

                      <TableCell>
                        <Skeleton className="h-6 w-24 ml-auto" />
                      </TableCell>

                      <TableCell>
                        <div className="flex justify-end gap-2">
                          <Skeleton className="h-9 w-9 rounded-md" />
                          <Skeleton className="h-9 w-9 rounded-md" />
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <>
                {pricing && pricing.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Model</TableHead>

                        <TableHead className="text-right">
                          Input / Token
                        </TableHead>

                        <TableHead className="text-right">
                          Output / Token
                        </TableHead>

                        <TableHead className="w-32">
                          Actions
                        </TableHead>
                      </TableRow>
                    </TableHeader>

                    <TableBody>
                      {pricing.map((m) => (
                        <TableRow key={m.id}>
                          <TableCell>
                            <Badge variant="secondary">
                              {m.model_name}
                            </Badge>
                          </TableCell>

                          <TableCell className="text-right font-mono">
                            $
                            {Number(
                              m.input_price
                            ).toFixed(8)}
                          </TableCell>

                          <TableCell className="text-right font-mono">
                            $
                            {Number(
                              m.output_price
                            ).toFixed(8)}
                          </TableCell>

                          <TableCell>
                            <div className="flex justify-end gap-2">
                              <Button
                                size="icon"
                                variant="outline"
                                onClick={() => edit(m)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>

                              <ConfirmDialog
                                title="Delete Pricing Model"
                                description={`This will permanently delete ${m.model_name}.`}
                                successMessage={`${m.model_name} deleted successfully`}
                                onConfirm={async () => {
                                  await deletePricing(m.id).unwrap();
                                }}
                                trigger={
                                  <Button
                                    size="icon"
                                    variant="destructive"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                }
                              />
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="flex flex-col items-center justify-center py-16">
                    <Database className="h-12 w-12 text-muted-foreground mb-4" />

                    <h3 className="font-semibold">
                      No Models Configured
                    </h3>

                    <p className="text-sm text-muted-foreground mt-2">
                      Add your first model pricing configuration to get started.
                    </p>
                  </div>
                )}
              </>
            )}
          </CardContent>


        </Card>
      </div>
    </Container>
  );
}
