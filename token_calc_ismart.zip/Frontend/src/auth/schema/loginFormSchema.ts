import { z } from 'zod'

export const loginFromSchema = z.object({
    identifier: z.string(),
    password: z.string()
})