import { z } from 'zod';
export const signUpFormSchema = z.object({
    empId: z.string({ message: 'Employee Id can\'t be empty ' })
        .min(5, { message: "Employee Id must be more than 5 characters" }),
    email: z.string({ message: 'Email can\'t be empty ' })
        .email()
        .regex(/^[a-zA-Z0-9._%+-]+@tcs\.com$/, { message: 'Email should belong to tcs' }),
    businessGroup: z.string({ message: 'Business group can\'t be empty ' })
        .min(1, { message: "Please select your business group" }),
    buOther: z.string().optional(),
    isu: z.string({ message: 'ISU can\'t be empty ' }),
    isuOther: z.string().optional(),
    // .min(1, { message: "Please select your ISU" }),
    subIsu: z.string({ message: 'Sub ISU group can\'t be empty ' }),
    subIsuOther: z.string().optional(),
    // .min(1, { message: "Please select your Sub ISU" }),
    password: z.string({ message: 'Password can\'t be empty ' })
        .min(4, { message: "Please enter the password" }),
    confirmPassword: z.string({ message: "Confirm Password can't be empty " })
        .min(4, { message: "Please re-enter the password" }),
}).refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
});
