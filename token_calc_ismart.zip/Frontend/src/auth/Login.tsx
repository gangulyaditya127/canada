import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useEffect, useState } from "react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Icon } from "@/components/ui/icon";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { Eye, EyeOff, RocketIcon } from "lucide-react";
import LanguageToggle from "@/components/ui/language-toggle";
import { useTranslation } from "react-i18next";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/components/ui/use-toast";
import { loginFromSchema } from "./schema/loginFormSchema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from 'zod';
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useLazyUserinfoQuery, useLoginMutation } from "./slice/keyClockAPISlice";
import { updateLoginStatus } from "./slice/authSlice";
import { useAppDispatch } from "@/lib/redux/hooks";
function Login() {
  const { t, ready } = useTranslation('auth')
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false)
  const location = useLocation();
  const redirectPath = new URLSearchParams(location.search).get("_r") || "/";
  const isAccountCreated = new URLSearchParams(location.search).get("_s") || "";
  const dispatch = useAppDispatch();
  const loginForm = useForm<z.infer<typeof loginFromSchema>>({
    resolver: zodResolver(loginFromSchema),
    defaultValues: {
    },
  })
  const { toast } = useToast()
  const [trigger, { isLoading, error, isError, data }] = useLoginMutation();

  const [triggerUserInfo, { data: userLoginData }] = useLazyUserinfoQuery()

  const login = ({ identifier, password }: z.infer<typeof loginFromSchema>) => {
    trigger({
      username: (identifier),
      password: password
    })
  };

  useEffect(() => {
    if (isError) {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: "Failed to login. Please try after sometime",
      });
      console.log({ error })
    }
    if (data) {
      triggerUserInfo(undefined)
    }
  }, [data, isError])

  useEffect(() => {
    if (userLoginData) {
      dispatch(updateLoginStatus({
        isLoggedIn: true,
        userName: 'test_user',
        isAdmin: false,
        rawUserDetails: userLoginData
      }))
      navigate(redirectPath);
    }
  }, [userLoginData])

  if (!ready) {
    return <div className="h-screen inset-0 w-full grid fixed z-[200] fixed bg-background place-items-center">
      <Skeleton className="h-80 w-96 rounded-xl" />
    </div>
  }

  if (userLoginData) {
    return <Navigate to={redirectPath} />
  }
  const signUpUrl =
  redirectPath && redirectPath.length > 0
    ? "/sign-up?_r=" + redirectPath
    : "/sign-up";
    

  return (
    <div className="h-screen inset-0 w-full grid fixed z-[200] fixed bg-background place-items-center">
      <LanguageToggle className="absolute top-2 right-2" />
      <div className="flex flex-col items-center justify-center py-12">
        <div className="relative">
          <div className="flex items-center justify-between">
            <NavigateBackButton />
            <Link className={("text-xs py-0 mb-4 col-span-4 flex gap-1 text-muted-foreground hover:text-foreground")} to='/'>
              <Icon name="home" className="size-4" />
              <span>Home</span>
            </Link >
          </div>
          <div className="mx-auto grid w-[350px] gap-6">
            <div className="grid gap-2 text-center">
              <h1 className="text-xl font-medium">{t('login')} {t('appName')}</h1>
            </div>
            {isAccountCreated?.length > 0 &&
              <Alert className="bg-blue-800/10 border-blue-800/10">
                <RocketIcon className="h-4 w-4" />
                <AlertTitle className="text-xs">Account created successfully!</AlertTitle>
                <AlertDescription className="text-xs text-muted-foreground">
                  Your account has been created successfully. Please verify your email to log in.
                </AlertDescription>
              </Alert>
            }
            {isError && <div className="bg-red-600 w-full p-2 rounded-lg text-center">
              <div className="text-sm text-white">{t('loginInput.error')}</div>
            </div>}
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(login)} className="grid gap-4">
                <FormField
                  control={loginForm.control}
                  name="identifier"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('loginInput.empid')}</FormLabel>
                      <FormControl>
                        <Input placeholder={t('loginInput.empid')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center">
                        <FormLabel>{t('loginInput.password')}</FormLabel>
                        <Link
                          to={`https://ismartams.tcsapps.com/keycloak/realms/are_master/login-actions/reset-credentials`}
                          className="ml-auto inline-block text-sm underline"
                          target="_blank"
                        >
                          {t('loginInput.forgotPassword')}
                        </Link>
                      </div>
                      <div className="relative">
                        <FormControl>
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder={t('loginInput.password')}
                            {...field}
                            className="pr-10"
                            autoComplete="password"
                          />
                        </FormControl>

                        <button
                          type="button"
                          onClick={() => setShowPassword((s) => !s)}
                          className="absolute inset-y-0 right-2 flex items-center text-muted-foreground hover:text-foreground"
                          aria-label={showPassword ? "Hide confirm password" : "Show confirm password"}
                          aria-pressed={showPassword}
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={isLoading} className="w-full bg-blue-700 hover:bg-blue-800 gap-2 rounded-lg text-white hover:text-white">
                  {isLoading && <Icon name="loader-circle" className="animate-spin h-4 w-4" />}
                  {t('loginInput.login')}
                </Button>
                <div className="flex justify-between items-center">
                  <Link to={signUpUrl} className="text-sm text-muted-foreground group/login text-center">
                    {t('loginInput.message')} {" "}
                    <span className="underline group-hover/login:text-foreground">{t('loginInput.signup')}</span>
                  </Link>
                </div>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Login;