import { useDispatch } from "react-redux";
import { logout } from "../slice/keyClockAuthSlice";

export const useLogout = () => {
    const dispatch = useDispatch()
    const lu = () => {
        dispatch(logout(
        ))
    }
    return lu;
}