import { useAppSelector } from "@/lib/redux/hooks";
import { Navigate, Outlet, useLocation } from "react-router-dom";

const AMSLoginProtectedRoute = () => {
    const userDetails = useAppSelector((state) => state.keyClockAuthSlice.user);
    const location = useLocation();
    return userDetails ? (
        <Outlet />
    ) : (
        <Navigate to={`/login?_r=${location.pathname}`} replace={true} />
    );
};

export default AMSLoginProtectedRoute;
