import { useAppSelector } from "@/lib/redux/hooks";
import { Navigate, Outlet } from "react-router-dom";

const AMSAdminProtectedRoute = () => {
    const userDetails = useAppSelector((state) => state.auth.rawUserDetails);
    return userDetails?.isAdmin == 'Y' ? (
        <Outlet />
    ) : (
        <Navigate to={`/`} replace={true} />
    );
};

export default AMSAdminProtectedRoute;
