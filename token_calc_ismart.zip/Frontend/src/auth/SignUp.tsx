import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Input } from "@/components/ui/input";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { z } from 'zod'
import { zodResolver } from "@hookform/resolvers/zod"
import { signUpFormSchema } from './schema/signupFormSchema'
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form"
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import { useForm } from "react-hook-form";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Skeleton } from "@/components/ui/skeleton";
import {
    useLazyGetBusinessGroupQuery,
    useLazyGetISUQuery,
    useLazyGetSubISUQuery,
    // useLazyRegisterUserQuery
} from "./slice/authAPISlice";
import { useToast } from "@/components/ui/use-toast";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
import { useAppSelector } from "@/lib/redux/hooks";
import Loader from "@/components/ui/loader";
import { Eye, EyeOff } from "lucide-react";
import { useSignupMutation } from "./slice/keyClockAPISlice";
import { AutocompleteInput } from "@/components/ui/autocomplete";

export default function SignUp() {
    const [bgOptions, setBgOptions] = useState([]);
    const [isuOptions, setIsuOptions] = useState([]);
    const [subIsuOptions, setSubIsuOptions] = useState([]);
    const [trigger, { isError: isRegisterError, error: registerError, data, isLoading: isLoadingSignUp }] = useSignupMutation()
    const [triggerBU, { isError: bgError, data: bgAPIResponse, isFetching: bgFetch }] = useLazyGetBusinessGroupQuery()
    const [getSubISUTrigger, subISUAPI] = useLazyGetSubISUQuery();
    const [getISUTrigger, isuAPI] = useLazyGetISUQuery()
    const { toast } = useToast()
    const navigate = useNavigate()
    const location = useLocation();
    const redirectPath = new URLSearchParams(location.search).get("_r") || "/";
    const { isError: subISUAPIError, isFetching: subISUAPIFetching, data: subISUResponse } = subISUAPI
    const { isError: isuAPIError, isFetching: isuAPIFetching, data: isuResponse } = isuAPI
    const { t, ready } = useTranslation('auth')
    const [showConfirm, setShowConfirm] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const userDetails = useAppSelector((state) => state.keyClockAuthSlice.user);

    const signupForm = useForm<z.infer<typeof signUpFormSchema>>({
        resolver: zodResolver(signUpFormSchema),
        defaultValues: {
        },
    })
    const bgWatch = signupForm.watch('businessGroup')
    const isuWatch = signupForm.watch('isu')
    const subIsuWatch = signupForm.watch('subIsu')

    const showBuOther = bgWatch === "Other";
    const showIsuOther = isuWatch === "Other";
    const showSubIsuOther = subIsuWatch === "Other";

    useEffect(() => {
        if (!showIsuOther) signupForm.setValue("isuOther", "");
    }, [showIsuOther]);
    useEffect(() => {
        if (!showSubIsuOther) signupForm.setValue("subIsuOther", "");
    }, [showSubIsuOther]);
    useEffect(() => {
        if (!showBuOther) signupForm.setValue("buOther", "");
    }, [showBuOther]);

    useEffect(() => {
        triggerBU();
    }, [triggerBU]);
    useEffect(() => {

        const mapped =
            bgAPIResponse?.map?.((el: string) => ({ value: el, label: el })) ?? [];

        mapped.push({ value: "Other", label: "Other" });

        setBgOptions(mapped);

    }, [bgAPIResponse])
    useEffect(() => {
        if (bgWatch?.length > 0) {
            const mapped =
                isuResponse?.map?.((el: string) => ({ value: el, label: el })) ?? [];

            mapped.push({ value: "Other", label: "Other" });

            setIsuOptions(mapped);

        } else {
            setIsuOptions([])
        }
    }, [isuResponse, bgWatch])
    useEffect(() => {
        const mapped =
            subISUResponse?.map?.((el: string) => ({ value: el, label: el })) ?? [];

        mapped.push({ value: "Other", label: "Other" });

        setSubIsuOptions(mapped);
    }, [subISUResponse])
    useEffect(() => {
        const id = setTimeout(() => {
            bgWatch?.length && getISUTrigger({
                businessGroup: bgWatch
            })
        }, 1000)
        signupForm.setValue("isu", "")
        return () => {
            clearTimeout(id)
        }
    }, [bgWatch])
    useEffect(() => {
        if (bgError) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to fetch business group list",
            });
        }
        if (subISUAPIError) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to fetch Sub ISU list",
            });
        }
        if (isuAPIError) {
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: "Failed to fetch ISU list",
            });
        }
    }, [bgError, subISUAPIError, isuAPIError])

    useEffect(() => {
        if (isRegisterError) {
            // console.log('calling toast')
            toast({
                variant: "destructive",
                title: "Uh oh! Something went wrong.",
                description: (registerError as any)?.data?.eror
            });
            return;
        }
        if (data) {
            toast({
                variant: 'default',
                title: "Account created successfully. Please verify your email",
                description: data.message
            })
            const loginUrl =
                redirectPath && redirectPath.length > 0
                    ? "/login?_r=" + redirectPath + "&_s=true"
                    : "/login";

            navigate(loginUrl);
            return;
        }
    }, [isRegisterError, data, registerError])

    useEffect(() => {
        setSubIsuOptions([])
        bgWatch && isuWatch && getSubISUTrigger({
            businessGroup: bgWatch,
            isu: isuWatch
        })
        signupForm.setValue("subIsu", "")
    }, [bgWatch, isuWatch])


    function onSubmit(values: z.infer<typeof signUpFormSchema>) {
        const payload = {
            empid: values.empId,
            email: values.email,
            bg: showBuOther ? (values.buOther || "").trim() : values.businessGroup,
            isu: showIsuOther ? (values.isuOther || "").trim() : values.isu,
            subisu: showSubIsuOther ? (values.subIsuOther || "").trim() : values.subIsu,
            account: "DEFAULT",
            password: values.password,
            confirm_password: values.confirmPassword,
        }
        trigger(payload)
    }

    if (!ready) {
        return <div className="h-screen inset-0 w-full grid z-[200] fixed bg-background place-items-center">
            <Skeleton className="w-80 h-[85vh] rounded-xl" />
        </div>
    }

    if (userDetails?.preferred_username) {
        return <Navigate to={redirectPath} />
    }
    const loginUrl =
        redirectPath && redirectPath.length > 0
            ? "/login?_r=" + redirectPath
            : "/login";
    return (
        <div className="h-screen inset-0 w-full grid fixed z-[200]  bg-background place-items-center pt-14 overflow-y-auto">
            <div className="flex flex-col items-center justify-center py-12">
                <div className="relative">
                    <NavigateBackButton />
                    <div className="mx-auto grid w-[350px] gap-6">
                        <div className="grid gap-2 text-center">
                            <h1 className="text-xl font-medium">{t('signup')} {t('appName')}</h1>
                        </div>
                        <Form {...signupForm}>
                            <form onSubmit={signupForm.handleSubmit(onSubmit)} className="grid gap-4 mt-4">
                                <FormField
                                    control={signupForm.control}
                                    name="empId"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t('signUpInput.0.field')}</FormLabel>
                                            <FormControl>
                                                <Input placeholder={t('signUpInput.0.placeholder')} {...field} />
                                            </FormControl>
                                            <FormDescription>
                                                {t('signUpInput.0.description')}
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={signupForm.control}
                                    name="email"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t('signUpInput.1.field')}</FormLabel>
                                            <FormControl>
                                                <Input placeholder={t('signUpInput.1.placeholder')} {...field} />
                                            </FormControl>
                                            <FormDescription>
                                                {t('signUpInput.1.description')}
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={signupForm.control}
                                    name="businessGroup"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel className="flex gap-2">
                                                <span>
                                                    {t('signUpInput.2.field')}
                                                </span>
                                                {bgFetch && <Icon name="loader-circle" className="animate-spin h-4 w-4" />}
                                            </FormLabel>
                                            <FormControl>
                                                <SingleSelectCombobox optionList={bgOptions} field="business group" setValue={field.onChange} value={field.value} placeholder={t('signUpInput.2.placeholder')} widthClass="w-full" />
                                            </FormControl>
                                            <FormDescription>
                                                {t('signUpInput.2.description')}
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                {showBuOther && (
                                    <FormField
                                        control={signupForm.control}
                                        name="buOther"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormControl>
                                                    <AutocompleteInput
                                                        options={bgOptions}
                                                        onValueChange={field.onChange}
                                                        value={field.value}
                                                        placeholder="Specify Business Group"
                                                        // widthClass="w-full"
                                                        loading={false}
                                                    />
                                                </FormControl>
                                                <FormDescription>
                                                    Provide the Business Group name if it’s not listed.
                                                </FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                )}
                                <FormField
                                    control={signupForm.control}
                                    name="isu"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel className="flex gap-2">
                                                <span>
                                                    {t('signUpInput.3.field')}
                                                </span>
                                                {isuAPIFetching && <Icon name="loader-circle" className="animate-spin h-4 w-4" />}
                                            </FormLabel>
                                            <SingleSelectCombobox optionList={isuOptions ?? []} field={t('signUpInput.3.field')} setValue={field.onChange} value={field.value} placeholder={t('signUpInput.3.placeholder')} widthClass="w-full" />
                                            <FormDescription>
                                                {t('signUpInput.3.description')}
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                {showIsuOther && (
                                    <FormField
                                        control={signupForm.control}
                                        name="isuOther"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormControl>
                                                    <AutocompleteInput
                                                        options={isuOptions}
                                                        onValueChange={field.onChange}
                                                        value={field.value}
                                                        placeholder="Specify ISU"
                                                        // widthClass="w-full"
                                                        loading={false}
                                                    />
                                                </FormControl>
                                                <FormDescription>
                                                    Provide the ISU name if it’s not listed.
                                                </FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                )}
                                <FormField
                                    control={signupForm.control}
                                    name="subIsu"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel className="flex gap-2">
                                                <span>
                                                    {t('signUpInput.4.field')}
                                                </span>
                                                {subISUAPIFetching && <Icon name="loader-circle" className="animate-spin h-4 w-4" />}
                                            </FormLabel>
                                            <SingleSelectCombobox optionList={subIsuOptions ?? []} field={t('signUpInput.4.field')} setValue={field.onChange} value={field.value} placeholder={t('signUpInput.4.placeholder')} widthClass="w-full" />
                                            <FormDescription>
                                                {t('signUpInput.4.description')}
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                {showSubIsuOther && (
                                    <FormField
                                        control={signupForm.control}
                                        name="subIsuOther"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormControl>
                                                    <AutocompleteInput
                                                        options={subIsuOptions}
                                                        onValueChange={field.onChange}
                                                        value={field.value}
                                                        placeholder="Type your Sub ISU"
                                                        // widthClass="w-full"
                                                        loading={false}
                                                    />
                                                </FormControl>
                                                <FormDescription>
                                                    Provide the Sub ISU name if it’s not listed.
                                                </FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                )}
                                <FormField
                                    control={signupForm.control}
                                    name="password"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t('signUpInput.5.field')}</FormLabel>
                                            <div className="relative">
                                                <FormControl>
                                                    <Input
                                                        type={showPassword ? "text" : "password"}
                                                        placeholder={t('signUpInput.5.placeholder')}
                                                        {...field}
                                                        className="pr-10"
                                                        autoComplete="new-password"
                                                    />
                                                </FormControl>

                                                <button
                                                    type="button"
                                                    onClick={() => setShowPassword((s) => !s)}
                                                    className="absolute inset-y-0 right-2 flex items-center text-muted-foreground hover:text-foreground"
                                                    aria-label={showPassword ? "Hide confirm password" : "Show confirm password"}
                                                    aria-pressed={showPassword}
                                                >
                                                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                                </button>
                                            </div>

                                            <FormDescription>
                                                {t('signUpInput.5.description')}
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={signupForm.control}
                                    name="confirmPassword"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t('signUpInput.6.field')}</FormLabel>
                                            <div className="relative">
                                                <FormControl>
                                                    <Input
                                                        type={showConfirm ? "text" : "password"}
                                                        placeholder={t('signUpInput.6.placeholder')}
                                                        {...field}
                                                        className="pr-10" // reserve space for the icon
                                                        autoComplete="new-password"
                                                    />
                                                </FormControl>

                                                <button
                                                    type="button"
                                                    onClick={() => setShowConfirm((s) => !s)}
                                                    className="absolute inset-y-0 right-2 flex items-center text-muted-foreground hover:text-foreground"
                                                    aria-label={showConfirm ? "Hide confirm password" : "Show confirm password"}
                                                    aria-pressed={showConfirm}
                                                >
                                                    {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                                </button>
                                            </div>

                                            <FormDescription>
                                                {t('signUpInput.6.description')}
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <Button type="submit" disabled={isLoadingSignUp} className="w-full bg-blue-700 hover:bg-blue-800 gap-2 rounded-lg text-white hover:text-white">
                                    {isLoadingSignUp && <Loader />}
                                    {t('continue')}
                                </Button>
                                <Link to={loginUrl} className="text-sm text-muted-foreground group/login text-center">
                                    {t('signUpDescription')} {" "}
                                    <span className="underline group-hover/login:text-foreground">{t('signUpAlt')}</span>
                                </Link>
                            </form>
                        </Form>
                    </div>
                </div>
            </div>
        </div>
    );
}