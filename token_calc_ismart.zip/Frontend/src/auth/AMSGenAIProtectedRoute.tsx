import { useAppSelector } from "@/lib/redux/hooks";
import { Navigate, Outlet, useLocation } from "react-router-dom";

const AMSGenAIProtectedRoute = ({ unauthorizedRoute }: { unauthorizedRoute: string }) => {
    const userDetails = useAppSelector((state) => state.auth.rawUserDetails);
    const location = useLocation();
    console.log(unauthorizedRoute);

    if (!userDetails?.empid) return <Navigate to={`/login?_r=${location.pathname}`} replace={true} />

    return   <Outlet />

  
};

export default AMSGenAIProtectedRoute;
