import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useEffect } from "react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Icon } from "@/components/ui/icon";
import LanguageToggle from "@/components/ui/language-toggle";
import { useTranslation } from "react-i18next";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/components/ui/use-toast";
import { forgotPasswordSchema } from "./schema/forgotPasswordSchema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from 'zod';
import { useLazyForgetPasswordQuery } from "./slice/authAPISlice";
import { NavigateBackButton } from "@/components/ui/navigate-back-button";
function ForgotPassword() {
  const { t, ready } = useTranslation('auth')
  const navigate = useNavigate();

  const forgotPassword = useForm<z.infer<typeof forgotPasswordSchema>>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
    },
  })
  const { toast } = useToast()
  const [trigger, { isError, data, isFetching }] = useLazyForgetPasswordQuery()

  const login = ({ identifier }: z.infer<typeof forgotPasswordSchema>) => {
    trigger({
      empid: Number(identifier),
    })
  };

  useEffect(() => {
    if (isError) {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: "Failed to login. Please try after sometime",
      });
      return;
    }
    if (data) {
      toast({
        title: "Password reset successful",
        description: data.message,
      });
      navigate('/login');
    }
  }, [data, isError])

  if (!ready) {
    return <div className="h-screen inset-0 w-full grid fixed z-[200] fixed bg-background place-items-center">
      <Skeleton className="h-80 w-96 rounded-xl" />
    </div>
  }

  return (
    <div className="h-screen inset-0 w-full grid fixed z-[200] fixed bg-background place-items-center">
      <LanguageToggle className="absolute top-2 right-2" />
      <div className="flex flex-col items-center justify-center py-12">
        <div className="relative">
          <NavigateBackButton />
          <div className="mx-auto grid w-[350px] gap-6">
            <div className="grid gap-2 text-center">
              <h1 className="text-xl font-medium">{t('login')} {t('appName')}</h1>
            </div>
            <Form {...forgotPassword}>
              <form onSubmit={forgotPassword.handleSubmit(login)} className="grid gap-4">
                <FormField
                  control={forgotPassword.control}
                  name="identifier"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('loginInput.empid')}</FormLabel>
                      <FormControl>
                        <Input placeholder={t('loginInput.empid')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={isFetching} className="w-full bg-tcs-primary gap-2 rounded-lg dark:bg-[#2469BC] text-primary">
                  {isFetching && <Icon name="loader-circle" className="animate-spin h-4 w-4" />}
                  Request Password Reset
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
}
export default ForgotPassword;
