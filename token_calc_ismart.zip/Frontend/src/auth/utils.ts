import { randomInt } from "node:crypto";

const MIN_RADIUS = 10;
const MAX_RADIUS = 25;
const DEPTH = 2;
const LEFT_COLOR = "9333ea";
const RIGHT_COLOR = "7c3aed";
const NUM_POINTS = 1500;

const getGradientStop = (ratio: number) => {
  if (ratio > 1) {
    ratio = 1;
  } else if (ratio < 0) {
    ratio = 0;
  }

  const c0 = LEFT_COLOR.match(/.{1,2}/g)?.map(
    (oct) => Number.parseInt(oct, 16) * (1 - ratio),
  );
  const c1 = RIGHT_COLOR.match(/.{1,2}/g)?.map(
    (oct) => Number.parseInt(oct, 16) * ratio,
  );
  const ci = [0, 1, 2].map((i) =>
    Math.min(Math.round(c0?.[i] ?? 0 + (c1?.[i] ?? 0)), 255),
  );
  const color = ci
    .reduce((a, v) => (a << 8) + v, 0)
    .toString(16)
    .padStart(6, "0");

  return `#${color}`;
};

const calculateColor = (x: number) => {
  const maxDiff = MAX_RADIUS * 4;
  const distance = x + MAX_RADIUS;

  const ratio = distance / maxDiff;

  const stop = getGradientStop(ratio);
  return stop;
};



const randomFromInterval = (min: number, max: number): number => {
  return randomInt(min, max);
};

export const pointsInner = Array.from(
  { length: NUM_POINTS },
  (_, k) => k + 1,
).map((num) => {
  const randomRadius = randomFromInterval(MIN_RADIUS, MAX_RADIUS);
  const randomAngle = randomInt(999) * Math.PI * 2;

  const x = Math.cos(randomAngle) * randomRadius;
  const y = Math.sin(randomAngle) * randomRadius;
  const z = randomFromInterval(-DEPTH, DEPTH);

  const color = calculateColor(x);
  return {
    idx: num,
    position: [x, y, z],
    color,
  };
});

export const pointsOuter = Array.from(
  { length: NUM_POINTS / 4 },
  (_, k) => k + 1,
).map((num) => {
  const randomRadius = randomFromInterval(MIN_RADIUS / 2, MAX_RADIUS * 2);
  const angle = randomInt(999) * Math.PI * 2;

  const x = Math.cos(angle) * randomRadius;
  const y = Math.sin(angle) * randomRadius;
  const z = randomFromInterval(-DEPTH * 10, DEPTH * 10);

  const color = calculateColor(x);

  return {
    idx: num,
    position: [x, y, z],
    color,
  };
});
