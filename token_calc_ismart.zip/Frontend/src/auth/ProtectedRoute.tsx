import { useAppSelector } from "@/lib/redux/hooks";
import { Navigate, Outlet, useLocation } from "react-router-dom";

const ProtectedRoute = () => {
  const isLoggedIn = useAppSelector((state) => state.auth?.isLoggedIn);
  const location = useLocation();
  return isLoggedIn ? (
    <Outlet />
  ) : (
    <Navigate to={`/login?_r=${location.pathname}`} replace={true} />
  );
  // return <Outlet />;
};

export default ProtectedRoute;
