import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

export type registerUserProps = {
    empid: number,
    email: string,
    bu: string,
    isu: string,
    sub_isu: string,
    password: string,
}
export type loginUserProps = {
    empid: number,
    pass: string
}
export const authAPI = createApi({
    reducerPath: 'authAPI',
    baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_SPRING_BASE_URL}/login/` }),
    tagTypes: ['auth_api'],
    endpoints: ({ query }) => ({
        registerUser: query<any, registerUserProps>({
            query: (queryParams) => ({ url: `registerUser`, params: queryParams }),
        }),
        loginUser: query<any, loginUserProps>({
            query: (queryParams) => ({ url: 'ismartLogin', params: queryParams })
        }),
        forgetPassword: query<any, { empid: number }>({
            query: (queryParams) => ({ url: 'forgetPassword', params: queryParams })
        }),
        getSubISU: query<any, any>({
            query: (queryParams) => ({
                url: `${import.meta.env.VITE_API_PYTHON_BASE_URL}/are-ams-quick-maturity/getSubIsu`,
                params: queryParams,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        getOpportunityType: query<any, any>({
            query: (queryParams) => ({ url: 'getOpportunityType', params: queryParams })
        }),
        getListOfLocations: query<any, any>({
            query: (queryParams) => ({ url: 'getListOfLocations', params: queryParams })
        }),
        getISU: query<any, any>({
            query: (queryParams) => ({
                url: `${import.meta.env.VITE_API_PYTHON_BASE_URL}/are-ams-quick-maturity/getIsu`,
                params: queryParams,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        getBusinessGroup: query<any, void>({
            query: () => ({
                url: `${import.meta.env.VITE_API_PYTHON_BASE_URL}/are-ams-quick-maturity/getBusinessGroup`,
                method: 'GET',
            }),
            // invalidatesTags: [],
        }),
        getLocation: query<any, any>({
            query: () => ({ url: 'getListOfLocations' })
        })
    }),
})

export const {
    useRegisterUserQuery,
    useLazyRegisterUserQuery,
    useLoginUserQuery,
    useLazyLoginUserQuery,
    useForgetPasswordQuery,
    useLazyForgetPasswordQuery,
    useGetSubISUQuery,
    useLazyGetISUQuery,
    useGetOpportunityTypeQuery,
    useLazyGetOpportunityTypeQuery,
    useGetListOfLocationsQuery,
    useLazyGetListOfLocationsQuery,
    useGetISUQuery,
    useLazyGetSubISUQuery,
    useLazyGetBusinessGroupQuery,
    useGetBusinessGroupQuery,
    useGetLocationQuery,
    useLazyGetLocationQuery,

} = authAPI