import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import type { BaseQueryFn, FetchArgs, FetchBaseQueryError } from '@reduxjs/toolkit/query'
import { selectAccessToken, selectRefreshToken, setCredentials, setUser, logout } from './keyClockAuthSlice'

type SolutionKey = `ARE_${string}`;
type Permission = 'download' | 'execute' | 'view';
type SolutionMap = Record<SolutionKey, Permission[]>;
export interface UserInfo extends Partial<SolutionMap> {
  sub: string;
  email_verified: boolean;
  name: string;
  preferred_username: string;
  given_name: string;
  family_name: string;
  email: string;
}
export type registerUserProps = {
  empid: string
  email: string
  bg: string
  isu: string
  subisu: string
  account: string
  password: string
  confirm_password: string
}

type TokenResponse = {
  access_token: string
  refresh_token?: string
  id_token?: string
  token_type?: string
  expires_in?: number
  scope?: string
}

const KC_REALM = import.meta.env.VITE_KEYCLOAK_REALM
const KC_BASE = import.meta.env.VITE_KEYCLOAK_BASE_URL

const rawBase = fetchBaseQuery({
  baseUrl: `${KC_BASE}/realms/${KC_REALM}`,
  prepareHeaders: (headers, { getState }) => {
    const token = selectAccessToken(getState() as any)
    if (token) headers.set('Authorization', `Bearer ${token}`);
    console.log({ headers })
    return headers
  },
})

const baseQueryWithReauth: BaseQueryFn<string | FetchArgs, unknown, FetchBaseQueryError> =
  async (args, api, extra) => {
    let result = await rawBase(args, api, extra)
    if (result.error?.status === 401) {
      const refreshToken = selectRefreshToken(api.getState() as any)
      if (!refreshToken) { api.dispatch(logout()); return result }
      const refreshBody = new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: import.meta.env.VITE_KEYCLOAK_CLIENT_ID,
        ...(import.meta.env.VITE_KEYCLOAK_CLIENT_SECRET
          ? { client_secret: import.meta.env.VITE_KEYCLOAK_CLIENT_SECRET }
          : {}),
        refresh_token: refreshToken,
      }).toString()
      const refreshRes = await rawBase({
        url: `/protocol/openid-connect/token`,
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: refreshBody,
      }, api, extra)
      if (refreshRes.data) {
        const td = refreshRes.data as TokenResponse
        api.dispatch(setCredentials({ accessToken: td.access_token, refreshToken: td.refresh_token ?? refreshToken }))
        result = await rawBase(args, api, extra)
      } else {
        api.dispatch(logout())
      }
    }
    return result
  }

export const keyClockAPI = createApi({
  reducerPath: 'keyClockAPI',
  baseQuery: baseQueryWithReauth,
  endpoints: ({ query, mutation }) => ({
    login: mutation<TokenResponse, { username: string; password: string }>({
      query: ({ username, password }) => ({
        url: `/protocol/openid-connect/token`,
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: import.meta.env.VITE_KEYCLOAK_CLIENT_ID,
          ...(import.meta.env.VITE_KEYCLOAK_CLIENT_SECRET
            ? { client_secret: import.meta.env.VITE_KEYCLOAK_CLIENT_SECRET }
            : {}),
          grant_type: 'password',
          username,
          password,
          scope: 'openid',
        }).toString(),
      }),
      async onQueryStarted(_arg, { queryFulfilled, dispatch }) {
        try {
          const { data } = await queryFulfilled;
          console.log({ dataFromKeyclockSlice: data })
          dispatch(setCredentials({
            accessToken: data.access_token,
            refreshToken: data.refresh_token ?? null,
          }));
        } catch (error) {
          console.error('Login failed:', error);
        }
      },
    }),
    refresh: mutation<TokenResponse, { refreshToken: string }>({
      query: ({ refreshToken }) => ({
        url: `/protocol/openid-connect/token`,
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: import.meta.env.VITE_KEYCLOAK_CLIENT_ID,
          ...(import.meta.env.VITE_KEYCLOAK_CLIENT_SECRET ? { client_secret: import.meta.env.VITE_KEYCLOAK_CLIENT_SECRET } : {}),
          grant_type: 'refresh_token',
          refresh_token: refreshToken,
        }).toString(),
      }),
      async onQueryStarted(_arg, { queryFulfilled, dispatch }) {
        const { data } = await queryFulfilled
        dispatch(setCredentials({ accessToken: data.access_token, refreshToken: data.refresh_token ?? null }))
      },
    }),
    userinfo: query<UserInfo, void>({
      query: () => ({ url: `/protocol/openid-connect/userinfo`, method: 'GET' }),
      async onQueryStarted(_arg, { queryFulfilled, dispatch }) {
        try {
          const { data } = await queryFulfilled
          dispatch(setUser(data))
        } catch {/* ignore */ }
      },
    }),
    signup: mutation<any, registerUserProps>({
      query: (body) => ({
        url: `${import.meta.env.VITE_API_PYTHON_BASE_URL}/keycloakMiddleware/v2/signup`,
        method: 'POST',
        body,
        headers: {
          'Content-Type': 'application/json',
        },
      }),
    })
  }),
})

export const {
  useLoginMutation,
  useRefreshMutation,
  useUserinfoQuery,
  useLazyUserinfoQuery,
  useSignupMutation
} = keyClockAPI
