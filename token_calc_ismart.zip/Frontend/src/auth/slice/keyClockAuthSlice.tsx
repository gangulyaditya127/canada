import { createSlice, PayloadAction, current } from '@reduxjs/toolkit';
type SolutionKey = `ARE_${string}`;
type Permission = 'download' | 'execute' | 'view' | 'edit';
type SolutionMap = Record<SolutionKey, Permission[]>;
export interface User extends Partial<SolutionMap> {
    sub: string;
    email_verified: boolean;
    name: string;
    preferred_username: string;
    given_name: string;
    family_name: string;
    email: string;
}
export type AuthState = {
    accessToken: string | null;
    refreshToken: string | null;
    user: User | null;
};
const STORAGE_KEY = '__tcs_are_auth__';
const load = (): AuthState => {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        return raw ? JSON.parse(raw) : { accessToken: null, refreshToken: null, user: null };
    } catch {
        return { accessToken: null, refreshToken: null, user: null };
    }
};
const persist = (state: AuthState) => {
    console.log({ persist: { state: current(state) } })
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(current(state)));
    } catch (err) {
        console.error('Persist error:', err);
    }
};
const keyClockAuthSlice = createSlice({
    name: 'auth',
    initialState: load(),
    reducers: {
        setCredentials: (state, action: PayloadAction<{ accessToken: string; refreshToken?: string | null }>) => {
            state.accessToken = action.payload.accessToken;
            if (typeof action.payload.refreshToken !== 'undefined') {
                state.refreshToken = action.payload.refreshToken;
            }
            persist(state);
        },
        setUser: (state, action: PayloadAction<User | null>) => {
            state.user = action.payload;
        },
        logout: (state) => {
            state.user = null;
            state.accessToken = null;
            state.refreshToken = null;
            persist(state);
        },
    },
});
export const { setCredentials, setUser, logout } = keyClockAuthSlice.actions;
export default keyClockAuthSlice.reducer;
export const selectAccessToken = (state: any) => (state.keyClockAuthSlice.accessToken as string | null)
export const selectRefreshToken = (state: any) => (state.keyClockAuthSlice.refreshToken as string | null)
export const selectUser = (state: any) => (state.keyClockAuthSlice.user as User | null)