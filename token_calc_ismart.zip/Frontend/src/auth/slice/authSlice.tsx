import {
  deteteFromLocal,
  loadStateFromLocal,
  saveStateToLocal,
} from "@/lib/local-storage.util";
import { createSlice } from "@reduxjs/toolkit";

export const loggedInUserDetails = () => {
  const userDetails = loadStateFromLocal("--_ism_log_u");
  return userDetails;
};

const initialState = {
  isLoggedIn: loggedInUserDetails() ? true : false,
  // isLoggedIn: true,
  role: loggedInUserDetails()?.role,
  // role: loggedInUserDetails()?.role  || "admin",
  isAdmin: loggedInUserDetails()?.isAdmin,
  // isAdmin: true,
  rawUserDetails: loggedInUserDetails()?.rawUserDetails,
  roleDetails: loggedInUserDetails()?.roleDetails
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    updateLoginStatus: (state, action) => {
      state.isLoggedIn = action.payload.isLoggedIn;
      const userName = action.payload.userName;
      const role = action.payload.role ?? null
      const isAdmin = action.payload.isAdmin
      const rawUserDetails = action.payload.rawUserDetails
      state.rawUserDetails = rawUserDetails
      action.payload.isLoggedIn
        ? saveStateToLocal({ user: userName, role, isAdmin, rawUserDetails }, "--_ism_log_u")
        : deteteFromLocal("--_ism_log_u");
    },
    updateRole: (state, action) => {
      state.role = action.payload.role
      state.isLoggedIn = true
      let oldData = loadStateFromLocal('--_ism_log_u')
      console.log({ user: oldData.user, role: action.payload.role, ...oldData })
      saveStateToLocal({ user: oldData.user, role: action.payload.role, rawUserDetails: oldData?.rawUserDetails }, "--_ism_log_u")
    },
    updateFPARole: (state, action) => {
      state.roleDetails = action.payload.roleDetails
      saveStateToLocal({ roleDetails: action.payload.roleDetails }, "--_fpa_log_u")
    }
  },
});

export const { updateLoginStatus, updateRole, updateFPARole } = authSlice.actions;

export default authSlice.reducer;
