import { createHashRouter } from "react-router-dom"; //createHashRouter
import App from "./App";

import ErrorFallback from "./components/ux/ErrorFallback";
import { baseRoutes } from "./routes/base.routs";
import { tokenCalculatorRoute } from "./routes/are-token_calculator.route";

export const router = createHashRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <ErrorFallback />,
    // ErrorBoundary,
    children: [
      ...baseRoutes,
      ...tokenCalculatorRoute,
    ],
  },
]);