declare global {
  interface Window {
    umami?: {
      track: (eventName: string | object, eventData?: object) => void;
      identify: (userId: string | object, userData?: object) => void;
      isLoaded?: boolean;
    };
  }
}

export {};