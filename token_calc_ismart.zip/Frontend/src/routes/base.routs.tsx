import { RouteObject } from "react-router-dom";
import { Suspense } from "react";
import Login from "@/auth/Login";
import Logout from "@/auth/Logout";
import SignUp from "@/auth/SignUp";
export const baseRoutes: RouteObject[] = [
    {
        path: 'login',
        element: (<Suspense fallback="">
            <Login />
        </Suspense>)
    },
    {
        path: 'logout',
        element: <Logout />
    },
    {
        path: 'sign-up',
        element: (<Suspense fallback="">
            <SignUp />
        </Suspense>)
    },
];

