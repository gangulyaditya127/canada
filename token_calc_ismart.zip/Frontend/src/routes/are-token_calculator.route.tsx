import CanPerformTokenCalculatorRouteGuard from "@/application/token_calculator/auth/CanPerformTokenCalculator";
import CanViewTokenCalculator from "@/application/token_calculator/auth/CanViewTokenCalculator";
import TokenUnauthorized from "@/application/token_calculator/pages/TokenUnauthorised";
import TokenCalculatorLayout from "@/application/token_calculator/TokenCalculatorLayout";


import { lazy, Suspense } from "react";
import { RouteObject } from "react-router-dom";

const CalculatorPage = lazy(() => import("@/application/token_calculator/pages/index"));
const DeveloperPage = lazy(() => import("@/application/token_calculator/pages/developer"));
const PricingPage = lazy(() => import("@/application/token_calculator/pages/pricing"));
const ModelSelectionPage = lazy(() => import("@/application/token_calculator/pages/model_selection"));

export const tokenCalculatorRoute: RouteObject[] = [
    {
        path: "",
        element: (
            <Suspense fallback="">
                <TokenCalculatorLayout />
            </Suspense>
        ),
        children: [
            {
                path: "unauthorized",
                element: (
                    <Suspense fallback="">
                        <TokenUnauthorized />
                    </Suspense>
                ),
            },
            {
                path: "",
                element: <CanViewTokenCalculator unauthorizedRoute="unauthorized" />,
                children: [
                    {
                        index: true,
                        element: (
                            <Suspense fallback="">
                                <CalculatorPage />
                            </Suspense>
                        ),
                    },

                    {
                        path: "pricing",
                        element: (
                            <Suspense fallback="">
                                <PricingPage />
                            </Suspense>
                        ),
                    },
                    {
                        path: "model-selection",
                        element: (
                            <Suspense fallback="">
                                <ModelSelectionPage />
                            </Suspense>
                        ),
                    },

                    {
                        path: "developer",
                        element: (
                            <CanPerformTokenCalculatorRouteGuard unauthorizedRoute="unauthorized" />
                        ),
                        children: [
                            {
                                index: true,
                                element: (
                                    <Suspense fallback="">
                                        <DeveloperPage />
                                    </Suspense>
                                ),
                            },
                        ],
                    },
                ],
            },
        ],
    },
];