import Container from "../ui/container";
import TCS_LOGO from "@/assets/logo/tcs-logo-1.svg";
import { useTranslation } from "react-i18next";
function Footer() {
  const { t } = useTranslation('ismartHome')
  return (
    <footer className="align-center dark flex h-[55px] flex-col justify-center bg-black">
      <Container className="items-center flex justify-center">
        <div className="">
          <img src={TCS_LOGO} alt="" className="h-12 w-auto" height={48} width={144}/>
        </div>
        <div className="ml-auto text-xs text-neutral-100">
        {t('footer.title')} {t('footer.release')}: 0.1 | ©2025 {t('footer.subTitle')}
        </div>
      </Container>
    </footer>
  );
}

export default Footer;
