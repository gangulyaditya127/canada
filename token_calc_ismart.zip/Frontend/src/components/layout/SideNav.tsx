import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
  TooltipProvider,
} from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { useAppSelector } from "@/lib/redux/hooks";
import {
  SideBarNavData,
  SideBarNavElement,
  SideBarNavElementGroup,
} from "./slice/sidebar-navigation";
import { Icon } from "../ui/icon";
import { Link, NavLink } from "react-router-dom";
import { cn } from "@/lib/tailwind.utils";
import TCS_LOGO_SQ_WHITE from '@/assets/logo/tcs_logo_1_white_crop (2).png'
import TCS_LOGO_SQ_BLACK from '@/assets/logo/tcs_logo_1_black_crop.png'

export function SideNav() {
  const sideBarData: SideBarNavData = useAppSelector((state) => state.sideNav);
  return (
    <aside className="inset-y fixed left-0 z-20 flex h-full flex-col border-r">
      <div className="border-b p-2">
        <Link to="/">
          <Button variant="ghost" size="icon" aria-label="Home">
            <img src={TCS_LOGO_SQ_WHITE} alt="" className="w-7 hidden dark:inline-block"/>
            <img src={TCS_LOGO_SQ_BLACK} alt="" className="w-7 dark:hidden inline-block"/>
          </Button>
        </Link>
      </div>
      {sideBarData?.sideBarNavList.map(
        ({ group, groupList }: SideBarNavElementGroup) => (
          <nav className="grid gap-1 p-2" key={group}>
            <TooltipProvider>
              {groupList?.map(
                ({ content, key, icon, route }: SideBarNavElement) => (
                  <Tooltip key={key}>
                    <TooltipTrigger asChild>
                      <NavLink to={route}>
                        {(
                          { isActive }, //isPending, isTransitioning <-- extra two parameters
                        ) => (
                          <Button
                            variant="ghost"
                            size="icon"
                            className={cn(
                              "rounded-lg",
                              isActive ? "bg-muted" : "",
                            )}
                            aria-label={content}
                          >
                            <Icon name={icon} className="size-5" />
                          </Button>
                        )}
                      </NavLink>
                    </TooltipTrigger>
                    <TooltipContent side="right" sideOffset={5}>
                      {content}
                    </TooltipContent>
                  </Tooltip>
                ),
              )}
            </TooltipProvider>
          </nav>
        ),
      )}
      <nav className="mt-auto grid gap-1 p-2">
        <TooltipProvider>
          {sideBarData?.bottomNavList?.map(
            ({ content, key, icon, route }: SideBarNavElement) => (
              <Tooltip key={key}>
                <TooltipTrigger asChild>
                  <NavLink to={route}>
                    {(
                      { isActive }, //isPending, isTransitioning <-- extra two parameters
                    ) => (
                      <Button
                        variant="ghost"
                        size="icon"
                        className={cn("rounded-lg", isActive ? "bg-muted" : "")}
                        aria-label={content}
                      >
                        <Icon name={icon} className="size-5" />
                      </Button>
                    )}
                  </NavLink>
                </TooltipTrigger>
                <TooltipContent side="right" sideOffset={5}>
                  {content}
                </TooltipContent>
              </Tooltip>
            ),
          )}
        </TooltipProvider>
      </nav>
    </aside>
  );
}
