
import { useState } from "react";

type SiteConfig = {
    id: number | string,
    group: string,
    list: {
        displayText: string;
        key: number | string;
        openInNew: boolean;
        route: string;
        description: string;
        icon: React.ReactNode;
    }[]
}[]

export const useSiteConfig = () => {
    const [siteConfig] = useState<SiteConfig>([])

    return siteConfig
}