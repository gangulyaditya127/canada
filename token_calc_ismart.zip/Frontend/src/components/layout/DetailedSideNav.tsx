const DetailedSideNav = () => {
  return (
    <div className="">
      <div className="flex cursor-pointer flex-col gap-2 text-nowrap text-muted-foreground">
        <p className="font-medium text-foreground">Point of View</p>
        <div className="flex flex-col gap-1 pl-6">
          <p>Incident Management</p>
          <p>Risk Management</p>
          <p>App Management</p>
        </div>
      </div>
    </div>
  );
};
export default DetailedSideNav;
