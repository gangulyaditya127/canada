import { createSlice } from "@reduxjs/toolkit";

export interface TopNavItem {
  key: string;
  content: string;
  route: string;
}

const initialState: {
  navList: TopNavItem[];
  isIsmartHome: boolean;
  isAMSHome: boolean;
  isAMS?: boolean;
  className?:string;
} = {
  navList: [],
  isIsmartHome: false,
  isAMSHome: false,
  isAMS: false,
  className:''
};

const topBarNavigationSlice = createSlice({
  name: "topbar-navigation",
  initialState,
  reducers: {
    updateTopNavigation: (state, action) => {
      (state.navList = action.payload.navList);
      (state.isIsmartHome = action.payload.isIsmartHome);
      state.isAMSHome = action.payload.isAMSHome;
      state.isAMS = action.payload.isAMS;
      state.className=action.payload.className
    },
  },
});

export const { updateTopNavigation } = topBarNavigationSlice.actions;

export default topBarNavigationSlice.reducer;
