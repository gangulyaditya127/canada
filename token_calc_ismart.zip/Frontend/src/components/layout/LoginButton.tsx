import { LogIn } from "lucide-react";
import { Link } from "react-router-dom";
import { HoverBorderGradient } from "../ui/hover-border-button";

export const LoginButton = () => {
  return (
    <Link to="/login" className="flex h-full items-center">
      <HoverBorderGradient
        containerClassName="rounded-lg p-[1px]"
        as="button"
        className="bg-black text-white flex items-center space-x-2 py-1"
      >
        <span>Login</span>
        <LogIn className="size-[15px]" />
      </HoverBorderGradient>
      {/* <button className="relative inline-flex h-[30px] w-24 overflow-hidden rounded-lg p-[1px] focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 focus:ring-offset-slate-50">
        <span className="absolute inset-[-1000%] animate-[spin_2s_linear_infinite] bg-[conic-gradient(from_90deg_at_50%_50%,#DBEAFE_0%,#2563EB_50%,#DBEAFE_100%)]" />
        <span className="inline-flex h-full w-full cursor-pointer items-center justify-center gap-1 rounded-lg bg-neutral-950 px-3 text-sm text-white backdrop-blur-3xl">
          <span>Login</span>
          <LogIn className="size-[15px]" />
        </span>
      </button> */}
    </Link>
  );
};
