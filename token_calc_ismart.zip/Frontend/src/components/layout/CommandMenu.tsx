import { useState, useEffect, useCallback } from "react";
import { Search, SunIcon, MoonIcon, LaptopIcon } from "lucide-react";
import { cn } from "@/lib/tailwind.utils";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";
import { useNavigate } from "react-router-dom";
import { useSiteConfig } from "./hooks/useSiteConfig";

export function CommandMenu({ className }: { className?: string }) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const { setTheme } = useTheme();
  const siteConfig = useSiteConfig();

  const runCommand = useCallback(
    (command: () => unknown) => {
      setOpen(false);
      command();
    },
    [open],
  );

  // FIX: Extracted the routing logic to a separate function to prevent deep nesting
  const handleCommandSelect = useCallback(
    (route?: string, openInNew?: boolean) => {
      runCommand(() => {
        if (openInNew) {
          window.open(route, "_blank");
        } else {
          navigate(route ?? ".");
        }
      });
    },
    [navigate, runCommand]
  );

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };

    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  return (
    <div className="flex items-center">
      <Button
        variant="ghost"
        className={cn(` ml-auto h-10 w-10 rounded-full `, className)}
        onClick={() => setOpen(true)}
      >
        <Search className="h-5 w-5 shrink-0 text-primary" />
      </Button>
      <p className="text-sm text-muted-foreground">
        Press{" "}
        <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100">
          <span className="text-xs">⌘</span>K
        </kbd>
      </p>
      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Type a command or search..." />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>
          
          {siteConfig.map(({ group, id, list }) => (
            <div key={id}>
              <CommandGroup heading={group}>
                {list.map(({ icon, displayText, key, route, openInNew }) => (
                  <CommandItem
                    key={key}
                    value={`${displayText}_${route}`}
                    // FIX: Replaced the deeply nested callbacks with our new handler
                    onSelect={() => handleCommandSelect(route, openInNew)}
                  >
                    {icon}
                    <span>{displayText}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
              <CommandSeparator />
            </div>
          ))}

          <CommandGroup heading="Theme">
            <CommandItem onSelect={() => runCommand(() => setTheme("light"))}>
              <SunIcon className="mr-2 h-4 w-4" />
              Light
            </CommandItem>
            <CommandItem onSelect={() => runCommand(() => setTheme("dark"))}>
              <MoonIcon className="mr-2 h-4 w-4" />
              Dark
            </CommandItem>
            <CommandItem onSelect={() => runCommand(() => setTheme("system"))}>
              <LaptopIcon className="mr-2 h-4 w-4" />
              System
            </CommandItem>
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </div>
  );
}