import { APP_LIST } from "./APP_LIST";
import {
  caseStudiesComponent,
  frameWorkComponent,
  offeringsComponent,
  onboardingComponents,
  transformComponent,
} from "./navigation.dropdown.data";
import { Icon } from "@/components/ui/icon";
export const SITE_CONFIG = [
  {
    id: 1,
    group: "Application",
    list: APP_LIST.map((el)=>{
      return ({...el,icon: <Icon name={el.icon} className="mr-2" />})
    }),
  },
  {
    id: 2,
    group: "Offerings ",
    list: offeringsComponent.map((el, i) => ({
      icon: <Icon name="circle-dot-dashed" className="mr-2" />,
      displayText: el.title,
      description: el.description,
      route: el.href,
      openInNew: false,
      key: i,
    })),
  },
  {
    id: 3,
    group: "Onboard ",
    list: onboardingComponents.map((el, i) => ({
      icon: <Icon name="circle-dot-dashed" className="mr-2" />,
      displayText: el.title,
      description: el.description,
      route: el.href,
      openInNew: false,
      key: i,
    })),
  },
  
  {
    id: 5,
    group: "Transform ",
    list: transformComponent.map((el, i) => ({
      icon: <Icon name="circle-dot-dashed" className="mr-2" />,
      displayText: el.title,
      description: el.description,
      route: el.href,
      openInNew: false,
      key: i,
    })),
  },
  {
    id: 6,
    group: "Frameworks ",
    list: frameWorkComponent.map((el, i) => ({
      icon: <Icon name="circle-dot-dashed" className="mr-2" />,
      displayText: el.title,
      description: el.description,
      route: el.href,
      openInNew: false,
      key: i,
    })),
  },
  {
    id: 7,
    group: "Case Studies",
    list: caseStudiesComponent.map((el, i) => ({
      icon: <Icon name="circle-dot-dashed" className="mr-2" />,
      displayText: el.title,
      description: el.description,
      route: el.href,
      openInNew: false,
      key: i,
    })),
  },
];
