import { IconNameProp } from "@/components/ui/icon";

export const ISMART_DOCS: {
    title: string;
    key: number;
    openInNew: boolean;
    href: string;
    description: string;
    icon?: IconNameProp; 
  }[] = [
    {
      title: "Integrated Change Review Management", 
      href: "/doc/icrm",
      key: 1, 
      openInNew: false,
      icon: "replace",
      description:
        "Change with confidence, prevent downtime, streamline reviews.",
    },
    {
      title: "Intelligent Resolution Recommender",
      description:
        "Resolve faster, smarter. Your ticket-solving copilot.",
      key: 2,
      href: "/doc/irr",
      icon: "bot",
      openInNew: false,
    },
    {
      title: "Gamification",
      href: "/doc/gamification",
      key: 3,
      icon: "gamepad-2",
      openInNew: false,
      description: "Unleash your inner hero. Boost productivity & teamwork.",
    },
    {
      title: "Integrated Application Dependency Dashboard",
      href: "/doc/iadd",
      key: 4,
      icon: "network",
      openInNew: false,
      description:
        "Unravel dependencies. Fix faster.  Illuminate application & infrastructure dependencies.",
    },
    {
      title: "Integrated Project Risk Management​",
      href: "/doc/iprm",
      icon: "square-asterisk",
      key: 5,
      openInNew: false,
      description:
        "Web based solution with workflow tracking mechanism to complete POA(Project Onboarding Assessment) or PRA(Project Risk Assesment) of new projects",
    },
    {
      title: "Daily Application Health Check",
      href: "/doc/dahc",
      key: 6,
      icon: "heart-pulse",
      openInNew: false,
      description: "Real time status of application health check.",
    },
    {
      title: "L1 Dashboard",
      href: "/doc/l1-dashboard",
      key: 7,
      icon: "layout-dashboard",
      openInNew: false,
      description:
        "Realtime status of incidents, MIM(Major Incident Management), change requests along with accountability matric, 13 months’ trend, LOB(Line of Business) & Country wise impact",
    },
    {
      title: "Automated Certificate Management",
      href: "/doc/icert",
      icon: "shield-check",
      key: 77,
      openInNew: false,
      description:
        "Latest status of certificates being used in production ensuring RAG(Red, Amber, Green) status highlights upcoming certificate expiry. Month wise expiry depiction coupled with LOB(Line of Business) wise view",
    },
    {
      title: "Batch Health Analyzer",
      href: "/doc/batch-status",
      icon: "file-pie-chart",
      key: 8,
      openInNew: false,
      description:
        "Realtime batch status dashboard displaying current status of every batch along with errors occurred, disk space utilization status, card transaction status etc.",
    },
    {
      title: "Global Planner",
      href: "/doc/global-planner",
      icon: "notebook-pen",
      key: 9,
      openInNew: false,
      description:
        "Handy list of upcoming planned global events like major releases, EOVS(End Of Version Support), monthly release dates etc.",
    },
    {
      title: "Intelligent Major Incident Briefing Paper",
      href: "/doc/imbp",
      icon: "layout-dashboard",
      key: 10,
      openInNew: false,
      description:
        "Dashboard highlighting severity based MIM(Major Incident Management) count along with causal analysis with drill down capability to identify resolution",
    },
    {
      title: "Regulatory Data Lineage Dashboard",
      href: "/doc/regulatory",
      icon: "package-check",
      key: 11,
      openInNew: false,
      description:
        "Reduce email and ticket volume by keeping stakeholders updated on real time basis.",
    },
    {
      title: "Capture Hidden Knowledge",
      href: "/doc/knowledge-management",
      key: 132,
      icon: "book-open-check",
      openInNew: false,
      description:
        "Capture the missing knowledge using our GenAI(Generative Artificial Intelligence) based Chatbot",
    },
    {
      title: "New Application Onboarding",
      href: "/doc/nao",
      key: 12,
      icon: "app-window-mac",
      openInNew: false,
      description:
        "Criticality, complexity & size estimation of a new application getting on boarded along with other rich features such as effort estimation, DD(Dependenncy Diagram) dube generation etc.",
    },
    {
      title: "Effort Calculator​",
      href: "/doc/iprompt",
      icon: "terminal",
      key: 112,
      openInNew: false,
      description:
        "Effort estimation of applications in production, with gap analysis between estimated & actual support resources.",
    },
    {
      title: "Intelligent SLA management​",
      href: "/doc/isla",
      icon: "terminal",
      key: 113,
      openInNew: false,
      description:
        "A comprehensive solution for intelligent SLA(Service Level Agreement) management, enabling organizations to proactively monitor and enforce service agreements, ultimately leading to improved service delivery and reduced operational costs",
    },
    {
      title: "Bots Family​",
      href: "/doc/bots",
      icon: "bot",
      key: 112,
      openInNew: false,
      description:
        "A collaborative bot family leverages multiple bots to intelligently assign tickets, enrich tickets with log data, perform automatic root cause analysis",
    },
  ];