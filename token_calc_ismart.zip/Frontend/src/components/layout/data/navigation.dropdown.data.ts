export const onboardingComponents: {
  title: string;
  href: string;
  description: string;
}[] = [
  {
    title: "Estimators",
    href: "/doc/estimators",
    description: "Streamline the process of estimating the effort",
  },
  {
    title: "Transition Planner / Digital DD Cube",
    href: "/doc/transition-planner",
    description:
      "Facilitate smooth transitions and due diligence (DD) processes during digital transformations, ensuring comprehensive planning and execution for production management.",
  },
  {
    title: "Intelligent Knowledge Onboarder",
    href: "/doc/konboard",
    description: "TCS Intelligent Knowledge Based Onboarding platform",
  },
  {
    title: "Intelligent Knowledge Builder",
    href: "/doc/intellegient-knowledge-builder",
    description: "Automated documentation with enhanced accessibility",
  },
];

export const transformComponent: {
  title: string;
  href: string;
  description: string;
}[] = [
  {
    title: "RiO Assessment Questionnaire",
    href: "/doc/rio-assessment",
    description:
      "End to end digitized assessment platform which helps production support engagement",
  },
  {
    title: "RiO Automation Maturity Workbench",
    href: "/doc/rio-automation-maturity",
    description:
      "It assesses the extent of automation adoption in AMS engagements.",
  },
  {
    title: "TCS ITSM Analytics",
    href: "/doc/service-clinic",
    description: "Advanced analytics tool that analyzes the ITSM ticket logs",
  },
  {
    title: "Lean Assessor",
    href: "/doc/lean-accessor",
    description:
      "Systematically analyze AMS teams from people and process dimensions.",
  },
];
export const frameWorkComponent: {
  title: string;
  href: string;
  description: string;
}[] = [
  {
    title: "POV on Next Gen AMS Trends and Implications",
    href: "/doc/pov",
    description: "A comprehensive documentation related to Next Gen AMS",
  },
  {
    title: "Service Risk Assessment Framework",
    href: "/doc/service-risk-assessment",
    description:
      "Proactively identify, evaluate, and mitigate risks associated with service delivery and application management",
  },
  {
    title: "Next Gen AMS Process Handbooks",
    href: "/doc/handover-workbook",
    description:
      "A set of process guidelines/handbook has been prepared to assist accounts in embracing concepts of Next Gen AMS model.",
  },
  {
    title: "AMS Career & Learning Builder.",
    href: "/doc/ams-carrer",
    description:
      "Support the continuous professional development and career progression of AMS professionals",
  },
];
export const caseStudiesComponent: {
  title: string;
  href: string;
  description: string;
}[] = [
  {
    title: "Success Stories",
    href: "/doc/success-story",
    description:
      "Dive into our Success Stories section, where we highlight the remarkable achievements of our clients using the Next Gen AMS framework",
  },
  {
    title: "Transforming IT operations hrough SRE",
    href: "/doc/sre",
    description:
      "To transform the traditional IT Ops function into SRE based function without having huge disruption. The proposed operating model, is aimed to identify Key SME’s from L2 Organization and train them on the SRE Ways of Working and then eventually transform the remaining L2 Layer into SRE based organization over period",
  },
  {
    title: "Transforming RTB through strategic observability adoption",
    href: "/doc/rtb",
    description:
      "Self-service portal which provides users with information on monitoring meta-data.",
  },
  {
    title: "Intelligent Conversational Assistant",
    href: "/doc/tqs",
    description:
      "Self-service portal which provides users with information on monitoring meta-data.",
  },
];
export const offeringsComponent: {
  title: string;
  href: string;
  description: string;
}[] = [
  {
    title: "Application Reliability Engineering",
    href: "/doc/ismart-catalog",
    description:
      "Explore the full range of modules and offerings provided by Application Reliability Engineering",
  },
  {
    title: "About TCS Next Gen AMS Framework",
    href: "/doc/about",
    description:
      "Discover the TCS Next Gen AMS (Application Management Services) framework, a comprehensive suite of methodologies, tools, and best practices designed to transform your application management processes.",
  },
  {
    title: "How can we help you",
    href: "/doc/how-can-we-help",
    description: "",
  },
];

