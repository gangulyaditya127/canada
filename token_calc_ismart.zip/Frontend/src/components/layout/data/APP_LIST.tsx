import { IconNameProp } from "@/components/ui/icon";

export const APP_LIST:{
  displayText: string;
  key: number;
  openInNew: boolean;
  route: string;
  description: string;
  icon: IconNameProp;
}[]  = [ 
  {
    icon: "replace",
    displayText: "Integrated Change Review Management", 
    route: "/icrm",
    key: 1,
    openInNew: false,
    description:
      "Change with confidence, prevent downtime, streamline reviews.",
  },
  {
    icon: "bot",
    displayText: "Intelligent Resolution Recommender",
    description:
      "Resolve faster, smarter. Your ticket-solving copilot.",
    key: 2,
    route: "/irr",
    openInNew: false,
  },
  {
    icon: "gamepad-2",
    displayText: "Gamification",
    route: "/gamification-onboard",
    key: 3,
    openInNew: false,
    description: "Unleash your inner hero. Boost productivity & teamwork.",
  },
  {
    icon: "network",
    displayText: "Integrated Application Dependency Dashboard",
    route: "/iadd",
    key: 4,
    openInNew: false,
    description:
      "Unravel dependencies. Fix faster.  Illuminate application & infrastructure dependencies.",
  },
  {
    icon: "square-asterisk",
    displayText: "Integrated Project Risk Management​",
    route: "/coming-soon",
    key: 5,
    openInNew: false,
    description:
      "Web based solution with workflow tracking mechanism to complete POA(Project Onboarding Assessment) or PRA(Project Risk Assesment) of new projects",
  },
  {
    icon: "heart-pulse",
    displayText: "Daily Application Health Check",
    route: "/coming-soon",
    key: 6,
    openInNew: false,
    description: "Real time status of application health check.",
  },
  {
    icon: "layout-dashboard",
    displayText: "L1 Dashboard",
    route: "/coming-soon",
    key: 7,
    openInNew: false,
    description:
      "Realtime status of incidents, MIM(Major Incident Management), change requests along with accountability matric, 13 months’ trend, LOB(Line of Business) & Country wise impact",
  },
  {
    icon: "shield-check",
    displayText: "Automated Certificate Management",
    route: "/coming-soon",
    key: 17,
    openInNew: false,
    description:
      "Latest status of certificates being used in production ensuring RAG(Red, Amber, Green) status highlights upcoming certificate expiry. Month wise expiry depiction coupled with LOB(Line of Business) wise view",
  },
  {
    icon: "file-pie-chart",
    displayText: "Batch Health Analyzer",
    route: "/coming-soon",
    key: 8,
    openInNew: false,
    description:
      "Realtime batch status dashboard displaying current status of every batch along with errors occurred, disk space utilization status, card transaction status etc.",
  },
  {
    icon: "notebook-pen",
    displayText: "Global Planner",
    route: "/coming-soon",
    key: 9,
    openInNew: false,
    description:
      "Handy list of upcoming planned global events like major releases, EOVS(End Of Version Support), monthly release dates etc.",
  },
  {
    icon: "layout-dashboard",
    displayText: "Intelligent Major Incident Briefing Paper",
    route: "/coming-soon",
    key: 10,
    openInNew: false,
    description:
      "Dashboard highlighting severity based MIM(Major Incident Management) count along with causal analysis with drill down capability to identify resolution",
  },
  {
    icon: "package-check",
    displayText: "Regulatory Data Lineage Dashboard",
    route: "/coming-soon",
    key: 11,
    openInNew: false,
    description:
      "Reduce email and ticket volume by keeping stakeholders updated on real time basis.",
  },
  {
    icon: "book-open-check",
    displayText: "Capture Hidden Knowledge",
    route: "/coming-soon",
    key: 12,
    openInNew: false,
    description:
      "Capture the missing knowledge using our GenAI(Generative Artificial Intelligence) based Chatbot",
  },
  {
    icon: "app-window-mac",
    displayText: "New Application Onboarding",
    route: "/coming-soon",
    key: 122,
    openInNew: false,
    description:
      "Criticality, complexity & size estimation of a new application getting on boarded along with other rich features such as effort estimation, DD(Dependenncy Diagram) dube generation etc.",
  },
  {
    icon: "terminal",
    displayText: "Effort Calculator​",
    route: "/coming-soon",
    key: 1212,
    openInNew: false,
    description:
      "Effort estimation of applications in production, with gap analysis between estimated & actual support resources",
  },
  {
    displayText: "Intelligent SLA management​",
    route: "/islam",
    icon: "terminal",
    key: 112,
    openInNew: false,
    description:
      "A comprehensive solution for intelligent SLA(Service Level Agreement) management, enabling organizations to proactively monitor and enforce service agreements, ultimately leading to improved service delivery and reduced operational costs",
  },
];
