import { CircleUser, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ModeToggle } from "@/components/theme/ModeToggle.tsx";
import { CommandMenu } from "@/components/layout/CommandMenu";
import { Link, NavLink } from "react-router-dom";
import { cn } from "@/lib/tailwind.utils";
import { useAppSelector } from "@/lib/redux/hooks";
import { TopNavItem } from "./slice/topbar-navigation";
import TATA_LOGO from "@/assets/logo/tata-logo-1.svg";
import ARE_LOGO_WHITE from '@/assets/logo/TCS Application Reliability Engineering_White.png'
import { Suspense, lazy, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Skeleton } from "../ui/skeleton";
import { LoginButton } from "./LoginButton";
const AMSShiftDropdown = lazy(() => import("./AMSShiftDropdown"));
export function TopNav({
  hasSideBar,
}: {
  hasSideBar?: boolean;
  className?: string;
}) {
  const { t, ready, i18n } = useTranslation('common')
  const {
    navList: topNavItemList,
    isIsmartHome,
    isAMSHome,
    className: topNavStoreClass
  } = useAppSelector((state) => state.topNav);
  const [appName, setAppName] = useState('')
  useEffect(() => {
    if (ready) {
      setAppName(t('ismartName'))
    }
  }, [i18n.language])

  const userDetails = useAppSelector((state) => state.keyClockAuthSlice.user)

  return (
    <div
      className={cn(
        "sticky top-0 z-50 flex h-[57px] border-b border-border",
        isIsmartHome || isAMSHome
          ? "dark fixed left-0 right-0 bg-black/90 backdrop-blur"
          : "bg-background/98 backdrop-blur supports-[backdrop-filter]:bg-background/60",
        topNavStoreClass
      )}
    >
      <header
        className={cn(
          "flex grow items-center gap-4 px-4",
          hasSideBar ? "border-l" : "",
        )}
      >
        {!hasSideBar && (
          <div className="h-full flex items-center">
            <Link to={import.meta.env.VITE_APP_BASE_URL} className="flex items-center font-semibold">
              <img src={ARE_LOGO_WHITE} alt="ARE logo" width={198.27} height={36} className="h-9" />
              {/* ARE */}
            </Link>
          </div>
        )}
        <nav className="hidden gap-2 md:flex md:flex-row md:items-center md:text-sm">
          {hasSideBar && (
            <div className="flex">
              <NavLink
                to={import.meta.env.VITE_APP_BASE_URL}
                className={({ isActive }) =>
                  cn(
                    "transition-colors hover:text-foreground",
                    isActive ? "text-foreground" : "text-muted-foreground",
                  )
                }
              >
                {appName}
              </NavLink>
              <div className="mx-2 text-muted-foreground">/</div>
              <NavLink
                to={`${import.meta.env.VITE_APP_BASE_URL}/#/operate`}
                className={({ isActive }) =>
                  cn(
                    "transition-colors hover:text-foreground",
                    isActive ? "text-foreground" : "text-muted-foreground",
                  )
                }
              >
                {"Experience Zone"}
              </NavLink>
              {topNavItemList?.length > 0 ? (
                <div className="ml-2 text-muted-foreground">/</div>
              ) : (
                ""
              )}
            </div>
          )}
          <div className="flex-col gap-6 text-lg font-medium md:flex md:flex-row md:items-center md:gap-5 md:text-sm lg:gap-6">
            {topNavItemList?.map(({ content, key, route }: TopNavItem) => (
              <NavLink
                to={route}
                key={key}
                className={({  }) => //isActive
                  cn(
                    "text-muted-foreground transition-colors hover:text-foreground",
                    true ? "text-foreground" : "text-muted-foreground",
                  )
                }
              >
                {content}
              </NavLink>
            ))}
            {(isAMSHome || isIsmartHome) && (
              <div className="ml-1">
                <Suspense fallback={(
                  <div className="relative flex h-fit gap-4">
                    <Skeleton className="bg-neutral-800 h-9 w-[100px] rounded-full" />
                    <Skeleton className="bg-neutral-800 h-9 w-[100px] rounded-full" />
                    <Skeleton className="bg-neutral-800 h-9 w-[90px] rounded-full" />
                    <Skeleton className="bg-neutral-800 h-9 w-[120px] rounded-full" />
                    <Skeleton className="bg-neutral-800 h-9 w-[120px] rounded-full" />
                    <Skeleton className="bg-neutral-800 h-9 w-[100px] rounded-full" />
                  </div>
                )}>
                  <AMSShiftDropdown />
                </Suspense>
              </div>
            )}
          </div>
        </nav>
        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="outline"
              size="icon"
              className="shrink-0 md:hidden"
            >
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle navigation menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <nav className="grid gap-6 text-lg font-medium">
              <NavLink
                to="/"
                className={({ isActive }) =>
                  cn(
                    "transition-colors hover:text-foreground",
                    isActive ? "text-foreground" : "text-muted-foreground",
                  )
                }
              >
                iSmart
              </NavLink>
              {topNavItemList?.map(({ content, key, route }: TopNavItem) => (
                <NavLink
                  to={route}
                  key={key}
                  className="text-muted-foreground transition-colors hover:text-foreground"
                >
                  {content}
                </NavLink>
              ))}
            </nav>
          </SheetContent>
        </Sheet>
        <div className="ml-auto flex items-center gap-4 md:gap-2 lg:gap-4">
          <div className="flex gap-1 items-center">
            <CommandMenu />
            <ModeToggle
              className={isIsmartHome || isAMSHome ? "text-white" : ""}
            />
            {userDetails?.email ? <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full text-white" >
                  <CircleUser className="h-5 w-5" />
                  <span className="sr-only">Toggle user menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem className='flex flex-col items-start'>
                  <div className="text-md">{userDetails?.email}</div>
                  <div className="text-muted-foreground">{userDetails?.preferred_username}</div>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Link to='/logout' className="w-full">Logout</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu> : <LoginButton />}
            {/* <LanguageToggle /> */}
          </div>
          <img
            src={TATA_LOGO}
            alt="Tata"
            className={`size-10 invert dark:hidden`}
          />
          <img
            src={TATA_LOGO}
            alt="Tata"
            className={`hidden size-10 dark:block`}
          />

        </div>
      </header>
    </div>
  );
}
