import React, { useEffect, useMemo, useState } from "react";
import { ChevronDown } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { Link } from "react-router-dom";
import { cn } from "@/lib/tailwind.utils";
import { Button } from "../../../src/components/ui/button";
import { Icon } from "../../../src/components/ui/icon";
import { useTranslation } from "react-i18next";
import { useAppSelector } from "@/lib/redux/hooks";

type OfferingTabContentProps = {
  itemList: itemListProp;
};

const OfferingTabContent: React.FC<OfferingTabContentProps> = ({ itemList }) => {
  return <SingleColDropDownContent itemList={itemList} />;
};

const AMSShiftDropdown = () => {
  const { ready, t, i18n } = useTranslation('next-gen-ams/AMSDropdown')
  // const { ready: r, t: operateT } = useTranslation('ismart_app_operate')

  const rawUserDetails = useAppSelector((state) => state.auth.rawUserDetails);

  const offeringItemList =
    (t("offeringComponent.content", { returnObjects: true }) as itemListProp) ?? [];
  const TAB_GROUP = useMemo(() => {


    return (
      [
        {
          tab: [
            {
              id: 1,
              title: t("offeringComponent.title"),
              Component: OfferingTabContent,
              componentProps: {
                itemList: offeringItemList,
              },
              hasContent: true,
            },
            {
              id: 2,
              title: "Docs Vault",
              Component: () => null,
              hasContent: false,
              href: `${import.meta.env.VITE_APP_BASE_URL}/#/doc/vault`
            },
            // {
            //   id: 3,
            //   hasContent: hasGenAIAccess,
            //   title: "Agentic ARE",
            //   Component: hasGenAIAccess ? () => <SingleColDropDownContent
            //     itemList={AGENTIC_ARE_SOLN}
            //   /> : () => null,
            //   href: '/agentic-are'
            // },
          ],
        },
        {
          tab: [
            {
              id: 4,
              title: "Experience Zone",
              Component: IsmartDropdownContent,
              hasContent: true,
            },
          ],
        },
        {
          tab: [
            // {
            //   id: 5,
            //   hasContent: true,
            //   title: "ARE Infra Ops",
            //   Component: () => null,
            //   // href: '/doc/one-engine'
            // },
            // {
            //   id: 6,
            //   title: t('caseStudiesComponent.title'),
            //   Component: () => null,
            //   hasContent: false,
            //   href: '/doc/case-study'
            // },
            {
              id: 7,
              hasContent: false,
              title: t('ARE Quick Assesment'),
              Component: () => null,
              //( <HelpsubContent itemList={(t("help.content", { returnObjects: true }) as itemListProp) ?? []} />)
              href: `${import.meta.env.VITE_APP_BASE_URL}/#/help`
            },
            // {
            //   id: 8,
            //   hasContent: false,
            //   title: "Impact",
            //   Component: () => null,
            //   href: '/doc/testimonials'
            // },
          ],
        },
      ]
    )
  }, [i18n.language, rawUserDetails])


  if (!ready) return null;
  return (
    <div className="flex items-center gap-2">
      {TAB_GROUP?.map((el, i) => <DropdownTab TABS={el.tab} id={i} key={el.tab.map((t) => t.id).join("-")} />)}
    </div>
  );
};
type DropDownTabProp = {
  id: number;
  title: string;
  Component: () => JSX.Element;
  hasContent: boolean;
  href?: string;
};
const DropdownTab = ({ TABS, id }: { TABS: DropDownTabProp[] | any; id: number }) => {
  const [selected, setSelected] = useState<any>(null);
  const [dir, setDir] = useState<any>(null);
  const handleSetSelected = (val: any) => {
    if (typeof selected === "number" && typeof val === "number") {
      setDir(selected > val ? "r" : "l");
    } else if (val === null) {
      setDir(null);
    }
    setSelected(val);
  };
  return (
    <button
      type="button"
      onMouseLeave={() => handleSetSelected(null)}
      className="relative flex h-fit gap-2"
    >
      {TABS.map((t: any) => {
        return (
          <Tab
            key={t.id}
            selected={selected}
            handleSetSelected={handleSetSelected}
            tab={t.id}
            hasContent={t.hasContent}
            route={t.href}
          >
            {t.title}
          </Tab>
        );
      })}
      {
        <AnimatePresence>
          {selected && (
            <Content
              dir={dir}
              selected={selected}
              TABS={TABS}
              id={id}
              handleSetSelected={handleSetSelected}
            />
          )}
        </AnimatePresence>
      }
    </button>
  );
};

const Tab = ({
  children,
  tab,
  handleSetSelected,
  selected,
  hasContent,
  route,
}: any) => {
  if (!route) {
    return (
      <button
        id={`shift-tab-${tab}`}
        onMouseEnter={() => {
          handleSetSelected(tab);
        }}
        onClick={() => {
          handleSetSelected(tab);
        }}
        className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-sm transition-colors whitespace-nowrap font-normal ${selected === tab
          ? "bg-neutral-800 text-neutral-100"
          : "text-neutral-100"
          }`}
        data-has-content={hasContent}
      >
        {route ? <Link to={route}>{children}</Link> : <span>{children}</span>}
        {hasContent && (
          <ChevronDown
            className={`size-3 transition-transform ${selected === tab ? "rotate-180" : ""
              }`}
          />
        )}
      </button>
    );
  }
  return (
    <Link
      id={`shift-tab-${tab}`}
      onMouseEnter={() => {
        handleSetSelected(tab);
      }}
      onClick={() => {
        handleSetSelected(tab);
      }}
      to={route}
      className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-sm transition-colors whitespace-nowrap font-normal ${selected === tab
        ? "bg-neutral-800 text-neutral-100"
        : "text-neutral-100"
        }`}
      data-has-content={hasContent}
    >
      {<span>{children}</span>}
      {hasContent && (
        <ChevronDown
          className={`size-3 transition-transform ${selected === tab ? "rotate-180" : ""
            }`}
        />
      )}
    </Link>
  );

};

const Content = ({ selected, dir, TABS, id, handleSetSelected }: any) => {
  let initialX = 0;

  if (dir === "l") {
    initialX = 100;
  } else if (dir === "r") {
    initialX = -100;
  }

  return (
    <motion.div
      id={`overlay-content-${id}`}
      initial={{
        opacity: 0,
        y: 8,
      }}
      animate={{
        opacity: 1,
        y: 0,
      }}
      exit={{
        opacity: 0,
        y: 8,
      }}
      className="absolute left-0 top-[calc(100%_+_24px)] rounded-lg border border-neutral-700 bg-background p-0 backdrop-blur-2xl"
    >
      <Bridge />
      <Nub selected={selected} id={id} />

      {TABS.map((t: any) => {
        return (
          <button
            type="button"
            className="overflow-hidden"
            key={t.id}
            onClick={() => handleSetSelected(null)}
          >
            {selected === t.id && (
              <motion.div
                initial={{
                  opacity: 0,
                  x: initialX,
                }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.25, ease: "easeInOut" }}
              >
                <t.Component />
              </motion.div>
            )}
          </button>
        );
      })}
    </motion.div>
  );
};

const Bridge = () => (
  <div className="absolute -top-[24px] left-0 right-0 h-[24px]" />
);

const Nub = ({ selected, id }: any) => {
  const [left, setLeft] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  useEffect(() => {
    moveNub();
  }, [selected]);

  const moveNub = () => {
    if (selected) {
      setIsVisible(true);
      const hoveredTab = document.getElementById(`shift-tab-${selected}`);
      const overlayContent = document.getElementById(`overlay-content-${id}`);

      if (!hoveredTab || !overlayContent) return;

      if (hoveredTab?.dataset?.hasContent == "false") {
        setIsVisible(false);
        return;
      }

      const tabRect = hoveredTab.getBoundingClientRect();
      const { left: contentLeft } = overlayContent.getBoundingClientRect();

      const tabCenter = tabRect.left + tabRect.width / 2 - contentLeft;

      setLeft(tabCenter);
    }
  };

  return (
    <motion.span
      style={{
        clipPath: "polygon(0 0, 100% 0, 50% 50%, 0% 100%)",
      }}
      animate={{ left }}
      transition={{ duration: 0.25, ease: "easeInOut" }}
      className={`absolute left-1/2 top-0 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rotate-45 rounded-tl border border-neutral-600 bg-background ${isVisible ? "opacity-100" : "opacity-0"}`}
    />
  );
};

type itemListProp = { title: string; href: string; description: string }[]

type SingleColDropDownContentProps = {
  className?: string;
  itemList: { title: string; href: string; description: string, openInNew?: boolean }[];
};
const SingleColDropDownContent = ({
  className,
  itemList,
}: SingleColDropDownContentProps) => (
  <div
    className={
      cn(
        "grid w-[200px] gap-3 p-4 md:w-[300px] md:grid-cols-1",
        className,
      )
    }
  >
    {
      itemList.map((component) => (
        <ListItem
          key={component.title}
          title={component.title}
          href={`${import.meta.env.VITE_APP_BASE_URL}/#${component.href}`}
          openInNew={component?.openInNew}
        >
          {component.description}
        </ListItem>
      ))
    }
  </div >
);

const IsmartDropdownContent = () => {
  const { ready, t } = useTranslation('ismart_app_operate')
  if (!ready) return null;
  const APP_LIST = t("app", { returnObjects: true }) as any
  return (
    <div className="grid w-[790px] p-4 grid-cols-3 gap-2 dark">
      {APP_LIST
        .filter((el: any) => el.route != "/coming-soon")
        .filter((_: any, idx: number) => idx < 10)
        .map((component: any) => (
          <Link to={`${import.meta.env.VITE_APP_BASE_URL}/#/${component.route}`} key={component.route} className="flex text-white dark gap-2 p-2 rounded group hover:bg-secondary/40">
            <div className="h-10 w-10 shrink-0 border rounded grid place-items-center group-hover:bg-blue-600/80">
              <Icon name={component.icon} className="h-6 w-6" />
            </div>
            <div className="">
              <p className="line-clamp-1">{component.displayText}</p>
              <p className="text-muted-foreground line-clamp-1">{component.description}</p>
            </div>
          </Link>
        ))}
      <Link to="/operate" className="col-span-3">
        <Button variant="link" className="mr-auto h-full gap-2 px-3">
          <span>View All</span>
          <Icon name="move-right" className="size-4"></Icon>
        </Button>
      </Link>
    </div>
  );
};


type ListItemProps = React.ComponentPropsWithoutRef<"a"> & {
  href: string;
  openInNew?: boolean;
};


const ListItem = React.forwardRef<React.ElementRef<"a">, ListItemProps>(
  ({ className, title, children, href, ...props }, ref) => {
    return (
      <Link
        ref={ref}
        className={cn(
          "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
          className,
        )}
        target={props?.openInNew ? "_blank" : "_self"}
        to={href}
        {...props}
      >
        <div className="text-sm font-medium leading-none text-foreground">
          {title}
        </div>
        <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
          {children}
        </p>
      </Link>
    );
  },
);
ListItem.displayName = "ListItem";

export default AMSShiftDropdown;