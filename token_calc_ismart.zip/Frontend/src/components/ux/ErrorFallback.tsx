import { useAppDispatch } from "@/lib/redux/hooks";
import { useEffect } from "react";
import { SideBarNavData, updateSideBarNavigation } from "../layout/slice/sidebar-navigation";
import { updateTopNavigation } from "../layout/slice/topbar-navigation";
import { TopNav } from "../layout/TopNav";

import IMG_DARK from '@/assets/ux_img/error_dark.svg'
import IMG_LIGHT from '@/assets/ux_img/error_light.svg'


const SIDEBAR_DATA: SideBarNavData = {
    hasSideBar: false,
    sideBarNavList: [],
    bottomNavList: [],
};

export default function ErrorFallback() {
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(updateSideBarNavigation(SIDEBAR_DATA));
        dispatch(
            updateTopNavigation({ navList: [], isIsmartHome: true, isAMS: false, className: '' }),
        );
    }, []);
    return (
        <div className="min-h-screen w-full">
            <TopNav hasSideBar={false} />
            <div className="grid place-items-center mt-20">
                <div className="grid place-items-center">
                    <img src={IMG_DARK} alt="" className="hidden dark:block h-96" />
                    <img src={IMG_LIGHT} alt="" className="block dark:hidden h-96" />
                </div>
                <div className="mt-12 text-center space-y-2 max-w-[500px]">
                    <p className="font-medium text-3xl">Oops! Something went wrong</p>
                    <p className="text-muted-foreground text-sm">We have encountered an unexpected error. Please try again or contact sebl-ismart@tcscomprod.onmicrosoft.com if the issue persists.</p>
                </div>
            </div>
        </div>
    )
}