import React, { Component, ErrorInfo } from 'react'

type ErrorBoundryState = {
    hasError: boolean
}

type ErrorBoundaryProp = { children: React.ReactNode, fallback: React.ReactNode }

class ErrorBoundry extends Component<ErrorBoundaryProp, ErrorBoundryState> {
    constructor(props: ErrorBoundaryProp) {
        super(props);
        this.state = { hasError: false }
    }
    static getDerivedStateFromError() {
        return { hasError: true }
    }
    componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
        console.error({
            error,
            errorInfo
        })
    }
    render() {
        if (this.state.hasError) {
            return this.props.fallback
        }
        return this.props.children;
    }
}

export default ErrorBoundry