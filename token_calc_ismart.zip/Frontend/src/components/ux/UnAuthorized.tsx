import { useAppDispatch } from "@/lib/redux/hooks";
import Container from "../ui/container";
import { useEffect } from "react";
import { updateSideBarNavigation } from "../layout/slice/sidebar-navigation";
import { updateTopNavigation } from "../layout/slice/topbar-navigation";
import { NavigateBackButton } from "../ui/navigate-back-button";

export default function Unauthorized() {
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(updateSideBarNavigation([]));
        dispatch(
            updateTopNavigation({ navList: [], isIsmartHome: true, isAMS: false, className: '' }),
        );
    }, []);
    return (
        <Container className="h-[90vh] grid place-items-center">
            <div className="mt-12 text-center space-y-2 max-w-[500px] flex flex-col items-center">
                <NavigateBackButton />
                <p className="font-medium text-3xl">Oops! You are unauthorized</p>
                <p className="text-muted-foreground text-sm">It seems you are not authorized to access this module. Please contact sebl-ismart@tcscomprod.onmicrosoft.com for more details</p>
            </div>
        </Container>
    )
}