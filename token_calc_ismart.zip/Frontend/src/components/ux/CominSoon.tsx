import EXITING_CHANGES_THUMB_LIGHT from '@/assets/ux_img/Exiting_Changes_Ahead_light.svg'
import EXITING_CHANGES_THUMB_DARK from '@/assets/ux_img/Exiting_Changes_Ahead_dark.svg'
import Container from '../ui/container'
import { Link, useNavigate } from 'react-router-dom'
import { NavigateBackButton } from '../ui/navigate-back-button'
import { useEffect, useState } from 'react'
const ComingSoon = () => {
    const [redirectCounter, setRedirectCounter] = useState(10);
    const navigate = useNavigate();
    useEffect(() => {
        const timer = setInterval(() => {
            setRedirectCounter(prev => prev - 1);
        }, 1000)
        if (redirectCounter == 0) {
            clearInterval(timer);
            navigate("/doc/are-assets")
        }
        return () => clearInterval(timer)
    }, [redirectCounter])
    return (
        <section className='pt-12 pb-8 h-screen'>
            <Container>
                <div className="grid grid-cols-6 items-center gap-4">
                    <div className="col-span-3  mt-4">
                        <NavigateBackButton />
                        <h1 className='text-4xl font-medium mb-4'>Exciting changes are on the way</h1>
                        <p className='text-muted-foreground'>
                            We're enhancing this section with new features and improvements. <br/>You'll be redirected to the ARE Assets shortly to explore our offerings. 
                            Thank you for your patience!
                        </p>
                        <Link to="/doc/are-assets" className="mt-8 text-sm inline-block text-muted-foreground text-center hover:underline hover:text-foreground">
                            <span className="text-foreground underline">Click here</span>{" "}
                            to know more about ARE Assets {" ( "}Redirecting in {redirectCounter}s{" )"}</Link>
                    </div>
                    <img src={EXITING_CHANGES_THUMB_DARK} alt="" className='col-span-3 hidden dark:block' />
                    <img src={EXITING_CHANGES_THUMB_LIGHT} alt="" className='col-span-3 dark:hidden' />
                </div>
                

            </Container>

        </section>
    )
}
export default ComingSoon
// Our team is busy revamping this section to bring you a fresh and enhanced interface packed with new features and improvement.