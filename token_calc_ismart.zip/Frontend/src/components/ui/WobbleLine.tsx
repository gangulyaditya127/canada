import { useEffect, useRef } from "react";

function WobbleLine() {
  const path = useRef<any>(null);
  const boxRef = useRef<any>(null);
  let progress = 0;
  let x = 0.5;
  let time = Math.PI / 2;
  let reqId: any = null;

  useEffect(() => {
    setPath(progress);
  }, []);

  const setPath = (progress: any) => {
    const width = boxRef.current.getBoundingClientRect().width;
    path.current.setAttributeNS(
      null,
      "d",
      `M0 250 Q${width * x} ${250 + progress}, ${width} 250`,
    );
  };

  const lerp = (x: any, y: any, a: any) => x * (1 - a) + y * a;

  const manageMouseEnter = () => {
    if (reqId) {
      cancelAnimationFrame(reqId);
      resetAnimation();
    }
  };

  const manageMouseMove = (e: any) => {
    const { movementY, clientX } = e;
    const pathBound = path.current.getBoundingClientRect();
    x = (clientX - pathBound.left) / pathBound.width;
    progress += movementY;
    setPath(progress);
  };

  const manageMouseLeave = () => {
    animateOut();
  };

  const animateOut = () => {
    const newProgress = progress * Math.sin(time);
    progress = lerp(progress, 0, 0.025);
    time += 0.2;
    setPath(newProgress);
    if (Math.abs(progress) > 0.75) {
      reqId = requestAnimationFrame(animateOut);
    } else {
      resetAnimation();
    }
  };

  const resetAnimation = () => {
    time = Math.PI / 2;
    progress = 0;
  };
  return (
    <div className="relative mb-[15px] mt-[20px] h-[1px] w-full">
      <button
        type="button"
        ref={boxRef}
        className="relative -top-[20px] z-10 h-[40px] w-full bg-transparent border-0 p-0"
        onMouseEnter={() => {
          manageMouseEnter();
        }}
        onMouseMove={(e) => {
          manageMouseMove(e);
        }}
        onMouseLeave={() => {
          manageMouseLeave();
        }}
      >
        <svg className="pointer-events-none absolute -top-[230px] h-[500px] w-full">
          <path ref={path} className="fill-none stroke-white stroke-1"></path>
        </svg>
      </button>
    </div>
  );
}
export default WobbleLine;
