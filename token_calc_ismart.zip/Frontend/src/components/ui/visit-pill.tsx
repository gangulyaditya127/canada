import { useGetOverAllVisitCountQuery } from "@/stats/slice/statsAPISlice";
import { useState } from "react";

export default function VisitPill() {
  const [visible, setVisible] = useState(true);

  const {
    isLoading,
    isError,
    data
  } = useGetOverAllVisitCountQuery(null)

  const formatter = new Intl.NumberFormat('en-US', {
    notation: "compact",
    compactDisplay: "short",
    maximumFractionDigits: 1 // Controls decimal places
  });

  if (!visible) return null;

  if (isLoading || isError) return null;

  return (
    <div className="fixed bottom-6 right-6 flex items-center gap-3 bg-[#0e0e0e] text-white 
                    shadow-md shadow-black/40 px-4 py-2 rounded-full border border-white/10 z-[1000]">

      <div className="flex items-center gap-2">
        <span className="h-3 w-3 rounded-full bg-blue-600"></span>
        <span className="font-medium text-sm">{formatter.format(data?.count)} visits</span>
      </div>

      <button
        onClick={() => setVisible(false)}
        className="text-white/60 hover:text-white text-sm ml-1"
      >
        ✕
      </button>
    </div>
  );
}