import { Icon } from "@/components/ui/icon"
import { cn } from "@/lib/tailwind.utils";
const ErrorContainer = ({
    className
}: {
    className?: string
}) => {
    return (
        <div className={cn("grid min-h-80 border mt-8 h-full place-items-center text-sm", className)}>
            <div className="flex flex-col items-center gap-4 dark:text-red-700 text-red-500">
                <Icon
                    name="shield-alert"
                    strokeWidth={1.2}
                    className="size-20"
                />
                <div className="grid place-items-center dark:text-red-500">
                    <p>Oops! Something went wrong, please try after sometime.</p>
                </div>
            </div>
        </div>
    )
}
export default ErrorContainer;