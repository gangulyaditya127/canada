import { useEffect, useMemo, useRef, useState } from "react";
import { Icon } from "@/components/ui/icon";
import { cn } from "@/lib/tailwind.utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandSeparator,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CommandList } from "cmdk";

export interface SelectOption {
  value: string;
  label: string | number;
}

export interface MultiSelectComboboxProps {
  optionList: SelectOption[];
  value: string[] | undefined;
  setValue: any;
  placeholder: string;
  setValueOnClose: boolean;
  label?: string
  widthClass?: string
}

export function MultiSelectCombobox({
  optionList,
  value,
  setValue,
  placeholder,
  setValueOnClose,
  label,
  widthClass
}: MultiSelectComboboxProps) {
  const [open, setOpen] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState<string | any>(value);
  useEffect(() => {
    if (!open && setValueOnClose) {
      setValue(selectedOptions);
    }
  }, [open]);
  useEffect(() => {
    setSelectedOptions(value);
  }, [value]);
  const selectedValue = useMemo(() => {
    if (setValueOnClose) {
      return new Set<string>(selectedOptions ?? []);
    }
    return new Set<string>(value ?? []);
  }, [selectedOptions, setValueOnClose]);
  const buttonRef = useRef<HTMLButtonElement>(null)
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          ref={buttonRef}
          aria-expanded={open}
          className={cn("w-[200px] justify-between text-muted-foreground", widthClass)}
        >
          {selectedValue?.size > 0
            ? `${selectedValue.size} ${label ?? ""} Selected`
            : `${placeholder}`}
          <Icon
            name="chevrons-up-down"
            className="ml-2 h-4 w-4 shrink-0 opacity-50"
          />
        </Button>
      </PopoverTrigger>
      <PopoverContent style={
        {
          width: buttonRef.current?.clientWidth ?? '100%'
        }
      }
        className="p-0"
      >
        <Command>
          <CommandInput
            placeholder={placeholder?.length > 0 ? `Search ${placeholder}` : "Search ..."}
            className="h-9"
          />
          <CommandList>
            <CommandEmpty>No {placeholder ?? "Result"} found.</CommandEmpty>
            <CommandGroup>
              {optionList?.map((option: SelectOption) => {
                const isSelected = selectedValue.has(option.value);
                return (
                  <CommandItem
                    key={option.value}
                    value={option.value}
                    onSelect={(_) => {
                      if (isSelected) {
                        selectedValue.delete(option.value);
                      } else {
                        selectedValue.add(option.value);
                      }
                      const selectedVal: string[] = Array.from(selectedValue);
                      setSelectedOptions(selectedVal.length ? selectedVal : []);
                      if (!setValueOnClose) {
                        setValue(selectedVal.length ? selectedVal : []);
                      }
                    }}
                  >
                    <div
                      className={cn(
                        "mr-2 flex size-4 items-center justify-center rounded-sm border-[1.5px] border-primary",
                        isSelected
                          ? "bg-primary text-primary-foreground"
                          : "opacity-50 [&_svg]:invisible",
                      )}
                    >
                      <Icon
                        name="check"
                        strokeWidth={2.25}
                        className="size-4"
                      />
                    </div>
                    <span>{option.label}</span>
                  </CommandItem>
                );
              })}
            </CommandGroup>
            {selectedValue?.size > 0 && (
              <>
                <CommandSeparator />
                <CommandGroup>
                  <CommandItem
                    onSelect={() => {
                      setSelectedOptions([]);
                      if (!setValueOnClose) {
                        setValue([]);
                      }
                    }}
                    className="justify-center text-center"
                  >
                    Clear filters
                  </CommandItem>
                </CommandGroup>
              </>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
