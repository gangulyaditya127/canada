import React from "react";
import { cn } from "@/lib/tailwind.utils";
interface ContainerProp {
  children: React.ReactNode;
  className?: string;
  ref?: any;
}
const Container: React.FC<ContainerProp> = ({ children, className, ref }) => {
  return (
    <div
      ref={ref ?? null}
      className={cn("relative mx-auto w-full max-w-[2000px] md:px-4", className)}
    >
      {children}
    </div>
  );
};
export default Container;
