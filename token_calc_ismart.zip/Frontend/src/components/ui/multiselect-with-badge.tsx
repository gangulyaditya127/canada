import * as React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Command,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandEmpty,
} from "@/components/ui/command";
import { Check, ChevronsUpDown, X } from "lucide-react";
import { cn } from "@/lib/utils";

export type Option = {
  label: string;
  value: string;
};

type MultiSelectProps = {
  value: string[];
  onChange: (next: string[]) => void;
  options: Option[];
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  maxSelected?: number;
  onMaxSelectedHit?: (max: number) => void;
};

export function MultiSelectWithBadge({
  value,
  onChange,
  options,
  placeholder = "Select…",
  disabled,
  className,
  maxSelected,
  onMaxSelectedHit,
}: MultiSelectProps) {
  const [open, setOpen] = React.useState(false);
  const selectedSet = new Set(value);
  const limitReached = typeof maxSelected === "number" && value.length >= maxSelected;

  const toggle = (val: string) => {
    const next = new Set(selectedSet);
    const isSelected = next.has(val);
    if (!isSelected && limitReached) {
      onMaxSelectedHit?.(maxSelected as number);
      return;
    }

    if (isSelected) next.delete(val);
    else next.add(val);

    onChange(Array.from(next));
  };

  const remove = (val: string) => {
    const next = value.filter((v) => v !== val);
    onChange(next);
  };

  const selectedLabels = options
    .filter((o) => selectedSet.has(o.value))
    .map((o) => o.label);

  let selectedText: string;

  if (selectedLabels.length > 0) {
    selectedText = `${selectedLabels.length} selected`;

    if (maxSelected) {
      selectedText += ` (max ${maxSelected - 1})`;
    }
  } else {
    selectedText = placeholder;
  }
  return (
    <div className={cn("space-y-2", className)}>
      {selectedLabels.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {selectedLabels.map((label) => {
            const opt = options.find((o) => o.label === label)!;
            return (
              <Badge key={opt.value} variant="secondary" className="pr-1 bg-blue-500 hover:bg-blue-600 text-white">
                {label}
                <button
                  type="button"
                  aria-label={`Remove ${label}`}
                  onClick={() => remove(opt.value)}
                  className="ml-1 inline-flex items-center text-muted-foreground hover:text-foreground"
                >
                  <X className="h-3 w-3 text-white/60" />
                </button>
              </Badge>
            );
          })}
        </div>
      )}

      {/* Trigger */}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            disabled={disabled}
            className="w-full justify-between"
          >
            <span className={cn(selectedLabels.length === 0 && "text-muted-foreground")}>
              {selectedText}
            </span>
            <ChevronsUpDown className="ml-2 h-4 w-4 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0" align="start">
          <Command>
            <CommandInput placeholder="Search…" />
            <CommandList>
              <CommandEmpty>No options found.</CommandEmpty>
              <CommandGroup>
                {options.map((opt) => {
                  const isSelected = selectedSet.has(opt.value);
                  const shouldDisable = !isSelected && limitReached;

                  return (
                    <CommandItem
                      key={opt.value}
                      onSelect={() => {
                        if (!shouldDisable) toggle(opt.value);
                        else onMaxSelectedHit?.(maxSelected as number);
                      }}
                      className={cn(
                        "cursor-pointer",
                        shouldDisable && "opacity-50 pointer-events-none"
                      )}
                      aria-disabled={shouldDisable}
                      data-disabled={shouldDisable}
                    >
                      <Check
                        className={cn(
                          "mr-2 h-4 w-4",
                          isSelected ? "opacity-100" : "opacity-0"
                        )}
                      />
                      {opt.label}
                    </CommandItem>
                  );
                })}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

    </div>
  );
}
