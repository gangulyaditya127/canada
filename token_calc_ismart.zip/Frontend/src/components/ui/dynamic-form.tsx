import { useState } from "react"
import { useForm, UseFormReturn } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form"
import { MultiSelectCombobox, SelectOption } from "./multi-select-combobox"

type FieldOption = {
    value: string
    label: string
}

type ValidationRule = {
    type: 'required' | 'min' | 'max' | 'minLength' | 'maxLength' | 'pattern' | 'custom'
    value?: any
    message: string
}

export type FormFieldProp = {
    name: string
    label: string
    type: "text" | "select" | "multiselect"
    description?: string
    options?: FieldOption[]
    validation?: ValidationRule[]
}

export type FormData = Record<string, string | string[]>

// Function to generate Zod schema based on JSON input
const generateSchema = (fields: FormFieldProp[]): z.ZodObject<any> => {
    if (!Array.isArray(fields)) {
        console.error("Invalid formFields: expected an array")
        return z.object({})
    }

    const schemaFields: Record<string, z.ZodTypeAny> = {}
    fields.forEach((field) => {
        if (field?.name && field?.type) {
            let fieldSchema: z.ZodTypeAny

            switch (field.type) {
                case "text":
                    fieldSchema = z.string()
                    break
                case "select":
                    fieldSchema = z.string()
                    break
                case "multiselect":
                    fieldSchema = z.array(z.string())
                    break
                default:
                    console.warn(`Unsupported field type: ${field.type}`)
                    return
            }

            if (field.validation) {
                field.validation.forEach((rule: ValidationRule) => {
                    switch (rule.type) {
                        case 'required':
                            if (field.type === "text" || field.type === "select") {
                                fieldSchema = (fieldSchema as z.ZodString).min(1, { message: rule.message })
                            } else if (field.type === "multiselect") {
                                fieldSchema = (fieldSchema as z.ZodArray<z.ZodString>).min(1, { message: rule.message })
                            }
                            break
                        case 'min':
                            if (field.type === "text" || field.type === "select") {
                                fieldSchema = (fieldSchema as z.ZodString).min(rule.value, { message: rule.message })
                            } else if (field.type === "multiselect") {
                                fieldSchema = (fieldSchema as z.ZodArray<z.ZodString>).min(rule.value, { message: rule.message })
                            }
                            break
                        case 'max':
                            if (field.type === "text" || field.type === "select") {
                                fieldSchema = (fieldSchema as z.ZodString).max(rule.value, { message: rule.message })
                            } else if (field.type === "multiselect") {
                                fieldSchema = (fieldSchema as z.ZodArray<z.ZodString>).max(rule.value, { message: rule.message })
                            }
                            break
                    }
                })
            }

            schemaFields[field.name] = fieldSchema
        } else {
            console.warn("Invalid field definition:", field)
        }
    })
    return z.object(schemaFields)
}

// Input components
const TextInput: React.FC<{ field: FormFieldProp; control: UseFormReturn["control"]; name: string }> = ({ field, control, name }) => (
    <FormField
        control={control}
        name={name}
        render={({ field: formField }) => (
            <FormItem>
                <FormLabel>{field.label}</FormLabel>
                <FormControl>
                    <Input {...formField} />
                </FormControl>
                <FormDescription>{field.description}</FormDescription>
                <FormMessage />
            </FormItem>
        )}
    />
)

const SelectInput: React.FC<{ field: FormFieldProp; control: UseFormReturn["control"]; name: string }> = ({ field, control, name }) => (
    <FormField
        control={control}
        name={name}
        render={({ field: formField }) => (
            <FormItem>
                <FormLabel>{field.label}</FormLabel>
                <Select onValueChange={formField.onChange} defaultValue={formField.value}>
                    <FormControl>
                        <SelectTrigger>
                            <SelectValue placeholder="Select an option" />
                        </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                        {field.options?.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                                {option.label}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
                <FormDescription>{field.description}</FormDescription>
                <FormMessage />
            </FormItem>
        )}
    />
)

const MultiSelectInput: React.FC<{ field: FormFieldProp; control: UseFormReturn["control"]; name: string }> = ({ field, control, name }) => (
    <FormField
        control={control}
        name={name}
        render={({ field: formField }) => (
            <FormItem>
                <FormLabel>{field.label}</FormLabel>
                <MultiSelectCombobox widthClass="w-full" setValueOnClose={true} optionList={field.options as unknown as SelectOption[] ?? []} value={formField.value} placeholder="Select" setValue={formField.onChange} />
                <FormDescription>{field.description}</FormDescription>
                <FormMessage />
            </FormItem>
        )}
    />
)

type DynamicFormProps = {
    formFields: FormFieldProp[]
    onSubmit: (data: FormData) => void
}

// Main DynamicForm component
export default function DynamicForm({ formFields, onSubmit }: DynamicFormProps) {
    const [formData, setFormData] = useState<FormData>({})

    const schema = generateSchema(formFields)
    const form = useForm<FormData>({
        resolver: zodResolver(schema),
        defaultValues: formFields.reduce((acc, field) => {
            acc[field.name] = field.type === "multiselect" ? [] : ""
            return acc
        }, {} as FormData),
    })

    const handleSubmit = (data: FormData) => {
        console.log({ formData })
        setFormData(data)
        onSubmit(data)
    }

    return (
        <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                {formFields.map((field) => {
                    switch (field.type) {
                        case "text": return <TextInput key={field.name} field={field} control={form.control} name={field.name} />
                        case "select": return <SelectInput key={field.name} field={field} control={form.control} name={field.name} />
                        case "multiselect": return <MultiSelectInput key={field.name} field={field} control={form.control} name={field.name} />
                        default: return null
                    }
                })}
                <Button type="submit">Submit</Button>
            </form>
        </Form>
    )
}
