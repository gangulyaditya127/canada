import {
  createContext,
  useContext,
  useState,
  useRef,
  useEffect,
  useCallback,
  useMemo,
  type ReactNode,
  type MouseEvent,
} from "react";
import {
  format,
  differenceInDays,
  addDays,
  startOfDay,
} from "date-fns";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { ChevronDown, ChevronRight, Plus, X, GripVertical } from "lucide-react";

// Types
type Range = "daily" | "weekly" | "monthly" | "quarterly";

interface Feature {
  id: string;
  name: string;
  startAt: Date;
  endAt: Date;
  status?: {
    id: string;
    name: string;
    color: string;
  };
  owner?: {
    id: string;
    name: string;
    image?: string;
  };
  group?: {
    id: string;
    name: string;
  };
  [key: string]: unknown;
}

interface Marker {
  id: string;
  date: Date;
  label: string;
  className?: string;
}

// Context
interface GanttContextValue {
  range: Range;
  zoom: number;
  startDate: Date;
  endDate: Date;
  totalWeeks: number;
  columnWidth: number;
  sidebarWidth: number;
  headerHeight: number;
  rowHeight: number;
  editable: boolean;
  onAddItem?: (date: Date) => void;
  getPositionFromDate: (date: Date) => number;
  getDateFromPosition: (position: number) => Date;
  getWeekFromDate: (date: Date) => number;
}

const GanttContext = createContext<GanttContextValue | null>(null);

function useGantt() {
  const context = useContext(GanttContext);
  if (!context) {
    throw new Error("useGantt must be used within a GanttProvider");
  }
  return context;
}

// GanttProvider
interface GanttProviderProps {
  children: ReactNode;
  range?: Range;
  zoom?: number;
  className?: string;
  onAddItem?: (date: Date) => void;
  editable?: boolean;
  startDate?: Date;
  totalWeeks?: number;
}

export function GanttProvider({
  children,
  range = "weekly",
  zoom = 100,
  className,
  onAddItem,
  editable = true,
  startDate: propStartDate,
  totalWeeks: propTotalWeeks = 20,
}: GanttProviderProps) {
  const startDate = propStartDate || startOfDay(new Date());
  const endDate = addDays(startDate, propTotalWeeks * 7);

  // Each week gets a column
  const columnWidth = useMemo(() => {
    const baseWidth = 80; // width per week
    return (baseWidth * zoom) / 100;
  }, [zoom]);

  const getPositionFromDate = useCallback(
    (date: Date): number => {
      const days = differenceInDays(date, startDate);
      const weekPosition = (days / 7) * columnWidth;
      return weekPosition;
    },
    [startDate, columnWidth]
  );

  const getDateFromPosition = useCallback(
    (position: number): Date => {
      const weeks = position / columnWidth;
      const days = Math.round(weeks * 7);
      return addDays(startDate, days);
    },
    [startDate, columnWidth]
  );

  const getWeekFromDate = useCallback(
    (date: Date): number => {
      const days = differenceInDays(date, startDate);
      return Math.floor(days / 7) + 1;
    },
    [startDate]
  );

  const value: GanttContextValue = useMemo(
    () => ({
      range,
      zoom,
      startDate,
      endDate,
      totalWeeks: propTotalWeeks,
      columnWidth,
      sidebarWidth: 300,
      headerHeight: 50,
      rowHeight: 44,
      editable,
      onAddItem,
      getPositionFromDate,
      getDateFromPosition,
      getWeekFromDate,
    }),
    [
      range,
      zoom,
      startDate,
      endDate,
      propTotalWeeks,
      columnWidth,
      editable,
      onAddItem,
      getPositionFromDate,
      getDateFromPosition,
      getWeekFromDate,
    ]
  );

  return (
    <GanttContext.Provider value={value}>
      <TooltipProvider>
        <div className={cn("flex overflow-hidden rounded-lg bg-background", className)}>
          {children}
        </div>
      </TooltipProvider>
    </GanttContext.Provider>
  );
}

// GanttSidebar
interface GanttSidebarProps {
  children: ReactNode;
  className?: string;
}

export function GanttSidebar({ children, className }: GanttSidebarProps) {
  const { sidebarWidth, headerHeight } = useGantt();

  return (
    <div
      className={cn("flex flex-col border-r bg-muted/30 shrink-0", className)}
      style={{ width: sidebarWidth }}
    >
      <div
        className="flex items-center border-b px-4 font-medium text-sm"
        style={{ height: headerHeight }}
      >
        <span>Solutions</span>
        <span className="ml-auto text-muted-foreground">Duration</span>
      </div>
      <div className="flex-1 overflow-y-auto">{children}</div>
    </div>
  );
}

interface GanttSidebarGroupProps {
  name: string;
  children: ReactNode;
  className?: string;
}

export function GanttSidebarGroup({ name, children, className }: GanttSidebarGroupProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const { rowHeight } = useGantt();

  return (
    <div className={cn("", className)}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex w-full items-center gap-2 border-b px-4 py-2 text-sm font-medium hover:bg-muted/50 transition-colors"
        style={{ minHeight: rowHeight }}
      >
        {isExpanded ? (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        )}
        <span className="truncate text-muted-foreground">{name}</span>
      </button>
      {isExpanded && <div>{children}</div>}
    </div>
  );
}

// GanttSidebarItem
interface GanttSidebarItemProps {
  feature: Feature;
  onSelectItem?: (id: string) => void;
  className?: string;
}

export function GanttSidebarItem({ feature, onSelectItem, className }: GanttSidebarItemProps) {
  const { rowHeight } = useGantt();
  const duration = differenceInDays(feature.endAt, feature.startAt);
  const weeks = Math.ceil(duration / 7);

  return (
    <button
      onClick={() => onSelectItem?.(feature.id)}
      className={cn(
        "flex w-full items-center justify-between border-b px-4 text-sm hover:bg-muted/50 transition-colors",
        className
      )}
      style={{ minHeight: rowHeight }}
    >
      <span className="truncate pr-2">{feature.name}</span>
      <span className="text-muted-foreground whitespace-nowrap">{weeks}w</span>
    </button>
  );
}

// GanttTimeline
interface GanttTimelineProps {
  children: ReactNode;
  className?: string;
}

export function GanttTimeline({ children, className }: GanttTimelineProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const { totalWeeks, columnWidth } = useGantt();

  const totalWidth = totalWeeks * columnWidth;

  return (
    <div ref={scrollRef} className={cn("flex-1 overflow-auto relative", className)}>
      <div style={{ width: totalWidth, minWidth: "100%" }} className="relative">
        {children}
      </div>
    </div>
  );
}

// GanttHeader - Shows Week 1, Week 2, etc.
interface GanttHeaderProps {
  className?: string;
}

export function GanttHeader({ className }: GanttHeaderProps) {
  const { totalWeeks, columnWidth, headerHeight } = useGantt();

  const weeks = Array.from({ length: totalWeeks }, (_, i) => i + 1);

  return (
    <div
      className={cn("sticky top-0 z-10 border-b bg-background flex", className)}
      style={{ height: headerHeight }}
    >
      {weeks.map((week) => (
        <div
          key={week}
          className="flex items-center justify-center border-r text-xs font-medium shrink-0"
          style={{ width: columnWidth }}
        >
          Week {week}
        </div>
      ))}
    </div>
  );
}

// GanttFeatureList
interface GanttFeatureListProps {
  children: ReactNode;
  className?: string;
}

export function GanttFeatureList({ children, className }: GanttFeatureListProps) {
  const { totalWeeks, columnWidth } = useGantt();

  return (
    <div className={cn("relative", className)}>
      {/* Grid background */}
      <div className="absolute inset-0 flex pointer-events-none">
        {Array.from({ length: totalWeeks }, (_, i) => (
          <div
            key={i}
            className={cn(
              "border-r h-full shrink-0",
              i % 4 === 0 && "bg-muted/20"
            )}
            style={{ width: columnWidth }}
          />
        ))}
      </div>
      {/* Features */}
      <div className="relative">{children}</div>
    </div>
  );
}

// GanttFeatureListGroup
interface GanttFeatureListGroupProps {
  children: ReactNode;
  className?: string;
}

export function GanttFeatureListGroup({ children, className }: GanttFeatureListGroupProps) {
  const { rowHeight } = useGantt();

  return (
    <div className={className}>
      {/* Group header spacer */}
      <div className="border-b bg-muted/20" style={{ height: rowHeight }} />
      {/* Group items */}
      {children}
    </div>
  );
}

// GanttFeatureItem - with drag support
interface GanttFeatureItemProps extends Feature {
  children?: ReactNode;
  onMove?: (id: string, startAt: Date, endAt: Date | null) => void;
  className?: string;
}

export function GanttFeatureItem({
  id,
  name,
  startAt,
  endAt,
  status,
  children,
  onMove,
  className,
}: GanttFeatureItemProps) {
  const {
    getPositionFromDate,
    getDateFromPosition,
    columnWidth,
    rowHeight,
    editable,
  } = useGantt();

  const [isDragging, setIsDragging] = useState(false);
  const [dragStartX, setDragStartX] = useState(0);
  const [originalLeft, setOriginalLeft] = useState(0);
  const [currentLeft, setCurrentLeft] = useState(0);

  const itemRef = useRef<HTMLButtonElement>(null);

  const left = getPositionFromDate(startAt);
  const durationDays = differenceInDays(endAt, startAt) + 1;
  const width = (durationDays / 7) * columnWidth;

  useEffect(() => {
    setCurrentLeft(left);
  }, [left]);

  const handleMouseDown = (e: MouseEvent<HTMLButtonElement>) => {
    if (!editable || !onMove) return;

    e.preventDefault();
    e.stopPropagation();

    setIsDragging(true);
    setDragStartX(e.clientX);
    setOriginalLeft(currentLeft);
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: globalThis.MouseEvent) => {
      const deltaX = e.clientX - dragStartX;
      const newLeft = Math.max(0, originalLeft + deltaX);
      setCurrentLeft(newLeft);
    };

    const handleMouseUp = () => {
      setIsDragging(false);

      const newStartDate = getDateFromPosition(currentLeft);
      const duration = differenceInDays(endAt, startAt);
      const newEndDate = addDays(newStartDate, duration);

      onMove?.(id, newStartDate, newEndDate);
    };

    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [
    isDragging,
    dragStartX,
    originalLeft,
    currentLeft,
    id,
    startAt,
    endAt,
    onMove,
    getDateFromPosition,
  ]);

  return (
    <div className="relative border-b" style={{ height: rowHeight }}>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            ref={itemRef}
            type="button"
            className={cn(
              "absolute top-1/2 -translate-y-1/2 rounded-md px-2 py-1 text-xs font-medium text-white shadow-sm transition-all hover:shadow-md flex items-center gap-1 overflow-hidden",
              "bg-transparent border-0 p-0",
              isDragging
                ? "cursor-grabbing shadow-lg opacity-90 z-50"
                : "cursor-grab",
              className
            )}
            style={{
              left: currentLeft,
              width: Math.max(width, 50),
              backgroundColor: status?.color || "#3b82f6",
              height: rowHeight - 10,
            }}
            onMouseDown={handleMouseDown}
          >
            {editable && onMove && (
              <GripVertical className="h-3 w-3 shrink-0 opacity-60" />
            )}
            {children || <span className="truncate">{name}</span>}
          </button>
        </TooltipTrigger>

        <TooltipContent>
          <div className="text-sm">
            <p className="font-medium">{name}</p>
            <p className="text-muted-foreground">
              {format(startAt, "MMM d")} – {format(endAt, "MMM d, yyyy")}
            </p>
            {status && (
              <p className="text-muted-foreground">
                Phase: {status.name}
              </p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </div>
  );
}
// GanttMarker
interface GanttMarkerProps extends Marker {
  onRemove?: (id: string) => void;
  className?: string;
}

export function GanttMarker({ id, date, label, onRemove, className }: GanttMarkerProps) {
  const { getPositionFromDate, headerHeight } = useGantt();
  const left = getPositionFromDate(date);

  return (
    <div
      className={cn(
        "absolute z-20 flex flex-col items-center pointer-events-auto",
        className
      )}
      style={{ left, top: headerHeight }}
    >
      <div
        className={cn(
          "px-2 py-1 rounded text-xs font-medium whitespace-nowrap flex items-center gap-1",
          className || "bg-blue-100 text-blue-900"
        )}
      >
        <span>{label}</span>
        {onRemove && (
          <button
            onClick={() => onRemove(id)}
            className="hover:bg-black/10 rounded p-0.5"
          >
            <X className="h-3 w-3" />
          </button>
        )}
      </div>
      <div className="w-px h-full bg-current opacity-30" />
    </div>
  );
}

// GanttToday
interface GanttTodayProps {
  className?: string;
}

export function GanttToday({ className }: GanttTodayProps) {
  const { getPositionFromDate, headerHeight, getWeekFromDate } = useGantt();
  const today = new Date();
  const left = getPositionFromDate(today);
  const week = getWeekFromDate(today);

  return (
    <div
      className={cn("absolute z-30 pointer-events-none", className)}
      style={{ left, top: 0, bottom: 0 }}
    >
      <div
        className="bg-red-500 text-white text-xs px-2 py-0.5 rounded whitespace-nowrap"
        style={{ marginTop: headerHeight + 4 }}
      >
        Today (Week {week})
      </div>
      <div className="w-0.5 h-full bg-red-500 absolute left-1/2 -translate-x-1/2 top-0" />
    </div>
  );
}

// GanttCreateMarkerTrigger
interface GanttCreateMarkerTriggerProps {
  onCreateMarker?: (date: Date) => void;
  className?: string;
}

export function GanttCreateMarkerTrigger({
  onCreateMarker,
  className,
}: GanttCreateMarkerTriggerProps) {
  const { getDateFromPosition, headerHeight } = useGantt();
  const [showButton, setShowButton] = useState(false);
  const [buttonPosition, setButtonPosition] = useState(0);

  const handleMouseMove = (e: MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    setButtonPosition(x);
    setShowButton(true);
  };

  const handleClick = () => {
    const date = getDateFromPosition(buttonPosition);
    onCreateMarker?.(date);
  };

  return (
    <button
      type="button"
      className={cn("absolute inset-0 z-10", className)}
      style={{ top: headerHeight }}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => setShowButton(false)}
      onClick={handleClick}
    >{showButton && (
      <div
        className="absolute top-2 -translate-x-1/2 bg-primary text-primary-foreground rounded-full p-1 cursor-pointer shadow-lg opacity-50 hover:opacity-100 transition-opacity"
        style={{ left: buttonPosition }}
      >
        <Plus className="h-4 w-4" />
      </div>
    )}
    </button>
  );
}
