import { cn } from "@/lib/tailwind.utils";
import { MoveLeft } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useLocation } from "react-router-dom";
export const NavigateBackButton = (
    {
        className,
        fallbackUrl
    }: {
        className?: string,
        fallbackUrl?: string
    }
) => {
    const navigate = useNavigate()
    const location = useLocation()
    const { t } = useTranslation('common')
    const handleNavigate = () => {
        if (location.key == "default") {
            navigate(fallbackUrl ?? "/")
            return;
        }
        navigate(-1)
    }
    return (
        <button onClick={handleNavigate} className={cn("text-xs py-0 mb-4 col-span-4 flex gap-1 text-muted-foreground hover:text-foreground", className)}>
            <MoveLeft className='size-4'/>
            <span>{t('back')}</span>
        </button >
    )
}