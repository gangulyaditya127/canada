
import { LucideProps } from "lucide-react";
import { DynamicIcon, IconName } from 'lucide-react/dynamic';
interface DynamicIconComponentProps extends LucideProps {
  name: IconName;
  fallback?: () => JSX.Element | null;
}
export type IconNameProp = IconName
export const Icon = ({ ...props }: DynamicIconComponentProps) => {
  return (
    <DynamicIcon {...props} />
  );
};
