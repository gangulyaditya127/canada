const PageLoader = () => {
    return (
        <div className="fixed inset-0 grid items-center justify-center bg-black bg-opacity-20 dark:bg-opacity-20 z-[9999]">
            <div className="fixed inset-0 grid place-items-center bg-black bg-opacity-50 z-9999">
                <div className="animate-spin size-4 rounded-full h-16 w-16 border-t-4 border-purple-500"></div>
            </div>
        </div>
    );
};

export default PageLoader;