
import * as React from "react"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
    Command,
    CommandEmpty,
    CommandGroup,
    CommandItem,
    CommandList,
} from "@/components/ui/command"

type Option = {
    value: string | undefined;
    label: string | number;
}

export type AutocompleteInputProps = {
    options: Option[]
    value?: string
    onValueChange?: (val: string) => void
    onSelect?: (option: Option) => void
    placeholder?: string
    id?: string
    label?: string
    minChars?: number
    loading?: boolean
    className?: string
    /** If true, Enter selects the first suggestion */
    selectFirstOnEnter?: boolean
}

export function AutocompleteInput({
    options,
    value,
    onValueChange,
    onSelect,
    placeholder = "Search…",
    id,
    label,
    minChars = 0,
    loading = false,
    className,
    selectFirstOnEnter = true,
}: AutocompleteInputProps) {
    const isControlled = value !== undefined
    const [internal, setInternal] = React.useState("")
    const text = isControlled ? (value as string) : internal

    const [open, setOpen] = React.useState(false)

    const filtered = React.useMemo(() => {
        const q = (text || "").trim().toLowerCase()
        if (!q) return options
        return options.filter(
            (o) =>
                (o.label + "")?.toLowerCase().includes(q) ||
                (o.value + "").toLowerCase().includes(q)
        )
    }, [text, options]);

    const inputRef = React.useRef<HTMLInputElement>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const next = e.target.value
        if (isControlled) {
            onValueChange?.(next)
        } else {
            setInternal(next)
            onValueChange?.(next)
        }
        setOpen(next.length >= minChars)
    }

    const handleFocus = () => {
        setOpen((text?.length ?? 0) >= minChars)
    }

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === "Escape") setOpen(false)
        if (e.key === "ArrowDown") {
            setOpen(true)
            e.preventDefault()
        }
        if (e.key === "Enter" && selectFirstOnEnter && filtered.length > 0) {
            e.preventDefault()
            commitSelection(filtered[0])
        }
    }

    const commitSelection = (opt: Option) => {
        if (isControlled) {
            onValueChange?.(opt.label + "")
        } else {
            setInternal(opt.label + "")
            onValueChange?.(opt.label + "")
        }
        onSelect?.(opt)
        setOpen(false)
    }

    const handleCommandItemSelect = (val: string) => {
        const opt =
            options.find((o) => o.label === val) ??
            options.find((o) => o.value === val)
        if (opt) commitSelection(opt)
    }

    const showDropdown =
        open && (loading || filtered.length > 0 || (text?.length ?? 0) > 0)

    React.useEffect(() => {
        setTimeout(() => {
            console.log({
                ip: inputRef?.current
            })
        }, 100)
    }, [])
    let commandContent: React.ReactNode;

    if (loading) {
        commandContent = (
            <div className="p-3 text-sm text-muted-foreground">
                Loading…
            </div>
        );
    } else if (filtered.length === 0) {
        commandContent = (
            <CommandEmpty>No results found.</CommandEmpty>
        );
    } else {
        commandContent = (
            <CommandGroup>
                {filtered.map((opt) => (
                    <CommandItem
                        key={opt.value}
                        value={String(opt.label)}
                        onSelect={handleCommandItemSelect}
                        // Prevent the input from blurring before selection
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => commitSelection(opt)}
                    >
                        {opt.label}
                    </CommandItem>
                ))}
            </CommandGroup>
        );
    }
    return (
        <div className={cn("w-full", className)}>
            {label ? (
                <label htmlFor={id} className="mb-1 block text-sm font-medium text-muted-foreground">
                    {label}
                </label>
            ) : null}

            {/* Keep focus in the Input; don't let popover trap focus */}
            <Popover open={showDropdown} onOpenChange={setOpen} modal={false}>
                <PopoverTrigger asChild>
                    <Input
                        id={id}
                        value={text}
                        onChange={handleChange}
                        onFocus={handleFocus}
                        onKeyDown={handleKeyDown}
                        placeholder={placeholder}
                        role=""
                        type="text"
                        aria-expanded={showDropdown}
                        aria-controls={showDropdown ? `${id}-listbox` : undefined}
                        autoComplete="off"
                        ref={inputRef}
                    />
                </PopoverTrigger>

                <PopoverContent
                    className="p-0 z-[300]"
                    align="start"
                    sideOffset={4}
                    style={{ width: inputRef.current?.clientWidth ?? '100%' }}
                    // Prevent popover from auto-focusing itself when it opens
                    onOpenAutoFocus={(e) => e.preventDefault()}
                    // Ignore "outside" when it's the input trigger itself
                    onInteractOutside={(e) => {
                        const target = e.target as HTMLElement
                        if (target?.closest("input")) {
                            e.preventDefault()
                        }
                    }}
                >
                    <Command aria-label={label || "Suggestions"}>
                        <CommandList id={`${id}-listbox`} role="listbox" className="max-h-[200px] overflow-auto">
                            {commandContent}
                        </CommandList>
                    </Command>
                </PopoverContent>
            </Popover>
        </div>
    )
}
