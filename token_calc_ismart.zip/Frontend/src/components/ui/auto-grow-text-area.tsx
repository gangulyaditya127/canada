import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/tailwind.utils";
import { ChangeEvent, forwardRef } from "react";

interface AutoTextareaProps
    extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
    defaultRows: number | undefined;
    maxRows: number | undefined;
    className: string | undefined;
    onChange: ((e: ChangeEvent<HTMLTextAreaElement>) => void);
    value: string;
    id: string
}

const AutoTextArea = forwardRef<HTMLTextAreaElement, AutoTextareaProps>(({
    maxRows = 5,
    className,
    defaultRows = 1,
    value,
    onChange,
    id,
    ...props
}, ref) => {
    const handleInput = (e: ChangeEvent<HTMLTextAreaElement>) => {
        const textarea = e.target;
        textarea.style.height = "auto";
        const style = window.getComputedStyle(textarea);
        const borderHeight =  Number.parseInt(style.borderTopWidth) +  Number.parseInt(style.borderBottomWidth);
        const paddingHeight =  Number.parseInt(style.paddingTop) +  Number.parseInt(style.paddingBottom);
        const lineHeight =  Number.parseInt(style.lineHeight);
        const maxHeight = maxRows ? lineHeight * maxRows + borderHeight + paddingHeight : Infinity;
        const newHeight = Math.min(textarea.scrollHeight + borderHeight, maxHeight);
        textarea.style.height = `${newHeight}px`;
        onChange(e)
    };
    return (
        <Textarea
            id={id}
            ref={ref}
            onChange={handleInput}
            value={value}
            rows={defaultRows}
            {...props}
            className={cn("min-h-[none] resize-none", className)}
        />
    );
})

AutoTextArea.displayName = "AutoTextArea";
export default AutoTextArea