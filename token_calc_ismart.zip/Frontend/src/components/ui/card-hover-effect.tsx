import { cn } from "@/lib/tailwind.utils";
import { AnimatePresence, motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useState } from "react";
import { IconNameProp } from "./icon";
import { Icon } from "@/components/ui/icon";

export const HoverEffect = ({
  items,
  className,
}: {
  items: {
    title: string;
    description: string;
    link: string;
    icon?: IconNameProp;
    openInNew?: boolean,
    key: number,
    badge?: string;
  }[];
  className?: string;
}) => {
  let [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <div
      className={cn(
        "grid grid-cols-1 py-10 md:grid-cols-2 lg:grid-cols-3",
        className,
      )}
    >
      {items.map((item, idx) => (
        <Link
          to={item?.link ?? ""}
          key={item?.key}
          className="group relative block h-full w-full p-2"
          onMouseEnter={() => setHoveredIndex(idx)}
          onMouseLeave={() => setHoveredIndex(null)}
          target={item.openInNew ? "_blank" : "_self"}
        >
          <AnimatePresence>
            {hoveredIndex === idx && (
              <motion.span
                className="absolute inset-0 block h-full w-full rounded-xl bg-neutral-200 dark:bg-zinc-900/[0.8] -z-[20]"
                layoutId="hoverBackground"
                initial={{ opacity: 0 }}
                animate={{
                  opacity: 1,
                  transition: { duration: 0.15 },
                }}
                exit={{
                  opacity: 0,
                  transition: { duration: 0.15, delay: 0.2 },
                }}
              />
            )}
          </AnimatePresence>
          <CardWraper icon={item.icon} title={item.title} description={item.description} />
        </Link>
      ))}
    </div>
  );
};

export const HoverEffectWithBadge = ({
  items,
  className,
}: {
  items: {
    title: string;
    description: string;
    link: string;
    icon?: IconNameProp;
    openInNew?: boolean,
    key: number,
    badge?: string;
    tags?: string[];
  }[];
  className?: string;
}) => {
  let [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <div
      className={cn(
        "grid grid-cols-1 py-10 md:grid-cols-2 lg:grid-cols-3",
        className,
      )}
    >
      {items.map((item, idx) => (
        <Link
          to={item?.link ?? ""}
          key={item?.key}
          className="group relative block h-full w-full p-2"
          onMouseEnter={() => setHoveredIndex(idx)}
          onMouseLeave={() => setHoveredIndex(null)}
          target={item.openInNew ? "_blank" : "_self"}
        >
          <AnimatePresence>
            {hoveredIndex === idx && (
              <motion.span
                className="absolute inset-0 block h-full w-full rounded-xl bg-neutral-200 dark:bg-zinc-900/[0.8] -z-[20]"
                layoutId="hoverBackground"
                initial={{ opacity: 0 }}
                animate={{
                  opacity: 1,
                  transition: { duration: 0.15 },
                }}
                exit={{
                  opacity: 0,
                  transition: { duration: 0.15, delay: 0.2 },
                }}
              />
            )}
          </AnimatePresence>
          <CardWraper icon={item.icon} title={item.title} description={item.description} tags={item.tags} />
        </Link>
      ))}
    </div>
  );
};

const CardWraper = ({
  icon,
  title,
  description,
  // badge,
  tags
}: {
  title: string;
  description: string;
  icon?: IconNameProp;
  tag?: string;
  badge?: string;
  tags?: string[]
}) => {
  return (
    <Card>
      {icon &&
        <Icon name={icon} className="mb-1 size-5" />
      }
      <CardTitle>{title}</CardTitle>
      <CardDescription>{description}</CardDescription>
      <div className="flex items-center gap-1">
        {
          tags?.map((el) => (
            <span key={el} className="mt-2 inline-flex w-fit rounded-full px-[10px] py-[2px] bg-secondary border border-white/40 text-xs font-medium text-white">
              {el}
            </span>
          ))
        }
      </div>
    </Card>
  )
}

const Card = ({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) => {
  return (
    <div
      className={cn(
        "relative z-20 h-full w-full overflow-hidden rounded-lg border  bg-secondary/50 p-4 ",
        className,
      )}
    >
      <div className="relative z-50">
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
};
const CardTitle = ({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) => {
  return (
    <h4
      className={cn(
        "line-clamp-1 font-bold tracking-wide text-neutral-800 dark:text-neutral-100",
        className,
      )}
    >
      {children}
    </h4>
  );
};
const CardDescription = ({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) => {
  return (
    <p
      className={cn(
        "mt-2 line-clamp-2 text-sm leading-relaxed tracking-wide text-neutral-500 dark:text-neutral-400",
        className,
      )}
    >
      {children}
    </p>
  );
};
