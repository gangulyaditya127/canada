import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Globe } from 'lucide-react'
import i18next from "i18next";
import { cn } from "@/lib/tailwind.utils";
import { useTranslation } from "react-i18next";
const LANGUAGES = [
    {
        code: 'en',
        name: 'English'
    },
    {
        code: 'pt',
        name: 'Português'
    },
    {
        code: 'es',
        name: 'Español'
    },
]
export default function LanguageToggle({
    className
}: {
    className?: string
}) {
    const { i18n } = useTranslation()
    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button
                    variant="ghost"
                    className={cn("rounded-2xl gap-1 px-4", className)}
                >
                    <Globe className="h-5 w-5 shrink-0 text-primary" />
                    <span className=" capitalize">{i18n.language}</span>

                    <span className="sr-only">Change Language</span>
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                {
                    LANGUAGES.map((lang) => (
                        <DropdownMenuItem key={lang.code} onClick={() => i18next.changeLanguage(lang.code)}>
                            {lang.name}
                        </DropdownMenuItem>
                    ))
                }
            </DropdownMenuContent>
        </DropdownMenu>
    );
}