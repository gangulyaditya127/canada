import Loader from "./loader";
import { TextShimmer } from "./text-shimmer";
import { cn } from "@/lib/tailwind.utils";

const LoadingAuthentication = ({
    className
}: {
    className?: string
}) => {
    return (
        <div className={cn("h-screen w-full grid place-items-center", className)}>
            <div className="flex items-center gap-2">
                <Loader />
                <TextShimmer>
                    Authenticating
                </TextShimmer>
            </div>
        </div>
    );
};

export default LoadingAuthentication;