import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

interface OptionChipProps {
    option: string;
    isSelected: boolean;
    onClick: () => void;
    className?: string;
}

export const OptionChip = ({ option, isSelected, onClick, className }: OptionChipProps) => {
    return (
        <Badge
            variant={isSelected ? "default" : "outline"}
            className={cn(
                "cursor-pointer px-4 py-2 text-sm transition-all duration-200 hover:scale-[1.05]",
                isSelected && "gap-1",
                className
            )}
            onClick={onClick}
        >
            {isSelected && <Check className="h-3 w-3" />}
            {option}
        </Badge>
    );
};
