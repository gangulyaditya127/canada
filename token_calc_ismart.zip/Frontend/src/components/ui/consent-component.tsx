import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "./button"
import { useState } from "react";
import { NavigateBackButton } from "./navigate-back-button";

export const UserConsent = () => {
    const [open, setOpen] = useState(true);
    return (
        <Dialog defaultOpen={true} open={open}>
            <DialogContent className="sm:max-w-6xl">
                <DialogHeader>
                    <NavigateBackButton />
                    <DialogTitle>Attention</DialogTitle>
                    <DialogDescription>
                        For your safety and the security of our platform, please be aware of the following
                    </DialogDescription>
                </DialogHeader>
                <div className="text-muted-foreground text-sm space-y-4">
                    <div>
                        <p className="text-primary">Do Not Upload Sensitive Information or Documents of any customer.</p>
                    </div>
                    <div className=" space-y-1">
                        <p className="text-primary">No Sensitive Personal Data</p>
                        <p>Do not upload or input any sensitive personal data, including but not limited to Social Security numbers, credit card information, bank account details, medical records, or any other personal identifiers.</p>
                    </div>
                    <div className="space-y-1">
                        <p className="text-primary">No Confidential Business Information</p>
                        <p>Do not share confidential business information, such as proprietary documents, trade secrets, financial records, or any other corporate-sensitive data.</p>
                    </div>
                    <div className="space-y-1">
                        <p className="text-primary">Protection Compliance</p>
                        <p>Ensure all data shared complies with applicable data protection regulations and policies.</p>
                    </div>
                    <div className="space-y-1">
                        <p className="text-primary">Cooperation is Essential</p>
                        <p>By adhering to these guidelines, you help us maintain a secure and trustworthy environment for all users. If any associate found non-compliant related to the above requirements, TCS incident management process will be followed against the associate.</p>
                    </div>
                </div>
                <DialogFooter className="sm:justify-start">
                    <Button type="button" variant="primary" className="ml-auto" onClick={() => setOpen(false)}>
                        Accept & Continue
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

