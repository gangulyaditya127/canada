import "@blocknote/core/fonts/inter.css";
import { BlockNoteView, Theme } from "@blocknote/mantine";
import "@blocknote/mantine/style.css";
import { useCreateBlockNote } from "@blocknote/react";
import { useTheme } from "../theme-provider";

export default function Editor() {
    // Creates a new editor instance.
    const {theme}=useTheme()

    const editor = useCreateBlockNote();

    // Renders the editor instance using a React component.
    return <BlockNoteView editor={editor} theme={theme as Theme}/>;
}
