import { AgGridReact } from "ag-grid-react";
import "ag-grid-charts-enterprise";

import useDerivedTheme from "@/lib/hooks/useDerivedTheme";
import {
    ClientSideRowModelModule,
    // GridOptions,
    ModuleRegistry,
    themeQuartz,
} from "ag-grid-community";
import { forwardRef, useMemo } from "react";
import { RowGroupingModule } from "ag-grid-charts-enterprise";

ModuleRegistry.registerModules([
    ClientSideRowModelModule,
    RowGroupingModule,
]);

const themeDark = themeQuartz
    .withParams({
        backgroundColor: "#0A0A0A",
        browserColorScheme: "dark",
        // columnBorder: false,
        fontFamily: "inherit",
        foregroundColor: "#FAFAFA",
        headerBackgroundColor: "#101010",
        headerColumnBorder: true,
        oddRowBackgroundColor: "#101010",
        fontSize: 14,
        headerFontSize: 13,
        iconSize: 12,
        columnBorder: true,
    });
const themeLight = themeQuartz
    .withParams({
        fontSize: 14,
        headerFontSize: 13,
        iconSize: 12,
        columnBorder: true,
        headerColumnBorder: true,
    })

import type {
    AgGridReactProps,
} from "ag-grid-react";

interface DataGridProps
    extends AgGridReactProps<any> { }

const DataGrid = forwardRef<AgGridReact<any>, DataGridProps>(
    ({ ...options }: DataGridProps, ref) => {
        const theme = useDerivedTheme();
        const derived = useMemo(() => {
            return theme == 'dark' ? themeDark : themeLight
        }, [theme]);
        return (
            <AgGridReact<any>
                theme={
                    derived
                }
                ref={ref}
                {...options}
            />
        )
    }
)

export default DataGrid;