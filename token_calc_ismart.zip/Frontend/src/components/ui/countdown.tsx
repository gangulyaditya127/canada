import { cn } from "@/lib/tailwind.utils";
import { useAnimate } from "framer-motion";
import { useEffect, useRef, useState } from "react";

// NOTE: Change this date to whatever date you want to countdown to :)


const SECOND = 1000;
const MINUTE = SECOND * 60;
const HOUR = MINUTE * 60;
const DAY = HOUR * 24;
type UnitType = "Day" | "Hour" | "Minute" | "Second"
type CountDownProps = {
    countDownFrom: string,
    className?: string,
    countDownItemClassName?: string
    countDownItemLabelClassName?: string
    countDownItemCounterClassName?: string
}
const CountDown = (
    {
        countDownFrom,
        className,
        ...rest
    }: CountDownProps
) => {
    return (
        <div className={cn("flex items-center", className)}>
            <CountdownItem unit="Day" text="Days" countDownFrom={countDownFrom} {...rest} />
            <CountdownItem unit="Hour" text="Hours" countDownFrom={countDownFrom} {...rest} />
            <CountdownItem unit="Minute" text="Minutes" countDownFrom={countDownFrom} {...rest} />
            <CountdownItem unit="Second" text="Seconds" countDownFrom={countDownFrom} {...rest} />
        </div>
    );
};

type CountdownItemProps = {
    unit: UnitType,
    text: string,
    countDownFrom: string,
    countDownItemClassName?: string
    countDownItemLabelClassName?: string
    countDownItemCounterClassName?: string
}

const CountdownItem = ({ unit, text, countDownFrom, countDownItemClassName,countDownItemLabelClassName,countDownItemCounterClassName }: CountdownItemProps) => {
    const { ref, time } = useTimer(unit, countDownFrom);

    return (
        <div className={cn("flex  w-1/4 flex-col items-center justify-center gap-1 md:gap-2", countDownItemClassName)}>
            <div className="relative w-full overflow-hidden text-center">
                <p
                    ref={ref}
                    className={countDownItemCounterClassName??""}
                >
                    {time}
                </p>
            </div>
            <span className={cn("text-xs",countDownItemLabelClassName)}>
                {text}
            </span>
        </div>
    );
};

export default CountDown;

// NOTE: Framer motion exit animations can be a bit buggy when repeating
// keys and tabbing between windows. Instead of using them, we've opted here
// to build our own custom hook for handling the entrance and exit animations
const useTimer = (unit: UnitType, countDownFrom: string) => {
    const [ref, animate] = useAnimate();
    const intervalRef = useRef<any>(null);
    const timeRef = useRef(0);

    const [time, setTime] = useState(0);

    useEffect(() => {
        intervalRef.current = setInterval(handleCountdown, 1000);

        return () => clearInterval(intervalRef.current || undefined);
    }, []);

    const handleCountdown = async () => {
        const end = new Date(countDownFrom);
        const now = new Date();
        const distance = +end - +now;

        let newTime = 0;

        if (unit === "Day") {
            newTime = Math.floor(distance / DAY);
        } else if (unit === "Hour") {
            newTime = Math.floor((distance % DAY) / HOUR);
        } else if (unit === "Minute") {
            newTime = Math.floor((distance % HOUR) / MINUTE);
        } else {
            newTime = Math.floor((distance % MINUTE) / SECOND);
        }

        if (newTime !== timeRef.current) {
            // Exit animation
            await animate(
                ref.current,
                { y: ["0%", "-50%"], opacity: [1, 0] },
                { duration: 0.35 }
            );

            timeRef.current = newTime;
            setTime(newTime);

            // Enter animation
            await animate(
                ref.current,
                { y: ["50%", "0%"], opacity: [0, 1] },
                { duration: 0.35 }
            );
        }
    };

    return { ref, time };
};