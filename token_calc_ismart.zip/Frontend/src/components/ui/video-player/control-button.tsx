import { cn } from "@/lib/tailwind.utils";
import * as Tooltip from "@radix-ui/react-tooltip";
import { Icon } from "@/components/ui/icon";
import {
  CaptionButton,
  FullscreenButton,
  isTrackCaptionKind,
  MuteButton,
  PIPButton,
  PlayButton,
  useMediaState,
} from "@vidstack/react";

import { buttonVariants } from "../button";

export interface MediaButtonProps {
  tooltipSide?: Tooltip.TooltipContentProps["side"];
  tooltipAlign?: Tooltip.TooltipContentProps["align"];
  tooltipOffset?: number;
  variant?:
  | "link"
  | "ghost"
  | "default"
  | "destructive"
  | "outline"
  | "secondary"
  | null;
  className?: string;
  size?: "default" | "sm" | "lg" | "icon" | null;
}

export const buttonClass =
  "group ring-media-focus relative inline-flex h-10 w-10 cursor-pointer items-center justify-center rounded-md outline-none ring-inset hover:bg-white/20 focus-visible:ring-4 aria-disabled:hidden";

export const tooltipClass =
  "animate-out fade-out slide-out-to-bottom-2 data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in data-[state=delayed-open]:slide-in-from-bottom-4 z-10 rounded-sm bg-black/90 px-2 py-0.5 text-sm font-medium text-white parent-data-[open]:hidden";

export function Play({
  tooltipOffset = 0,
  tooltipSide = "top",
  tooltipAlign = "center",
  className = "",
  variant = "ghost",
  size,
}: MediaButtonProps) {
  const isPaused = useMediaState("paused");
  return (
    <Tooltip.Root>
      <Tooltip.Trigger asChild>
        <PlayButton
          className={cn(buttonVariants({ variant, size, className }))}
        >
          {isPaused ? (
            <Icon name="play" className="size-6 translate-x-px" />
          ) : (
            <Icon name="pause" className="size-6" />
          )}
        </PlayButton>
      </Tooltip.Trigger>
      <Tooltip.Content
        className={tooltipClass}
        side={tooltipSide}
        align={tooltipAlign}
        sideOffset={tooltipOffset}
      >
        {isPaused ? "Play" : "Pause"}
      </Tooltip.Content>
    </Tooltip.Root>
  );
}

export function Mute({
  tooltipOffset = 0,
  tooltipSide = "top",
  tooltipAlign = "center",
  className = "",
  variant = "ghost",
  size,
}: MediaButtonProps) {
  const volume = useMediaState("volume"),
    isMuted = useMediaState("muted");

  let volumeIcon: React.ReactNode;

  if (isMuted || volume === 0) {
    volumeIcon = <Icon name="volume-x" className="size-6" />;
  } else if (volume < 0.5) {
    volumeIcon = <Icon name="volume-1" className="size-6" />;
  } else {
    volumeIcon = <Icon name="volume-2" className="size-6" />;
  }

  return (
    <Tooltip.Root>
      <Tooltip.Trigger asChild>
        <MuteButton
          className={cn(buttonVariants({ variant, size, className }))}
        >
          {volumeIcon}
        </MuteButton>
      </Tooltip.Trigger>
      <Tooltip.Content
        className={tooltipClass}
        side={tooltipSide}
        align={tooltipAlign}
        sideOffset={tooltipOffset}
      >
        {isMuted ? "Unmute" : "Mute"}
      </Tooltip.Content>
    </Tooltip.Root>
  );
}

export function Caption({
  tooltipOffset = 0,
  tooltipSide = "top",
  tooltipAlign = "center",
  className = "",
  variant = "ghost",
  size,
}: MediaButtonProps) {
  const track = useMediaState("textTrack"),
    isOn = track && isTrackCaptionKind(track);
  return (
    <Tooltip.Root>
      <Tooltip.Trigger asChild>
        <CaptionButton
          className={cn(buttonVariants({ variant, size, className }))}
        >
          <Icon
            name="expand"
            className={`size-6 ${!isOn ? "text-white/60" : ""}`}
          />
        </CaptionButton>
      </Tooltip.Trigger>
      <Tooltip.Content
        className={tooltipClass}
        side={tooltipSide}
        align={tooltipAlign}
        sideOffset={tooltipOffset}
      >
        {isOn ? "Closed-Captions Off" : "Closed-Captions On"}
      </Tooltip.Content>
    </Tooltip.Root>
  );
}

export function PIP({
  tooltipOffset = 0,
  tooltipSide = "top",
  tooltipAlign = "center",
  className = "",
  variant = "ghost",
  size,
}: MediaButtonProps) {
  const isActive = useMediaState("pictureInPicture");
  return (
    <Tooltip.Root>
      <Tooltip.Trigger asChild>
        <PIPButton className={cn(buttonVariants({ variant, size, className }))}>
          {isActive ? (
            <Icon name="picture-in-picture" className="size-6" />
          ) : (
            <Icon name="picture-in-picture-2" className="size-6" />
          )}
        </PIPButton>
      </Tooltip.Trigger>
      <Tooltip.Content
        className={tooltipClass}
        side={tooltipSide}
        align={tooltipAlign}
        sideOffset={tooltipOffset}
      >
        {isActive ? "Exit PIP" : "Enter PIP"}
      </Tooltip.Content>
    </Tooltip.Root>
  );
}

export function Fullscreen({
  tooltipOffset = 0,
  tooltipSide = "top",
  tooltipAlign = "center",
  className = "",
  variant = "ghost",
  size,
}: MediaButtonProps) {
  const isActive = useMediaState("fullscreen");
  return (
    <Tooltip.Root>
      <Tooltip.Trigger asChild>
        <FullscreenButton
          className={cn(buttonVariants({ variant, size, className }))}
        >
          {isActive ? (
            <Icon name="expand" className="size-6" />
          ) : (
            <Icon name="expand" className="size-7" />
          )}
        </FullscreenButton>
      </Tooltip.Trigger>
      <Tooltip.Content
        className={tooltipClass}
        side={tooltipSide}
        align={tooltipAlign}
        sideOffset={tooltipOffset}
      >
        {isActive ? "Exit Fullscreen" : "Enter Fullscreen"}
      </Tooltip.Content>
    </Tooltip.Root>
  );
}
