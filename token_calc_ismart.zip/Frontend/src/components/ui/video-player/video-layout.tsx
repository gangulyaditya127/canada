import * as Tooltip from "@radix-ui/react-tooltip";
import { Controls, Gesture, PlayButton } from "@vidstack/react";

import { Play, Mute, PIP, Fullscreen } from "./control-button";
import { Time, Volume } from "./control-slider";
import { TimeGroup } from "./time-group";
import { Title } from "./title";
import { motion } from "framer-motion";
import { BufferingIndicator } from "./buffering-indicator";
import { Icon } from "@/components/ui/icon";
// Offset tooltips/menus/slider previews in the lower controls group so they're clearly visible.
const popupOffset = 30;

export interface VideoLayoutProps {
  thumbnails?: string;
}

export function VideoLayout({ }: VideoLayoutProps) {

  return (
    <>
      <Gestures />
      {false ? (
        <motion.div
          className="z-12 absolute grid h-full w-full place-items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <PlayButton
            className={`backdrop-blur-xs hover:opacity-1 relative z-10 inline-flex size-20 items-center justify-center whitespace-nowrap rounded-full bg-black/80 bg-slate-100/80 text-sm font-medium ring-offset-background transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 supports-[backdrop-filter]:bg-black/60`}
          >
            <Icon name="play" />
          </PlayButton>
          <div className="backdrop-blur-xs pointer-events-none absolute h-full w-full rounded-xl bg-black/60 bg-slate-100/60 supports-[backdrop-filter]:bg-black/40"></div>
        </motion.div>
      ) : (
        <motion.div>
          <Controls.Root className="background-red-800 absolute inset-0 z-10 flex h-full w-full flex-col bg-gradient-to-t from-black/90 to-transparent opacity-0 transition-opacity media-controls:opacity-100">
            <Tooltip.Provider>
              <div className="flex-1" />
              <Controls.Group className="flex w-full items-center px-2 py-2">
                <Time />
              </Controls.Group>
              <Controls.Group className="-mt-0.5 flex w-full items-center gap-2 px-2 pb-2">
                <Play tooltipAlign="start" tooltipOffset={popupOffset} />
                <Mute tooltipOffset={popupOffset} />
                <Volume />
                <TimeGroup />
                <Title />
                <div className="flex-1" />
                <PIP tooltipOffset={popupOffset} />
                <Fullscreen tooltipAlign="end" tooltipOffset={popupOffset} />
              </Controls.Group>
            </Tooltip.Provider>
          </Controls.Root>
          <BufferingIndicator />
        </motion.div>
      )}
    </>
  );
}

function Gestures() {
  return (
    <>
      <Gesture
        className="absolute inset-0 z-0 block h-full w-full"
        event="pointerup"
        action="toggle:paused"
      />
      <Gesture
        className="absolute inset-0 z-0 block h-full w-full"
        event="dblpointerup"
        action="toggle:fullscreen"
      />
      <Gesture
        className="absolute left-0 top-0 z-10 block h-full w-1/5"
        event="dblpointerup"
        action="seek:-10"
      />
      <Gesture
        className="absolute right-0 top-0 z-10 block h-full w-1/5"
        event="dblpointerup"
        action="seek:10"
      />
    </>
  );
}
