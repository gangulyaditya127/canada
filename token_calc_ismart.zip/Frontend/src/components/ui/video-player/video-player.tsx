import "@vidstack/react/player/styles/base.css";

import { useRef, useState } from "react";

import {
  MediaPlayer,
  MediaProvider,
  Poster,
  type MediaPlayerInstance,
} from "@vidstack/react";

export interface VidePlayerProps {
  src: string;
  autoPlay?: boolean;
  loop?: boolean;
  className?: string;
  thumbnail?: any;
  title?: string;
  load?: "eager" | "play" | "idle" | "visible";
}
import { VideoLayout } from "./video-layout";
import { cn } from "@/lib/tailwind.utils";
import Loader from "../loader";

export function VideoPlayer({
  src,
  autoPlay,
  loop,
  className,
  thumbnail,
  title,
  load
}: VidePlayerProps) {
  let player = useRef<MediaPlayerInstance>(null);
  const [canPlay, setCanPlay] = useState(false);
  function onCanPlay() {
    setCanPlay(true);
  }

  return (
    <div className="relative">
      {!canPlay && (
        <div className="z-[100] bg-black/20 absolute grid h-full w-full place-items-center">
          <div className="backdrop-blur-xs hover:opacity-1 relative z-10 inline-flex size-20 items-center justify-center whitespace-nowrap rounded-full bg-black/80 text-sm font-medium ring-offset-background transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 supports-[backdrop-filter]:bg-black/60 pointer-events-none">
            <Loader iconClassName="h-8 w-8" />
          </div>
        </div>
      )}
      {/* <div className="aspect-video w-full rounded-xl z-[1] absolute bg-red-500"></div> */}
      <MediaPlayer
        className={cn(
          "aspect-video w-full overflow-hidden rounded-xl bg-background font-sans text-white ring-media-focus data-[focus]:ring-4",
          className,
        )}
        title={title}
        src={src}
        crossOrigin
        playsInline
        autoPlay={autoPlay ?? false}
        loop={loop ?? false}
        ref={player}
        onCanPlay={onCanPlay}
        keyDisabled
        load={load ?? "eager"}
        posterLoad="eager"
      >
        <MediaProvider>
          <Poster
            className="absolute inset-0 block h-full w-full rounded-md object-cover opacity-0 transition-opacity data-[visible]:opacity-100"
            src={thumbnail}
            alt="video_thumbnail"
          />
        </MediaProvider>
        <VideoLayout />
      </MediaPlayer>
    </div>
  );
}
