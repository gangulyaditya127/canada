import { useEffect, useState } from "react";
import { Slider } from "@/components/ui/slider";
import {
  useMediaRemote,
  useMediaState,
  useSliderPreview,
} from "@vidstack/react";

export function Volume() {
  const volume = useMediaState("volume"),
    canSetVolume = useMediaState("canSetVolume"),
    remote = useMediaRemote();

  if (!canSetVolume) return null;
  return (
    <Slider
      value={[volume * 100]}
      onValueChange={([value]) => {
        remote.changeVolume(value / 100);
      }}
      className="dark max-w-[80px] cursor-pointer"
      trackHeightClass="h-[3px]"
      thumbSizeClass="size-2"
    />
  );
}

export interface TimeSliderProps {
  thumbnails?: string;
}

export function Time() {
  const time = useMediaState("currentTime"),
    canSeek = useMediaState("canSeek"),
    duration = useMediaState("duration"),
    seeking = useMediaState("seeking"),
    remote = useMediaRemote(),
    step = (1 / duration) * 100,
    [value, setValue] = useState(0),
    { previewRootRef } = useSliderPreview({
      clamp: true,
      offset: 6,
      orientation: "horizontal",
    });

  // Keep slider value in-sync with playback.
  useEffect(() => {
    if (seeking) return;
    setValue((time / duration) * 100);
  }, [time, duration]);

  return (
    <Slider
      className="dark w-full cursor-pointer"
      value={[value]}
      disabled={!canSeek}
      step={Number.isFinite(step) ? step : 1}
      ref={previewRootRef}
      onValueChange={([value]) => {
        setValue(value);
        remote.seeking((value / 100) * duration);
      }}
      onValueCommit={([value]) => {
        remote.seek((value / 100) * duration);
      }}
    />
  );
}
