import { useId } from "react";
import { cn } from "@/lib/tailwind.utils";

let fallbackSeed = 999;
const getSecureRandom = () => {
  if (typeof globalThis !== "undefined" && globalThis.crypto?.getRandomValues) {
    const array = new Uint32Array(1);
    globalThis.crypto.getRandomValues(array);
    return array[0] / 4294967296;
  }
  fallbackSeed = (fallbackSeed * 1664525 + 1013904223) % 4294967296;
  return fallbackSeed / 4294967296;
};

export const Meteors = ({
  number,
  className,
}: {
  number?: number;
  className?: string;
}) => {
  const baseId = useId();
  const meteors = new Array(number || 20).fill(true);

  return (
    <>
      {meteors.map((_, idx) => (
        <span
          key={`${baseId}-meteor-${idx}`}
          className={cn(
            "absolute left-1/2 top-1/2 h-0.5 w-0.5 rotate-[215deg] animate-meteor-effect rounded-[9999px] bg-slate-500 shadow-[0_0_0_1px_#ffffff10]",
            "before:absolute before:top-1/2 before:h-[1px] before:w-[50px] before:-translate-y-[50%] before:transform before:bg-gradient-to-r before:from-[#64748b] before:to-transparent before:content-['']",
            className,
          )}
          style={{
            top: 0,
            left: Math.floor(getSecureRandom() * (400 - -400) + -400) + "px",
            animationDelay: getSecureRandom() * (0.8 - 0.2) + 0.2 + "s",
            animationDuration: Math.floor(getSecureRandom() * (10 - 2) + 2) + "s",
          }}
        />
      ))}
    </>
  );
};