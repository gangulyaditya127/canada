import { cn } from "@/lib/tailwind.utils";
import React, { useEffect, useState } from "react";

export const InfiniteMovingBlock = ({
  children,
  direction = "left",
  speed = "fast",
  pauseOnHover = true,
  className,
  containerClassName,
  mask = true,
  ...props
}: {
  children: any;
  direction?: "left" | "right";
  speed?: "fast" | "normal" | "slow" | "extremeslow";
  pauseOnHover?: boolean;
  className?: string;
  containerClassName?: string
  mask: boolean
  onClick?: () => void
}) => {
  const containerRef = React.useRef<HTMLDivElement>(null);
  const scrollerRef = React.useRef<HTMLUListElement>(null);

  useEffect(() => {
    addAnimation();
  }, []);
  const [start, setStart] = useState(false);
  function addAnimation() {
    if (containerRef.current && scrollerRef.current) {
      const scrollerContent = Array.from(scrollerRef.current.children);

      scrollerContent.forEach((item) => {
        const duplicatedItem = item.cloneNode(true);
        if (scrollerRef.current) {
          scrollerRef.current.appendChild(duplicatedItem);
        }
      });

      getDirection();
      getSpeed();
      setStart(true);
    }
  }
  const getDirection = () => {
    if (containerRef.current) {
      if (direction === "left") {
        containerRef.current.style.setProperty(
          "--animation-direction",
          "forwards",
        );
      } else {
        containerRef.current.style.setProperty(
          "--animation-direction",
          "reverse",
        );
      }
    }
  };
  const getSpeed = () => {
    if (containerRef.current) {
      switch (speed) {
        case 'fast':
          containerRef.current.style.setProperty("--animation-duration", "20s");
          break;
        case 'normal':
          containerRef.current.style.setProperty("--animation-duration", "40s");
          break;
        case 'slow':
          containerRef.current.style.setProperty("--animation-duration", "80s");
          break;
        case 'extremeslow':
          containerRef.current.style.setProperty("--animation-duration", "110s");
          break;
        default:
          containerRef.current.style.setProperty("--animation-duration", "40s");
      }

    }
  };
  return (
    <div
      ref={containerRef}
      className={cn(
        "scroller relative z-20 w-full overflow-hidden",
        mask && "[mask-image:linear-gradient(to_right,transparent,black_20%,black_95%,transparent)]",
        className,

      )}
      {...props}
    >
      <ul
        ref={scrollerRef}
        className={cn(
          "flex w-max min-w-full shrink-0 flex-nowrap gap-4 py-4",
          start && "animate-scroll",
          pauseOnHover && "hover:[animation-play-state:paused]",
          containerClassName
        )}
      >
        {children}
      </ul>
    </div>
  );
};
