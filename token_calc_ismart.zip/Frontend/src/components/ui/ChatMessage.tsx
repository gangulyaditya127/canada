import { cn } from "@/lib/utils";

interface ChatMessageProps {
    message: string;
    isBot: boolean;
    className?: string;
}

export const ChatMessage = ({ message, isBot, className }: ChatMessageProps) => {
    return (
        <div
            className={cn(
                "flex w-full animate-slide-up",
                isBot ? "justify-start" : "justify-end",
                
                className
            )}
        >
            <div
                className={cn(
                    "max-w-[80%] rounded-2xl px-4 py-3 shadow-sm bg-chat-user text-chat-user-foreground border border-border rounded-tr-sm",
                    !isBot && "bg-blue-500 text-white",
                    // isBot
                    //     ? "bg-chat-bot text-chat-bot-foreground rounded-tl-sm"
                    //     : "bg-chat-user text-chat-user-foreground border border-border rounded-tr-sm"
                )}
            >
                <p className="text-sm leading-relaxed">{message}</p>
            </div>
        </div>
    );
};
