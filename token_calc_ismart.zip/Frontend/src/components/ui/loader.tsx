import { cn } from "@/lib/tailwind.utils"
import { Loader as LoaderIcon } from "lucide-react"



type loaderProps = {
    children?: React.ReactNode
    className?: string
    iconClassName?:string
}

export default function Loader({ className, children ,iconClassName}: loaderProps) {
    return (<div className={cn("flex items-center", className)}>
        <LoaderIcon className={cn("h-5 w-5 animate-spin",iconClassName)} />
        {children}
    </div>)
}