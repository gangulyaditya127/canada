import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";
import { z } from "zod";
import { useToast } from "@/components/ui/use-toast";
import { Textarea } from "./textarea";

const messageSchema = z
    .string()
    .trim()
    .min(1, { message: "Message cannot be empty" })
    .max(500, { message: "Message must be less than 500 characters" });

interface ChatInputProps {
    onSubmit: (message: string) => void;
    disabled?: boolean;
    placeholder?: string;
}

export const ChatInput = ({ onSubmit, disabled, placeholder = "Type your response..." }: ChatInputProps) => {
    const [input, setInput] = useState("");
    const { toast } = useToast();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        try {
            const validatedInput = messageSchema.parse(input);
            onSubmit(validatedInput);
            setInput("");
        } catch (error) {
            if (error instanceof z.ZodError) {
                toast({
                    title: "Invalid input",
                    description: error.issues[0].message,
                    variant: "destructive",
                });
            }
        }
    };

    return (
        <form onSubmit={handleSubmit} className="flex gap-2 relative">
            <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={placeholder}
                disabled={disabled}
                className="flex-1 p-3 pr-8 min-h-1"
                maxLength={500}
            />
            <div className="absolute h-full right-0 z-10 flex flex-col w-12">
                <Button type="submit" size="icon" disabled={disabled || !input.trim()} className="mt-auto h-full w-full">
                    <Send className="h-5 w-5" />
                </Button>
            </div>

        </form>
    );
};
