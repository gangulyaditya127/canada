import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface OptionButtonProps {
    option: string;
    isSelected?: boolean;
    onClick: () => void;
    className?: string;
}

export const OptionButton = ({ option, isSelected, onClick, className }: OptionButtonProps) => {
    return (
        <Button
            variant={isSelected ? "default" : "outline"}
            onClick={(e) => {
                e.currentTarget.blur();
                onClick()
            }}
            className={cn(
                "justify-start text-left transition-all duration-200 hover:scale-[1.02]",
                isSelected && "ring-2 ring-primary ring-offset-2",
                className
            )}
            tabIndex={-1}
        >
            {option}
        </Button>
    );
};
