
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

export default defineConfig({
    plugins: [react()],
    resolve: {
        alias: {
            "@": path.resolve(__dirname, "../../../src"),
        },
    },
    build: {
        // outDir: 'C:\\Users\\2096742\\Backend\\test2\\are-quick-assesment-report-dist',
        outDir: 'are-quick-assesment-report-dist',
        emptyOutDir: true,
        lib: {
            entry: path.resolve(__dirname, 'index.tsx'),
            name: 'ReportStandalone',
            formats: ['iife'],
            fileName: () => 'runtime.js',
        },
        rollupOptions: {
            output: {
                inlineDynamicImports: true,
                assetFileNames: (assetInfo) => assetInfo.name ?? 'asset-[hash][extname]',
            },
        },
        assetsInlineLimit: 1000000,
        cssCodeSplit: false,
    },
});
