export function loadStateFromLocal(key: string) {
  try {
    const serializedState = localStorage.getItem(key);
    if (!serializedState) return undefined;
    return JSON.parse(serializedState);
  } catch (e) {
    return undefined;
  }
}

export function saveStateToLocal(state: any, key: string) {
  try {
    const serializedState = JSON.stringify(state);
    localStorage.setItem(key, serializedState);
  } catch (e) {
    // Ignore
  }
}

export function deteteFromLocal(key: string) {
  try {
    localStorage.removeItem(key);
  } catch (e) {}
}
