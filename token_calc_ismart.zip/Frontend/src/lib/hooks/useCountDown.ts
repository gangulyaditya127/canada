
import { useEffect, useMemo, useRef, useState } from "react";
type SlaInput =
    | { minutes: number }
    | { seconds: number }
    | { ms: number };

type Countdown = {
    minutes: number;
    seconds: number;
    totalSeconds: number;
    isExpired: boolean;
};

export function useCountdownToSLA(
    createdAt: Date | number | string,
    slaTime: SlaInput,
    tickMs: number = 1000,
    onExpire?: () => void
): Countdown {
    const createdAtMs = useMemo(() => {
        if (createdAt instanceof Date) return createdAt.getTime();
        if (typeof createdAt === "number") return createdAt; // assume ms timestamp
        const parsed = Date.parse(createdAt);
        return Number.isNaN(parsed) ? 0 : parsed;
    }, [createdAt]);

    const slaMs = useMemo(() => {
        if ("ms" in slaTime) return Math.max(0, Math.floor(slaTime.ms));
        if ("seconds" in slaTime)
            return Math.max(0, Math.floor(slaTime.seconds)) * 1000;
        if ("minutes" in slaTime)
            return Math.max(0, Math.floor(slaTime.minutes)) * 60 * 1000;
        return 0;
    }, [slaTime]);

    const [state, setState] = useState<Countdown>(() => ({
        minutes: 0,
        seconds: 0,
        totalSeconds: 0,
        isExpired: false,
    }));

    const endTimeRef = useRef<number | null>(null);
    const expiredRef = useRef<boolean>(false);

    useEffect(() => {
        if (createdAtMs <= 0 || slaMs <= 0) {
            setState({
                minutes: 0,
                seconds: 0,
                totalSeconds: 0,
                isExpired: true,
            });
            return;
        }
        endTimeRef.current = createdAtMs + slaMs;
        expiredRef.current = false;
        const tick = () => {
            const now = Date.now();
            const remainingMs = Math.max(0, (endTimeRef.current ?? 0) - now);
            const totalSeconds = Math.floor(remainingMs / 1000);
            const minutes = Math.floor(totalSeconds / 60);
            const seconds = totalSeconds % 60;

            const isExpired = totalSeconds <= 0;

            console.log({ now, remainingMs, totalSeconds, t: endTimeRef.current })

            setState({ minutes, seconds, totalSeconds, isExpired });

            if (isExpired && !expiredRef.current) {
                expiredRef.current = true;
                if (onExpire) {
                    try {
                        onExpire();
                    } catch {
                    }
                }
            }
        };
        tick();
        const id = setInterval(tick, Math.max(250, tickMs)); // guard against too small intervals
        return () => clearInterval(id);
    }, [createdAtMs, slaMs, tickMs, onExpire]);
    return state;
}