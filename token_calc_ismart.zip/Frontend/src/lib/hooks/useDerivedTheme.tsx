import { useTheme } from "@/components/theme-provider";
import { useEffect, useState } from "react";

const useDerivedTheme = () => {
  const [systemDerivedTheme, setSystemDerivedTheme] = useState<
    "light" | "dark"
  >();
  const { theme } = useTheme();

  useEffect(() => {
    if (theme === "system") {
      setSystemDerivedTheme(
        window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : "light",
      );
      return;
    }
    setSystemDerivedTheme(theme);
  }, [theme]);

  return systemDerivedTheme;
};
export default useDerivedTheme;
