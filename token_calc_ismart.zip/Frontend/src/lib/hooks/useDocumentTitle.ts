
import { useEffect } from 'react';
function usePageTitle({ title }: { title: string }) {
    useEffect(() => {
        if (title) {
            document.title = title;
        }
    }, [title]);
}

export default usePageTitle;
