import { configureStore } from "@reduxjs/toolkit";
import sidebarNavigationSlice from "@/components/layout/slice/sidebar-navigation";
import topbarNavigation from "@/components/layout/slice/topbar-navigation";

import authSlice from "@/auth/slice/authSlice";
import keyclockAuthSlice from "@/auth/slice/keyClockAuthSlice";
import { authAPI } from "@/auth/slice/authAPISlice";
import { keyClockAPI } from "@/auth/slice/keyClockAPISlice";
import { statsAPI } from "@/stats/slice/statsAPISlice";
import { tokenCalculatorAPISlice } from "@/application/token_calculator/slice/tokenCalculatorAPISlice";

export const store = configureStore({
  reducer: {
    sideNav: sidebarNavigationSlice,
    topNav: topbarNavigation,
    auth: authSlice,
    [authAPI.reducerPath]: authAPI.reducer,
    keyClockAuthSlice: keyclockAuthSlice,
    [keyClockAPI.reducerPath]: keyClockAPI.reducer,
    [statsAPI.reducerPath]: statsAPI.reducer,
    [tokenCalculatorAPISlice.reducerPath]: tokenCalculatorAPISlice.reducer,

  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(
      authAPI.middleware,
      keyClockAPI.middleware,
      statsAPI.middleware,
      tokenCalculatorAPISlice.middleware,
    ),
});
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;