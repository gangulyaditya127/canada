export const filterNullValues = (obj: any): any => {
    return Object.entries(obj).reduce((acc: any, [key, value]) => {
        if (value !== null && value !== undefined && value != '') {
            if (typeof value === 'object') {
                acc[key] = filterNullValues(value)
            } else {
                acc[key] = value
            }
        }
        return acc;
    }, {})
}