export function getImageURL(name: string) {
  const IMG = new URL(`../assets/${name}`, import.meta.url).href;
  return IMG;
}
