export const getNthDate = (dayCount: number) => {
    const today = new Date();
    const nthDay = new Date(today.setDate(today.getDate() + 1 + dayCount))
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    }).format(nthDay)
}
export const getNthDateNumericFormat = (dayCount: number) => {
    const today = new Date();
    const nthDay = new Date(today.setDate(today.getDate() + 1 + dayCount))
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'numeric',
        day: 'numeric'
    }).format(nthDay)
}

export const getFormatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-us', {
        dateStyle: 'full',
        timeStyle: 'medium'
    }).format(date)
}

export const getNthHourNumericFormat = (hourCount: number) => {
    const today = new Date();
    const nthHour = new Date(today.setHours(today.getHours() + 1 + hourCount));
    return new Intl.DateTimeFormat('en-US', {
        dateStyle: "short",
        timeStyle: 'medium'
    }).format(nthHour)
}

export const getNthHour = (hourCount: number) => {
    const today = new Date();
    const nthHour = new Date(today.setHours(today.getHours() + hourCount));
    return nthHour.toISOString();
}
export const getNthMinuteDate = (minuteCount: number) => {
    const today = new Date();
    return new Date(today.setMinutes(today.getMinutes() + minuteCount))
}