import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

export interface UmamiPayload {
  hostname: string;
  language: string;
  referrer: string;
  screen: string;
  title: string;
  url: string;
  website: string;
  name: string;
  id: string;
  data?: Record<string, any>;
}

export interface UmamiRequest {
  payload: UmamiPayload;
  type: 'event';
}

export const webTrackingApi = createApi({
  reducerPath: 'webTrackingApi',
  baseQuery: fetchBaseQuery({
    baseUrl: import.meta.env.VITE_UMAMI_BASE_URL, // or your self-hosted instance
  }),
  endpoints: (builder) => ({
    trackEvent: builder.mutation<any, UmamiRequest>({
      query: (data) => ({
        url: '/api/send',
        method: 'POST',
        body: data,
        headers: {
          'User-Agent': navigator.userAgent, // Required by Umami
        },
      }),
    }),
  }),
});


export const statsAPI = createApi({
  reducerPath: 'statsAPI',
  baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_API_PYTHON_BASE_URL}` }),
  tagTypes: ['auth_api'],
  endpoints: ({ query }) => ({

    trackVisitCount: query<any, any>({
      query: (queryParams) => ({
        url: `are-ams-quick-maturity/updateVisitCount?module=overall`,
        params: queryParams,
        method: 'POST',
      }),
      // invalidatesTags: [],
    }),
    getOverAllVisitCount: query<any, any>({
      query: (queryParams) => ({
        url: `are-ams-quick-maturity/getTotalCount`,
        params: queryParams,
        method: 'GET',
      }),
      // invalidatesTags: [],
    }),

  }),
})

export const {
  useTrackVisitCountQuery,
  useGetOverAllVisitCountQuery

} = statsAPI

export const { useTrackEventMutation } = webTrackingApi;