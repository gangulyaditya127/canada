import { useAppSelector } from "@/lib/redux/hooks";
import { useCallback, useEffect } from "react";

interface UmamiTrackingOptions {
    includeTimestamp?: boolean;
    includePageInfo?: boolean;
}
export const useWebTrackingScript = (options: UmamiTrackingOptions = {}) => {
    const {
        includeTimestamp = true,
        includePageInfo = true,
    } = options;

    const user = useAppSelector((state) => state.keyClockAuthSlice.user)

    const identifyUser = useCallback(
        (userId: string, userData?: Record<string, any>) => {
            if (window.umami) {
                if (window.umami.identify) {
                    window.umami.identify(userId, userData);
                }
            }
        },
        []
    );

    useEffect(() => {
        if (user?.preferred_username) {
            console.log("calling identifyong user")
            identifyUser(user.preferred_username, { email: user.email, name: user.name })
        }
    }, [user])

    const trackEvent = useCallback(
        (eventName: string, eventData?: Record<string, any>) => {
            if (!window.umami) {
                console.warn('[Umami] Umami script not loaded');
                return;
            }
            const enhancedData = {
                ...(includePageInfo && {
                    pageUrl: window.location.pathname + window.location.hash,
                    pageTitle: document.title,
                }),
                ...(includeTimestamp && {
                    timestamp: new Date().toISOString(),
                }),
                ...(user && { email: user.email, name: user.name }),
                ...eventData,
                id:user?.preferred_username
            };
            window.umami.track(eventName, enhancedData);
        },
        [user, includePageInfo, includeTimestamp]
    );

    return {
        trackEvent,
        identifyUser,
        isLoaded: !!window.umami,
    };
};