import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useWebTracking } from './useWebTracking';
export const usePageTracking = (eventName:string='pageview') => {
    const location = useLocation();
    const { trackAction } = useWebTracking();

    useEffect(() => {
        trackAction(eventName, {
            pathname: window.location.pathname,
            hash: window.location.hash,
            title: document.title,
        });
    }, [location]);
};