// hooks/useWebTracking.ts
import { useAppSelector } from '@/lib/redux/hooks';
import { UmamiRequest, useTrackEventMutation } from '../slice/statsAPISlice';
import { useCallback } from 'react';


const WEBSITE_ID = import.meta.env.VITE_UAMAI_TRACKING_ID;

export const useWebTracking = () => {
    const [trackEvent] = useTrackEventMutation();
    const userId = useAppSelector((state) => state.keyClockAuthSlice.user?.preferred_username)
    const email = useAppSelector((state) => state.keyClockAuthSlice.user?.email)

    const getTrackingPayload = useCallback((
        eventName: string,
        additionalData?: Record<string, any>
    ): UmamiRequest => {
        return {
            payload: {
                hostname: window.location.hostname,
                language: navigator.language,
                referrer: document.referrer || '',
                screen: `${window.screen.width}x${window.screen.height}`,
                title: document.title,
                url: window.location.pathname + window.location.hash,
                website: WEBSITE_ID,
                name: eventName,
                id: userId ?? crypto.randomUUID(),
                data: {
                    "userId": userId,
                    "email": email,
                    ...additionalData,
                },
            },
            type: 'event',
        };
    }, [userId, email]);

    const trackAction = useCallback(
        (actionName: string, actionData?: Record<string, any>) => {
            if (WEBSITE_ID) {
                const payload = getTrackingPayload(actionName, actionData);
                trackEvent(payload);
            }
        },
        [getTrackingPayload, trackEvent]
    );

    return { trackAction };
};