import { useLocation } from "react-router-dom";
import { useWebTrackingScript } from "./useWebTrackingScript";
import { useCallback, useEffect } from "react";

export const useGlobalPageTracking = () => {
    const location = useLocation();
    const { trackEvent } = useWebTrackingScript({
        includePageInfo: true,
    });

    const trackPageView = useCallback(() => {
        if (!window.umami) {
            console.warn('[Umami] Umami not ready yet');
            return;
        }
        const pageInfo = {
            pathname: location.pathname,
            hash: location.hash,
            search: location.search,
        };
        trackEvent('pageview', pageInfo);
        console.log('[Umami] Pageview tracked:', pageInfo);
    }, [location, trackEvent]);

    useEffect(() => {
        trackPageView();
    }, [location, trackPageView]);
};