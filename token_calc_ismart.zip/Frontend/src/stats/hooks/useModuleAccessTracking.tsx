import { useLocation } from "react-router-dom";
import { useWebTrackingScript } from "./useWebTrackingScript";
import { useCallback, useEffect } from "react";

export const useModuleAccessTracking = (moduleName: string = "module-access") => {
    const location = useLocation();
    const { trackEvent } = useWebTrackingScript({
        includePageInfo: true,
    });

    const trackPageView = useCallback(() => {
        if (!window.umami) {
            console.warn('[Umami] Umami not ready yet');
            return;
        }
        const pageInfo = {
            pathname: location.pathname,
            hash: location.hash,
            search: location.search,
        };
        trackEvent(`module-access-${moduleName}`, pageInfo);
        console.log('[Umami] Pageview tracked:', pageInfo);
    }, [trackEvent]);

    useEffect(() => {
        trackPageView();
    }, [location, trackPageView]);
};