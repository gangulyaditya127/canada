import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { ThemeProvider } from "@/components/theme-provider";
import { store } from "@/lib/redux/store";
import { Provider } from "react-redux";
import { RouterProvider } from "react-router-dom";
import { router } from "./router.tsx";
import { Toaster } from "./components/ui/toaster";
import '@/lib/i18/index.ts'
import ErrorFallback from "./components/ux/ErrorFallback.tsx";
import ErrorBoundry from "./components/ux/ErrorBoundry.tsx";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const queryClient = new QueryClient();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <ErrorBoundry fallback={<ErrorFallback />}>
        <Provider store={store}>
          <ThemeProvider defaultTheme="dark" storageKey="ismart-ui-theme">
            <RouterProvider router={router} />
            <Toaster />
          </ThemeProvider>
        </Provider>
      </ErrorBoundry>
    </QueryClientProvider>
  </React.StrictMode >,
);
