import { SideNav } from "@/components/layout/SideNav";
import { TopNav } from "@/components/layout/TopNav";

import { useAppSelector } from "@/lib/redux/hooks";
import { cn } from "@/lib/tailwind.utils";

import { Outlet } from "react-router-dom";
import { useTrackVisitCountQuery } from "./stats/slice/statsAPISlice";
import VisitPill from "./components/ui/visit-pill";

function App() {
  const hasSideBar = useAppSelector((state) => state.sideNav.hasSideBar);
  useTrackVisitCountQuery(null);
  return (
    <div
      className={cn(`min-h-screen w-full`, hasSideBar ? "pl-[56px]" : "")}
      id="ams_are_main_block"
    >
      {hasSideBar && <SideNav />}
      <TopNav hasSideBar={hasSideBar} />
      <main className="">
        <Outlet />
      </main>
      <VisitPill />
    </div>
  );
}

export default App;
