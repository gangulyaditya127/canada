import path from "path";
import react from "@vitejs/plugin-react";
import { defineConfig, type PluginOption } from "vite";

// import viteCompression from 'vite-plugin-compression';
export default defineConfig({
  plugins: [
    react()
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    watch: {
      followSymlinks: false,
    },
    proxy: {
      '/sq': {
        target: 'https://ismartams.tcsapps.com',
        changeOrigin: true,
        secure: false,
        rewrite: (path) => {
          const newPath = path.replace(/^\/sq/, '/sonarqube');
          console.log('[VITE PROXY REWRITE]', path, '→', newPath);
          return newPath;
        },
        configure: (proxy, options) => {
          proxy.on('proxyReq', (proxyReq, req) => {

            console.log(
              '[VITE PROXY HEADERS]',
              proxyReq.getHeader('authorization')
            );

            console.log(
              `[VITE PROXY] ${req.method} ${req.url} → ${options.target}${proxyReq.path}`
            );
          });

          proxy.on('proxyRes', (proxyRes, req) => {
            console.log(
              `[VITE PROXY RES] ${req.method} ${req.url} ← ${proxyRes.statusCode}`
            );
          });

          proxy.on('error', (err, req) => {
            console.error(
              `[VITE PROXY ERROR] ${req.method} ${req.url}`,
              err.message
            );
          });
        },
      },
    },

    fs: {
      allow: ['.']
    }
  },
  build: {
    minify: "terser",
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
      },
    },
    cssMinify: "esbuild",
    rollupOptions: {
      treeshake: true,
    },
    outDir: "dist/token-calculator",
    cssCodeSplit: true,
  },
  base: '/token-calculator/'
});
