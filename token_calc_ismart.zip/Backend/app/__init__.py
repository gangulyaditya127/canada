from flask import Flask, request, jsonify, render_template
from flask_cors import CORS, cross_origin
import os
from datetime import timedelta
from dotenv import load_dotenv
from flasgger import Swagger

import logging

from app.controllers.Token_Calculator.main import app as token_cal_bp


# 

def create_app(test_config=None):
    load_dotenv()
    
    app = Flask(__name__, instance_relative_config=True)
    CORS(app)
    Swagger(app)
    # logger
    
    app.register_blueprint(token_cal_bp)  
    # app.config["TEMPLATES_AUTO_RELOAD"] = True
    # app.config.from_pyfile('../app/config.cfg', silent=True)
    # with app.app_context():
    #     app.config["SETTINGS_CREDENTIALS"] = fetch_credentials()

    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass
    return app
