import os
import urllib.parse
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import (
    Column,
    String,
    Integer,
    Date,
    DateTime,
    TIMESTAMP,
    Text,
    PrimaryKeyConstraint,
    Float,
    ForeignKey,
    CLOB,
)
from sqlalchemy.orm import declarative_base
from sqlalchemy.dialects.postgresql import JSONB
from datetime import datetime

Base = declarative_base()
# SCHEMA = "ismart"
SCHEMA = "public"


# load_dotenv()

load_dotenv()


class Config:
    POSTGRESQL_USERNAME = os.getenv("POSTGRESQL_USERNAME", "postgres")
    POSTGRESQL_PASSWORD = os.getenv("POSTGRESQL_PASSWORD", "StrongPassword123")
    POSTGRESQL_HOST = os.getenv("POSTGRESQL_HOST", "10.169.51.2")
    POSTGRESQL_PORT = os.getenv("POSTGRESQL_PORT", "8081")
    POSTGRESQL_SERVICE_NAME = os.getenv("POSTGRESQL_SERVICE_NAME", "postgres")

    # URL encode the password to handle special characters like @
    ENCODED_PASSWORD = urllib.parse.quote_plus(POSTGRESQL_PASSWORD)

    SQLALCHEMY_DATABASE_URI = (
        f"postgresql+psycopg://{POSTGRESQL_USERNAME}:{ENCODED_PASSWORD}"
        f"@{POSTGRESQL_HOST}:{POSTGRESQL_PORT}/{POSTGRESQL_SERVICE_NAME}"
    )

    SQLALCHEMY_ECHO = False


engine = create_engine(
    Config.SQLALCHEMY_DATABASE_URI,
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def get_session():
    """Creates a new SQLAlchemy session."""
    return SessionLocal()


class Application(Base):
    __tablename__ = "are_applications"
    __table_args__ = {"schema": SCHEMA}

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)



class Service(Base):
    __tablename__ = "are_application_services"
    __table_args__ = {"schema": SCHEMA}

    id = Column(Integer, primary_key=True)
    app_id = Column(Integer,nullable=False)
    name = Column(String(255), nullable=False)
    input_words = Column(Integer, nullable=False)
    output_words = Column(Integer, nullable=False)
    ratio = Column(Float, nullable=False)

    


class ModelPricing(Base):
    __tablename__ = "model_pricing"
    __table_args__ = {"schema": SCHEMA}

    id = Column(Integer, primary_key=True)
    model_name = Column(String(255), nullable=False, unique=True)
    input_price = Column(Float, nullable=False)
    output_price = Column(Float, nullable=False)
