from sqlalchemy import select, func, text, update, or_, and_, case, exists
from sqlalchemy.exc import SQLAlchemyError
from flask import (
    Blueprint,
    request,
    jsonify,
    send_file,
)
import os
import json
import sys
import requests
import re
import pandas as pd
from io import BytesIO
from datetime import datetime
from app.controllers.Token_Calculator.models import (
    get_session,
    Application,Service,ModelPricing
    
    
)
from werkzeug.utils import secure_filename
from sqlalchemy import select, func, text, update, or_, and_, case, true, distinct
from sqlalchemy.orm import Session

app = Blueprint("token-calculator", __name__, url_prefix="/token_calc")
@app.route('/pricing', methods=['GET'])
def get_pricing():
    """
    Get all pricing models
    ---
    responses:
      200:
        description: A list of pricing models
        schema:
          type: object
          properties:
            success:
              type: boolean
            pricing:
              type: array
              items:
                type: object
                properties:
                  id:
                    type: integer
                  model:
                    type: string
                  input_price:
                    type: number
                  output_price:
                    type: number
    """
    try:
        session=get_session()
        models = session.query(ModelPricing).all()
        return jsonify({"success": True, "pricing": [{"id":m.id,"model":m.model_name,"input_price":m.input_price,"output_price":m.output_price} for m in models]})
    
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()


@app.route('/pricing', methods=['POST'])
def create_pricing():
    try:
        session=get_session()
        data = request.get_json()
        if not data or not data.get('model') or data.get('input_price') is None or data.get('output_price') is None:
            return jsonify({"success": False, "error": "Model name, input_price, and output_price are required"}), 400
            
        # Check if model already exists
        existing = session.query(ModelPricing).filter(ModelPricing.model_name==data['model']).first()
        if existing:
            return jsonify({"success": False, "error": "Model already exists"}), 400

        new_model = ModelPricing(
            model_name=data['model'],
            input_price=float(data['input_price']),
            output_price=float(data['output_price'])
        )
        session.add(new_model)
        session.commit()
        
        return jsonify({"success": True, "model": data}), 201
    
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()

@app.route('/pricing/<int:model_id>', methods=['PUT'])
def update_pricing(model_id):
    try:
        session=get_session()
        model = session.query(ModelPricing).filter(ModelPricing.id==model_id).first()
        if not model:
            return jsonify({"success": False, "error": "Model not found"}), 404
            
        data = request.get_json()
        if 'model' in data.keys():
            # Check uniqueness if name changed
            if data['model'] != model.model_name:
                existing = session.query(ModelPricing).filter(ModelPricing.model_name==data['model']).first()
                if existing:
                    return jsonify({"success": False, "error": "Model name already exists"}), 400
            model.model_name = data['model']
            
        if 'input_price' in data:
            model.input_price = float(data['input_price'])
        if 'output_price' in data:
            model.output_price = float(data['output_price'])
            
        session.commit()
        return jsonify({"success": True, "model": data})
    
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()

@app.route('/pricing/<int:model_id>', methods=['DELETE'])
def delete_pricing(model_id):
    try:
        session=get_session()
        model = session.query(ModelPricing).filter(ModelPricing.id==model_id).first()
        if not model:
            return jsonify({"success": False, "error": "Model not found"}), 404
            
        session.delete(model)
        session.commit()
        return jsonify({"success": True})
    
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()


@app.route('/applications', methods=['GET'])
def get_applications():
    """
    Get all applications
    ---
    responses:
      200:
        description: A list of applications
        schema:
          type: object
          properties:
            success:
              type: boolean
            applications:
              type: array
              items:
                type: object
    """
    try:
        session=get_session()
        apps = session.query(Application,Service).outerjoin(Service,Application.id==Service.app_id).all()
        output={}
        for application,service in apps:
            if application.id not in output.keys():
                output[application.id]={"id":application.id,"name":application.name,"description":application.description,"services":[]}
            if service:
                output[application.id]['services'].append({'id':service.id,"app_id":service.app_id,"name":service.name,"input_words":service.input_words,"output_words":service.output_words,"ratio":service.ratio})
        return jsonify({"success": True, "applications": list(output.values())})
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()

@app.route('/applications', methods=['POST'])
def create_application():
    try:
        session=get_session()
        data = request.get_json()
        if not data or not data.get('name'):
            return jsonify({"success": False, "error": "Name is required"}), 400
        
        new_app = Application(
            name=data['name'],
            description=data.get('description', '')
        )
        session.add(new_app)
        session.commit()
    
        return jsonify({"success": True, "application": data}), 201
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()

@app.route('applications/<int:id>', methods=['DELETE'])
def delete_application(id):
    try:
        session=get_session()
        app=session.query(Application).filter(Application.id==id).first()
        session.delete(app)
        
        session.commit()
    
        return jsonify({"success": True}), 201
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()


@app.route('/applications/<int:app_id>/services', methods=['POST'])
def create_service(app_id):
    try:
        session=get_session()
        app_obj = session.query(Application).filter(Application.id==app_id).first()
        if not app_obj:
            return jsonify({"success": False, "error": "Application not found"}), 404
            
        data = request.get_json()
        if not data or not data.get('name') or data.get('input_words') is None or data.get('output_words') is None:
            return jsonify({"success": False, "error": "Name, input_words, and output_words are required"}), 400
            
        input_words = float(data['input_words'])
        output_words = float(data['output_words'])
        
        ratio = output_words / input_words if input_words > 0 else 0
        
        new_service = Service(
            app_id=app_id,
            name=data['name'],
            input_words=int(input_words),
            output_words=int(output_words),
            ratio=ratio
        )
        
        session.add(new_service)
        session.commit()
        
        return jsonify({"success": True, "service": data}), 201
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()
@app.route('/services/<int:service_id>', methods=['PUT'])
def update_service(service_id):
    try:
        session=get_session()
        service = session.query(Service).filter(Service.id==service_id).first()
        if not service:
            return jsonify({"success": False, "error": "Service not found"}), 404
            
        data = request.get_json()
        if 'name' in data:
            service.name = data['name']
        if 'input_words' in data and 'output_words' in data:
            input_words = float(data['input_words'])
            output_words = float(data['output_words'])
            service.input_words = int(input_words)
            service.output_words = int(output_words)
            service.ratio = output_words / input_words if input_words > 0 else 0
            
        session.commit()
        return jsonify({"success": True, "service": data})
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()

@app.route('/services/<int:service_id>', methods=['DELETE'])
def delete_service(service_id):
    try:
        session=get_session()
        service = session.query(Service).filter(Service.id==service_id).first()
        if not service:
            return jsonify({"success": False, "error": "Service not found"}), 404
            
        session.delete(service)
        session.commit()
        return jsonify({"success": True})
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()

        return (
            jsonify(
                {
                    "success": False,
                    "line": tb.tb_lineno,
                    "error": str(e),
                }
            ),
            500,
        )

    finally:
        session.close()


@app.route('/litellm_models', methods=['GET'])
def get_litellm_models():
    """
    Get and categorize models from LiteLLM
    """
    try:
        response = requests.get("https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json")
        if response.status_code != 200:
            return jsonify({"success": False, "error": "Failed to fetch from LiteLLM"}), 500
        
        data = response.json()
        
        categories = {
            "OpenAI": [],
            "Anthropic": [],
            "Google": [],
            "Other major AI labs": [],
            "Cloud Platforms": [],
            "Aggregators/Platforms": [],
            "Uncategorized": []
        }
        
        for key, value in data.items():
            if key == "sample_spec": continue
            if "input_cost_per_token" not in value or "output_cost_per_token" not in value:
                continue
                
            input_cost = value.get("input_cost_per_token")
            output_cost = value.get("output_cost_per_token")
            
            if input_cost is None or output_cost is None:
                continue
                
            display_name = key.split("/", 1)[1] if "/" in key else key
            
            model_info = {
                "id": key,
                "model_name": display_name,
                "input_price": input_cost,
                "output_price": output_cost
            }
            
            k = key.lower()
            if any(x in k for x in ["openai", "azure", "chatgpt"]):
                categories["OpenAI"].append(model_info)
            elif any(x in k for x in ["anthropic", "bedrock", "vertex_ai-anthropic_models"]):
                categories["Anthropic"].append(model_info)
            elif any(x in k for x in ["gemini", "vertex_ai", "palm"]):
                categories["Google"].append(model_info)
            elif any(x in k for x in ["cohere", "mistral", "meta", "deepseek"]):
                categories["Other major AI labs"].append(model_info)
            elif any(x in k for x in ["aws_polly", "sagemaker", "cloudflare", "databricks", "watsonx"]):
                categories["Cloud Platforms"].append(model_info)
            elif any(x in k for x in ["openrouter", "together_ai", "replicate", "anyscale", "groq", "perplexity"]):
                categories["Aggregators/Platforms"].append(model_info)
            else:
                categories["Uncategorized"].append(model_info)
                
        return jsonify({"success": True, "categories": categories})
        
    except Exception as e:
        exc_type, exc_value, tb = sys.exc_info()
        return jsonify({"success": False, "line": tb.tb_lineno, "error": str(e)}), 500


@app.route('/pricing/bulk', methods=['POST'])
def bulk_create_pricing():
    """
    Bulk add/update models to estimator
    """
    try:
        session = get_session()
        data = request.get_json()
        models = data.get('models', [])
        
        if not models:
            return jsonify({"success": False, "error": "No models provided"}), 400
            
        added = 0
        updated = 0
        
        for m in models:
            model_name = m.get('model_name')
            input_price = m.get('input_price')
            output_price = m.get('output_price')
            
            if not model_name or input_price is None or output_price is None:
                continue
                
            existing = session.query(ModelPricing).filter(ModelPricing.model_name == model_name).first()
            if existing:
                existing.input_price = float(input_price)
                existing.output_price = float(output_price)
                updated += 1
            else:
                new_model = ModelPricing(
                    model_name=model_name,
                    input_price=float(input_price),
                    output_price=float(output_price)
                )
                session.add(new_model)
                added += 1
                
        session.commit()
        return jsonify({"success": True, "added": added, "updated": updated})
        
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()
        return jsonify({"success": False, "line": tb.tb_lineno, "error": str(e)}), 500
    finally:
        session.close()


@app.route('/pricing/sync', methods=['POST'])
def sync_pricing():
    """
    Sync existing prices with LiteLLM source
    """
    try:
        session = get_session()
        response = requests.get("https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json")
        if response.status_code != 200:
            return jsonify({"success": False, "error": "Failed to fetch from LiteLLM"}), 500
            
        data = response.json()
        
        litellm_prices = {}
        for key, value in data.items():
            if key == "sample_spec": continue
            if "input_cost_per_token" in value and "output_cost_per_token" in value:
                display_name = key.split("/", 1)[1] if "/" in key else key
                litellm_prices[display_name] = {
                    "input_price": value["input_cost_per_token"],
                    "output_price": value["output_cost_per_token"]
                }
                
        existing_models = session.query(ModelPricing).all()
        updated = 0
        
        for model in existing_models:
            if model.model_name in litellm_prices:
                new_prices = litellm_prices[model.model_name]
                if new_prices["input_price"] is not None and new_prices["output_price"] is not None:
                    model.input_price = float(new_prices["input_price"])
                    model.output_price = float(new_prices["output_price"])
                    updated += 1
                    
        session.commit()
        return jsonify({"success": True, "updated": updated})
        
    except Exception as e:
        session.rollback()
        exc_type, exc_value, tb = sys.exc_info()
        return jsonify({"success": False, "line": tb.tb_lineno, "error": str(e)}), 500
    finally:
        session.close()
