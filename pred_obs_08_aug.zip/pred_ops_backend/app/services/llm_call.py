import openai
import httpx 
from app.core.config import settings

direct_client = httpx.Client(trust_env=False)
print("api_key")
print(settings.OPENAI_API_KEY)
client = openai.OpenAI(
    api_key=settings.OPENAI_API_KEY,
    base_url="http://10.73.74.36:20119/v1",
    http_client=direct_client
)
def openai_invoke(prompt, system_prompt=None):
    try:
        sys_msg = system_prompt if system_prompt else "You output strict JSON only."
        response = client.chat.completions.create(
                model=settings.OPENAI_MODEL,
                temperature=0.2,
                # max_tokens=300, # Increased max_tokens slightly to accommodate the longer cascade description
                messages=[
                    {"role": "system", "content": sys_msg},
                    {"role": "user", "content": prompt}
                ]
            )

        content = response.choices[0].message.content.strip()
        if content.startswith("```"):
            content = content.split("\n", 1)[1].rsplit("```", 1)[0]
        print(content)
        return content
    except Exception as e:
        print(e)
        raise

# import google.generativeai as genai
# genai.configure(api_key=settings.GEMINI_API_KEY)

# def gemini_invoke(prompt, system_prompt=None):
#     try:
#         model = genai.GenerativeModel(
#             model_name=settings.GEMINI_LLM_MODEL,
#             system_instruction=system_prompt,
#         )
#         response = model.generate_content(
#             prompt,
#             generation_config=genai.GenerationConfig(
#                 response_mime_type="application/json",
#                 temperature=0.2,
#             )
#         )

#         print(response.text)
#         return response.text
#     except Exception as e:
#         print(e)
#         raise

def invoke(prompt, system_prompt=None):
    # return gemini_invoke(prompt, system_prompt)
    return openai_invoke(prompt, system_prompt)