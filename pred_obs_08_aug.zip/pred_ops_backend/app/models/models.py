from sqlalchemy import Column, String, Integer, BigInteger, Float, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class Journey(Base):
    __tablename__ = 'journeys'
    
    id = Column(String(50), primary_key=True, index=True)
    name = Column(String(255))
    
    # Health Metrics
    status = Column(String(50))
    users = Column(Integer)
    happy = Column(Integer)
    unhappy = Column(Integer)
    frustrated = Column(Integer)
    avail = Column(Float)
    alerts = Column(Integer)
    
    subjourneys = relationship("Subjourney", back_populates="journey")


class SubJourneyServiceMap(Base):
    """
    Junction table mapping subjourneys to Application Services.
    Stores performance metrics (resp, p95, errRate, avail) per service.
    """
    __tablename__ = 'sub_journey_services'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    subjourney_id = Column(String(50), ForeignKey('subjourneys.id', ondelete='CASCADE'), index=True, nullable=False)
    service_name = Column(String(255), index=True, nullable=False)
    short_name = Column(String(50), nullable=False)
    is_primary = Column(Boolean, default=True)
    
    # Performance Metrics per Service
    resp = Column(Integer, default=0)
    p95 = Column(Integer, default=0)
    errRate = Column("errRate", Float, default=0.0)
    avail = Column(Float, default=100.0)
    
    subjourney = relationship("Subjourney", back_populates="service_mappings")
    incidents = relationship("Incident", back_populates="service_map")


class Subjourney(Base):
    __tablename__ = 'subjourneys'
    
    id = Column(String(50), primary_key=True, index=True)
    journey_id = Column(String(50), ForeignKey('journeys.id'))
    name = Column(String(255))
    mapping_name = Column(String(255))
    short_name = Column(String(50))
    
    # Health Metrics (UX split & status remain on subjourney level)
    status = Column(String(50))
    happy = Column(Integer)
    unhappy = Column(Integer)
    frustrated = Column(Integer)
    alerts = Column(Integer)
    
    journey = relationship("Journey", back_populates="subjourneys")
    service_mappings = relationship("SubJourneyServiceMap", back_populates="subjourney", cascade="all, delete-orphan")
    pattern_families = relationship("PatternFamily", back_populates="subjourney")


class PatternFamily(Base):
    __tablename__ = 'pattern_families'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    subjourney_id = Column(String(50), ForeignKey('subjourneys.id'))
    pattern_name = Column(Text)
    example_description = Column(Text)
    incident_count = Column(Integer)
    root_cause_template = Column(Text)
    
    subjourney = relationship("Subjourney", back_populates="pattern_families")


class Incident(Base):
    __tablename__ = 'incidents'
    
    # We use 'number' as the primary key since it contains unique identifiers like 'INC2103046'
    number = Column(Text, primary_key=True)
    opened = Column(DateTime)
    caller = Column(Text)
    short_description = Column(Text)
    priority = Column(Text)
    state = Column(Text)
    assignment_group = Column(Text)
    updated = Column(DateTime)
    additional_comments = Column(Text)
    child_incidents = Column(BigInteger)
    business_duration = Column(Float)
    business_impact = Column(Text)
    business_resolve_time = Column(Float)
    caused_by_change = Column(Text)
    change_request = Column(Text)
    channel = Column(Text)
    closed = Column(DateTime)
    comments_and_work_notes = Column(Text)
    date = Column(Float)
    configuration_item = Column(Text)
    correlation_id = Column(Text)
    correlation_display = Column(Text)
    created = Column(DateTime)
    description = Column(Text)
    due_date = Column(Float)
    duration = Column(Float)
    first_assignment_group = Column(Text)
    impact = Column(Text)
    incident_state = Column(Text)
    major_incident_state = Column(Text)
    overview = Column(Text)
    parent_incident = Column(Text)
    probable_cause = Column(Text)
    problem = Column(Text)
    reassignment_count = Column(BigInteger)
    reopen_count = Column(BigInteger)
    resolution_code = Column(Text)
    resolution_notes = Column(Text)
    resolve_time = Column(Float)
    resolved = Column(DateTime)
    service = Column(Text)
    severity = Column(Text)
    technician_notes = Column(Float)
    urgency = Column(Text)
    work_notes = Column(Text)
    csat_overall_overall_how_satisfied_are_you_with_the_support_exp = Column(Float)
    ces_ease_how_easy_was_it_to_get_your_issue_resolved = Column(Float)
    communication_how_satisfied_are_you_with_the_clarity_and_timeli = Column(Float)
    resolution_quality_how_satisfied_are_you_that_the_issue_was_res = Column(Float)
    fcr_confirm_was_your_issue_resolved_without_needing_to_contact_ = Column(Float)
    comment_please_share_any_additional_feedback = Column(Float)
    hop_level = Column(Float)
    
    # --- UPDATED: Replaced subjourney_id with service_id pointing to sub_journey_services ---
    service_id = Column(Integer, ForeignKey('sub_journey_services.id', ondelete='SET NULL'), index=True, nullable=True)
    
    service_map = relationship("SubJourneyServiceMap", back_populates="incidents")
    correlated_incident = Column(Text, nullable=True)  # Stores created ServiceNow ticket number
    correlated_parent = Column(Text, nullable=True)    # Stores the parent event/alert ID for child alerts

class ServiceCorrelationMap(Base):
    __tablename__ = 'service_correlation_maps'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    map_id = Column(String(50), index=True, nullable=False)
    map_name = Column(String(255), nullable=False)
    service_name = Column(String(255), index=True, nullable=False)
    subjourney_id = Column(String(50), nullable=True)
    is_active = Column(Boolean, default=True)

from sqlalchemy import Column, String, Integer, ForeignKey
from sqlalchemy.orm import relationship
from app.models.models import Base

class Component(Base):
    __tablename__ = 'components'
    
    component_id = Column(String(50), primary_key=True)
    component_name = Column(String(255), nullable=False)


class ComponentServiceMap(Base):
    """
    Junction table mapping Configuration Items (components) to Application Services.
    """
    __tablename__ = 'component_service_map'
    
    map_id = Column(Integer, primary_key=True, autoincrement=True)
    component_id = Column(String(50), ForeignKey('components.component_id', ondelete='CASCADE'), nullable=False)
    service_id = Column(Integer, ForeignKey('sub_journey_services.id', ondelete='CASCADE'), nullable=False)
    
    component = relationship("Component", backref="service_mappings")
    service = relationship("SubJourneyServiceMap", backref="component_mappings")