# Seed script: Novelis "MuleSoft Cascade" Horizontal Correlation demo data
#
# Drop this into app/scripts/ alongside seed_horizontal_maps.py and run it the
# same way (e.g. `python -m app.scripts.seed_novelis_mulesoft_cascade`).
#
# It populates the exact tables build_horizontal_map_clusters() reads from:
#   - components               (the shared root-cause CI: MuleSoft)
#   - sub_journey_services     (the 3 downstream applications it feeds)
#   - component_service_map    (the CI -> application mapping the engine
#                                dynamically resolves at runtime)
#   - incidents                (the 13 real alerts, timestamps preserved
#                                from INC_Feb-_July_2026.xlsx)
#
# All incident numbers / timestamps / descriptions below are taken directly
# from the Novelis INC export (1 Apr 2026, 09:37-11:56). Journey / sub-journey
# / application labels are the cooked-up layer described in the story doc,
# since that layer doesn't exist in the raw exports.

from datetime import datetime
from app.database import SessionLocal
from app.models.models import Incident
from app.models.models import Component, ComponentServiceMap, SubJourneyServiceMap

db = SessionLocal()

# ---------------------------------------------------------------------------
# 1. Root-cause component (shared Configuration Item)
# ---------------------------------------------------------------------------
mulesoft = Component(component_id="CI-MULESOFT", component_name="MuleSoft")
db.merge(mulesoft)

# ---------------------------------------------------------------------------
# 2. Downstream applications the CI is mapped to (cooked-up journey layer)
# ---------------------------------------------------------------------------
services = [
    # id,  subjourney_id,       service_name,                                  short_name
    (501, "SJ-FIN-POST",       "Finance Integration Service (SAP FI/CO)",      "FIN"),
    (502, "SJ-COM-ORDER",      "Commercial Order Integration Service",         "COM"),
    (503, "SJ-TMS-FINSETL",    "TMS-Finance Settlement Interface",             "TMS"),
]
for sid, subj_id, name, short in services:
    row = SubJourneyServiceMap(
        id=sid,
        subjourney_id=subj_id,
        service_name=name,
        short_name=short,
        is_primary=True,
    )
    db.merge(row)

# ---------------------------------------------------------------------------
# 3. CI -> Application mapping (this is what build_horizontal_map_clusters
#    joins against to dynamically discover "all apps fed by MuleSoft")
# ---------------------------------------------------------------------------
for sid, _, _, _ in services:
    db.merge(ComponentServiceMap(component_id="CI-MULESOFT", service_id=sid))

# ---------------------------------------------------------------------------
# 4. The 13 raw alerts (real Novelis incident data)
# ---------------------------------------------------------------------------
incidents_raw = [
    ("INC2120997", "2026-04-01 09:37:00", "FIN--ELK-prod-interfaceId-- PLANT--nov-nna-fin-schedulers-Failed-", "FIN", 501),
    ("INC2120998", "2026-04-01 09:38:00", "FIN--ELK-prod-interfaceId-- PLANT--nov-nna-fin-schedulers-Failed-", "FIN", 501),
    ("INC2121012", "2026-04-01 09:43:00", "FIN--ELK-prod-interfaceId-- PLANT--nov-nna-fin-schedulers-Failed-", "FIN", 501),
    ("INC2121049", "2026-04-01 10:04:00", "FIN--ELK-prod-interfaceId-- PLANT--nov-nna-fin-papi-Failed-", "FIN", 501),
    ("INC2121050", "2026-04-01 10:05:00", "FIN--ELK-prod-interfaceId-- PLANT--nov-nna-fin-papi-Failed-", "FIN", 501),
    ("INC2121054", "2026-04-01 10:09:00", "COM--ELK-prod-interfaceId-- PLANT--nov-global-com-papi-Failed-8b60583aaf0d4d488ae7aa6b405d75f7 -Error Code: GENERIC Error Type : MULE:SOURCE_RESPONSE_SEND", "COM", 502),
    ("INC2121055", "2026-04-01 10:10:00", "FIN--ELK-prod-interfaceId-- PLANT--nov-nna-fin-papi-Failed-", "FIN", 501),
    ("INC2121153", "2026-04-01 11:32:00", "FIN--ELK-prod-interfaceId-- PLANT--nov-nna-fin-rate-papi-Failed-", "FIN", 501),
    ("INC2121154", "2026-04-01 11:32:00", "FIN--ELK-prod-interfaceId-- PLANT--nov-nna-fin-rate-papi-Failed-", "FIN", 501),
    ("INC2121165", "2026-04-01 11:37:00", "FIN--ELK-prod-interfaceId-- PLANT--nov-nna-fin-rate-papi-Failed-", "FIN", 501),
    ("INC2121182", "2026-04-01 11:51:00", "TMS--ELK-prod-interfaceId-- PLANT--nov-nna-tms-fin-papi-Failed95eb8dd0-2de1-11f1-8137-d2b3dc4db161 -Error Code: TECH-0002 Error Type : INTERNAL_ERROR", "TMS", 503),
    ("INC2121184", "2026-04-01 11:56:00", "TMS--ELK-prod-interfaceId-- PLANT--nov-nna-tms-fin-papi-Failed42928240-2de3-11f1-8137-d2b3dc4db161 -Error Code: TECH-0002 Error Type : INTERNAL_ERROR", "TMS", 503),
    ("INC2121185", "2026-04-01 11:56:00", "TMS--ELK-prod-interfaceId-- PLANT--nov-nna-tms-fin-papi-Failed42928240-2de3-11f1-8137-d2b3dc4db161 -Error Code: TECH-0002 Error Type : INTERNAL_ERROR", "TMS", 503),
]

for number, opened, desc, short_name, service_id in incidents_raw:
    svc_name = next(s[2] for s in services if s[0] == service_id)
    inc = Incident(
        number=number,
        opened=datetime.strptime(opened, "%Y-%m-%d %H:%M:%S"),
        caller="ITSI Event Management",
        short_description=desc,
        priority="3 - Normal",
        state="Closed",
        assignment_group="IT APP Global MW Tech L2",
    )
    # NOTE: if your `incidents` table (per fetch_horizontal_monitoring_incidents)
    # also has configuration_item / service / service_id / severity / urgency /
    # impact / channel columns, set them here too, e.g.:
    #   inc.configuration_item = "MuleSoft"
    #   inc.service = svc_name
    #   inc.service_id = service_id
    #   inc.severity = "Medium"
    #   inc.channel = "Monitoring"
    db.merge(inc)

db.commit()
print(f"Seeded MuleSoft cascade: 1 component, {len(services)} services, {len(incidents_raw)} incidents.")
