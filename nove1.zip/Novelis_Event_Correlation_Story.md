# Novelis Event Correlation Showcase — Story & Scenario

## 1. What the codebase actually does (my read of it)

The `pred_ops_backend` + `pred_obs_ui` app is an **AIOps event-correlation platform** (built originally for Canada Life, generic enough to re-skin for Novelis). Its job: take a flood of raw monitoring alerts ("incidents" in your Excel = the alert stream), and automatically group them into **one consolidated Incident** with a single root cause, instead of making an SRE stare at 13 separate tickets.

It supports **two distinct correlation strategies**, and your instruction was to demo only one:

| | **Vertical Correlation** | **Horizontal Correlation** |
|---|---|---|
| Matches alerts by | Same **service / application**, same generalized **pattern** (job/transaction abend, with IDs masked) over a rolling time window | Same **Configuration Item** (a shared component, e.g. middleware) whose failure **cascades across multiple different applications/services** |
| Where in code | `build_clusters`, `build_cics_vertical_cluster`, `VerticalCorrelation.jsx` | `build_horizontal_map_clusters`, `fetch_horizontal_monitoring_incidents`, `HorizontalCorrelationView.jsx` |
| Story it tells | "This one app keeps throwing the same error, here are 5 recurrences of it" | "This shared piece of infra broke, and here's how it silently took down 3 unrelated business capabilities" |
| Visual | Parent → children timeline with confidence bars/boosters | Animated cascade graph (root node → downstream app nodes) + play/pause + AI RCA card |

The UI already has a **hardcoded "JVM OOM Alert Cluster"** demo (per your instruction: **leave it exactly as is** — don't touch `CorrelationExecutionView.jsx`, `JvmAutoFixModalBody.jsx`, `isJvmResolved` logic, etc.). We are adding a *second, real, Novelis-data-driven* story to sit alongside it.

## 2. Why I picked **Horizontal**, based on your actual data

I mined `INC_Feb-_July_2026.xlsx` (10,685 incidents) for exactly the pattern the horizontal engine looks for: **one shared `Affected CI` whose failures fan out across multiple business towers in a tight time window.**

`MuleSoft` (Novelis's integration middleware/ESB) is by far the best candidate — 845 incidents, and its short descriptions encode a downstream-system prefix (`FIN--`, `COM--`, `TMS--`, `MAN--`, `PRC--`) baked right into the interface ID. That prefix *is* the "mapped application" the horizontal engine dynamically resolves via `component_service_map`. This is a gift — it's almost exactly the data shape `build_horizontal_map_clusters` expects, just needing the cooked-up service/journey names layered on top (which you already told me is expected/missing from the raw exports).

Scanning all MuleSoft incidents in rolling 2-hour buckets for the bucket with the most **distinct downstream prefixes**, the clear winner is:

> **1 April 2026, 09:37 – 11:56** → prefixes `FIN`, `COM`, `TMS` all fire from the same root cause, 13 raw alerts, all owned by the same team (`IT APP Global MW Tech L2`).

I also found a **Problem ticket that independently corroborates this exact incident** — `PRB0050928`, *"IDocs error 31.03.2026"*, CI = `MuleSoft`, same assignment group, opened 2026-04-01 13:35 (99 minutes after the cascade started) and not closed until **2026-04-23** (22 days later). That's the "manual RCA" timeline the correlation engine is designed to collapse to seconds — a perfect before/after narrative beat for the demo.

(I checked a Vertical alternative too — Coupa repeatedly throwing `<COUPA><TAX CALCULATION><id>: ERROR` against different document IDs is a legitimate same-app recurring-pattern cluster if you ever want a Vertical demo instead. I did **not** build this one out; happy to if you change your mind. `Story_Feb-July_2026.xlsx` is engineering backlog data, not alert data, so I didn't use it for either scenario.)

---

## 3. The Story: *"The MuleSoft Cascade"*

### The setup (cooked-up journey/app layer, built on top of your real incident data)

Since Journey / Sub-journey / Application / Component don't exist in the exports, here's the layer I'm proposing on top of the real `MuleSoft` CI and the real `FIN` / `COM` / `TMS` interface prefixes — deliberately realistic to Novelis's SAP-centric, plant-integration world:

| Layer | Value |
|---|---|
| **Root-cause Component** | `MuleSoft` — Integration Middleware / ESB (Tier: **Integration**) |
| **Downstream App 1** | Finance Integration Service *(SAP FI/CO ⇄ MuleSoft)* — short name **FIN** |
| ↳ Journey / Sub-journey | Journey: `Finance Operations` → Sub-journey: `Month-End Financial Posting & AP/AR Interface` |
| **Downstream App 2** | Commercial Order Integration Service *(Commercial systems ⇄ MuleSoft)* — short name **COM** |
| ↳ Journey / Sub-journey | Journey: `Commercial Solutions & Integrations` → Sub-journey: `Commercial Order Sync` |
| **Downstream App 3** | TMS–Finance Settlement Interface *(Transportation Mgmt ⇄ Finance via MuleSoft)* — short name **TMS** |
| ↳ Journey / Sub-journey | Journey: `Supply Chain Solutions & Shared Systems` → Sub-journey: `Freight Financial Settlement` |

A nice, true-to-life wrinkle to call out live in the demo: **ServiceNow itself tagged all 13 tickets under one generic `Business Tower` ("Commercial Solutions & Integrations")** — even though the real blast radius spans Finance, Commercial, and Logistics. That's a legitimate "gap in current tooling" talking point: *ITSM ticket tagging hides the cross-functional blast radius; the correlation engine reveals it.*

### The timeline (real data, real timestamps)

| # | Incident | Time | Delta | App | What fired |
|---|---|---|---|---|---|
| **ROOT** | **INC2120997** | 09:37 | 0 min | FIN | `nov-nna-fin-schedulers` — scheduler job failed |
| 2 | INC2120998 | 09:38 | +1 min | FIN | same scheduler, retry failed |
| 3 | INC2121012 | 09:43 | +6 min | FIN | same scheduler, 3rd failure |
| 4 | INC2121049 | 10:04 | +27 min | FIN | `nov-nna-fin-papi` — Finance PAPI interface failed |
| 5 | INC2121050 | 10:05 | +28 min | FIN | Finance PAPI failed again |
| 6 | **INC2121054** | 10:09 | +32 min | **COM** | `nov-global-com-papi` — `MULE:SOURCE_RESPONSE_SEND` — **cascade jumps to Commercial** |
| 7 | INC2121055 | 10:10 | +33 min | FIN | Finance PAPI failed again |
| 8 | INC2121153 | 11:32 | +115 min | FIN | `nov-nna-fin-rate-papi` — FX/rate interface failed |
| 9 | INC2121154 | 11:32 | +115 min | FIN | rate interface failed again |
| 10 | INC2121165 | 11:37 | +120 min | FIN | rate interface failed a 3rd time |
| 11 | **INC2121182** | 11:51 | +134 min | **TMS** | `nov-nna-tms-fin-papi` — `INTERNAL_ERROR` — **cascade jumps to Transportation/Finance settlement** |
| 12 | INC2121184 | 11:56 | +139 min | TMS | TMS-FIN interface failed again |
| 13 | INC2121185 | 11:56 | +139 min | TMS | TMS-FIN interface failed again |

**Cascade chain (3 nodes — a clean triangle in the UI's graph layout):** `FIN → COM → TMS`

> ⚠️ Implementation note: your `.env` default is `HORIZONTAL_WINDOW_MINUTES=115`. This real cascade runs 139 minutes end-to-end. For the demo, bump it to **150** (or point `opened_datetime` at `2026-04-01 11:56:00` and it'll pull the full 139-minute lookback cleanly) so the TMS wave isn't clipped.

### The payoff (what makes this a good demo, not just a data dump)

- **Without correlation:** 13 tickets landed with 4 different assignees (Tanmaya Joshi, Akash Jivrag, Mathumohan R, Koppula Kiran) working them independently, no one connecting FIN → COM → TMS. Resolution times ranged from **~1.5 hours to 5 days** (INC2121185 wasn't closed until 2026-04-06) for what was one underlying failure. A parallel Problem investigation (`PRB0050928`) into the same MuleSoft fault stayed open for **22 days**.
- **With correlation:** the engine sees the shared CI (`MuleSoft`) at the *earliest* timestamp, dynamically resolves every application mapped to it, groups all 13 alerts into one incident within seconds, and tells the SRE exactly what's about to break next if it isn't fixed — *before* the TMS wave even hits (the FIN→COM jump at +32 min is an early warning for the TMS jump at +134 min).

---

## 4. Ready-to-drop-in payload (matches your existing schema exactly)

This mirrors the exact JSON shape `build_horizontal_map_clusters()` / `get_top_horizontal_map_cluster()` returns today, and exactly what `HorizontalCorrelationView.jsx` renders (root-cause stat card, cascade graph, alert list, AI SRE analysis card). See `novelis_horizontal_cluster.json` for the full payload, and `seed_novelis_mulesoft_cascade.py` for the Component / ComponentServiceMap / SubJourneyServiceMap / Incident seed rows to insert via your existing seed scripts.

### `llm_analysis` copy (ready to use verbatim, in the same voice as your existing fallback text in `correlation_service.py`)

**likely_root_cause:**
> `INC2120997` (Finance scheduler job failure on interface `nov-nna-fin-schedulers`). The earliest degradation originated on configuration item **MuleSoft** within the Finance integration layer at 2026-04-01 09:37. From component **MuleSoft**, we dynamically fetched all mapped applications (**Finance Integration Service, Commercial Order Integration Service, TMS-Finance Settlement Interface**) and traced the chronological propagation of the outage: Finance scheduler retries (09:37–09:43) escalated into the Finance PAPI interface (10:04), which cross-contaminated the Commercial Order interface within 5 minutes (10:09), before re-surfacing as a Finance FX/rate interface failure (11:32) and finally cascading into the TMS-Finance settlement interface (11:51–11:56).

**business_impact:**
> Cascading degradation across 13 alerts propagated from the Finance Integration Service into the Commercial Order Integration Service and TMS-Finance Settlement Interface, delaying month-end financial postings, commercial order confirmations, and freight settlement runs. A parallel manual Problem investigation into the same MuleSoft fault (PRB0050928, "IDocs error 31.03.2026") remained open for 22 days, indicating the underlying middleware issue was not fully understood at the time. There is an increased risk that continued MuleSoft interface instability results in additional IDoc/transaction failures, queue backlogs on the Finance-TMS settlement path, and delayed coil/inventory postings into SAP if the condition recurs.

**correlation_rule_applied:**
> **Dynamic Component-Application Mapping Rule**: automatically grouped 13 co-occurring alerts within a 139-minute arrival window across 3 applications (Finance, Commercial, TMS-Finance) sharing configuration item **MuleSoft**, using the same dynamic CI→Service mapping logic already implemented in `build_horizontal_map_clusters`.

---

## 5. What I did *not* touch

- The hardcoded **JVM OOM Alert Cluster** (`CorrelationExecutionView.jsx`, `JvmAutoFixModalBody.jsx`, `isJvmResolved` state in `App.jsx`, `StepsView.jsx`, `JourneysView.jsx`) — left exactly as-is, per your instruction.
- `Story_Feb-July_2026.xlsx` — this is Agile/backlog data (STR tickets, story points, kanban), not alert data, so it isn't part of the correlation story.
- The **Vertical** correlation path — not built out, since you asked to showcase only one. If you want it later, the Coupa `TAX CALCULATION` recurring-error pattern in the same INC file is a ready-made Vertical candidate (same app, same generalized pattern, repeating over time).
