from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from dotenv import load_dotenv
from app.database import get_db
from app.services import correlation_service
load_dotenv()
router = APIRouter(prefix="/api/correlation", tags=["correlation"])

@router.get("/clusters")
def get_clusters(
    service_id: int = Query(..., description="The target service ID (e.g. 12 for Benefits - AS)"),
    opened_datetime: str = Query(..., description="The reference datetime in ISO format (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    clusters = correlation_service.build_clusters(service_id, ref_time, db)
    return {
        "service_id": service_id,
        "reference_datetime": opened_datetime,
        "total_clusters_found": len(clusters),
        "clusters": clusters
    }


@router.get("/top_cluster")
def get_top_cluster(
    service_id: int = Query(..., description="The target service ID (e.g. 12 for Benefits - AS)"),
    opened_datetime: str = Query(..., description="The reference datetime in ISO format (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    enriched_cluster = correlation_service.build_dynamic_enriched_top_cluster(service_id, ref_time, db)
    if not enriched_cluster:
        return {"error": f"No clusters found for service_id={service_id} and time window."}
        
    return enriched_cluster
@router.get("/splunk_children")
def get_splunk_children(
    parent_id: str = Query(..., description="The parent incident ID to search for"),
    db: Session = Depends(get_db)
):
    """
    Returns a list of incident IDs natively grouped by Splunk under a given parent_id.
    """
    return correlation_service.get_splunk_children(parent_id, db)

from app.core.config import settings

@router.get("/horizontal_clusters")
def get_all_horizontal_map_clusters(
    opened_datetime: str = Query(..., description="Reference ISO datetime (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    clusters = correlation_service.build_horizontal_map_clusters(ref_time, db)
    return {
        "reference_datetime": opened_datetime,
        "window_minutes": settings.HORIZONTAL_WINDOW_MINUTES,
        "total_clusters_found": len(clusters),
        "clusters": clusters
    }


@router.get("/horizontal_top_cluster")
def get_top_horizontal_map_cluster(
    opened_datetime: str = Query(..., description="Reference ISO datetime (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    top_cluster = correlation_service.get_top_horizontal_map_cluster(ref_time, db)
    if not top_cluster:
        return {"error": "No horizontal map clusters found for the given time window."}
        
    return {
        "reference_datetime": opened_datetime,
        "window_minutes": settings.HORIZONTAL_WINDOW_MINUTES,
        "top_cluster": top_cluster
    }
import os
import re
import requests
from requests.auth import HTTPBasicAuth
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.models import Incident

@router.post("/create_servicenow_ticket")
def create_servicenow_ticket(
    incident_id: str = Query(..., description="Root cause alert number (e.g., INC2150158)"),
    db: Session = Depends(get_db)
):
    try:
        # 1. Fetch the alert/incident directly from the database table
        inc = db.query(Incident).filter(Incident.number == incident_id).first()
        if not inc:
            return {
                "success": False, 
                "error": f"Root Cause Alert '{incident_id}' not found in database."
            }

        # 2. Extract description, short_description, impact, urgency, and severity from DB record
        short_desc = (inc.short_description or "").strip()
        desc = (inc.description or "").strip()
        
        # Extract leading digit for ServiceNow Table API (e.g., '1 - Critical' -> '1', fallback '3')
        impact_match = re.match(r"^(\d+)", str(inc.impact or "3").strip())
        impact_val = impact_match.group(1) if impact_match else "3"
        
        urgency_match = re.match(r"^(\d+)", str(inc.urgency or "3").strip())
        urgency_val = urgency_match.group(1) if urgency_match else "3"

        # 3. Fixed assignment values as requested
        cmdb_ci_val = "Benefit - AS"
        assignment_group_val = "ARE_TEAM"

        # 4. Build ServiceNow POST payload
        payload = {
            "cmdb_ci": cmdb_ci_val,
            "assignment_group": assignment_group_val,
            "short_description": short_desc,
            "description": desc,
            "impact": impact_val,
            "urgency": urgency_val
        }

        # 5. Call ServiceNow REST Table API (No Fallback)
        sn_instance = os.getenv("SERVICENOW_BASE_URL", "").rstrip("/")
        sn_user = os.getenv("SERVICENOW_USERNAME", "admin")
        sn_password = os.getenv("SERVICENOW_PASSWORD", "")
        
        if not sn_instance or not sn_password:
            return {
                "success": False, 
                "error": "ServiceNow API credentials (SERVICENOW_BASE_URL / SERVICENOW_PASSWORD) are not configured."
            }

        url = f"{sn_instance}/api/now/table/incident"
        res = requests.post(
            url,
            auth=HTTPBasicAuth(sn_user, sn_password),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            json=payload,
            timeout=10
        )

        # Check if ServiceNow API call succeeded
        if res.status_code not in [200, 201]:
            error_details = res.text
            try:
                err_json = res.json()
                error_details = err_json.get("error", {}).get("message") or err_json.get("error_description", res.text)
            except Exception:
                pass
            return {
                "success": False, 
                "error": f"ServiceNow API Error ({res.status_code}): {error_details}"
            }

        sn_ticket_number = res.json().get("result", {}).get("number")
        if not sn_ticket_number:
            return {
                "success": False, 
                "error": "ServiceNow API responded successfully but did not return a ticket number."
            }

        # 6. Save the created ticket number in the `correlated_incident` column in the database
        try:
            inc.correlated_incident = sn_ticket_number
            db.commit()
            db.refresh(inc)
        except Exception as db_err:
            db.rollback()
            return {
                "success": False, 
                "error": f"Ticket {sn_ticket_number} created in ServiceNow, but failed to save to database: {str(db_err)}"
            }

        # 7. Return success response to UI
        return {
            "success": True,
            "source_incident_id": incident_id,
            "servicenow_ticket_number": sn_ticket_number,
            "cmdb_ci": cmdb_ci_val,
            "assignment_group": assignment_group_val,
            "message": f"ServiceNow ticket {sn_ticket_number} created successfully."
        }

    except Exception as e:
        print(f"[SN-CREATE] Unexpected server error: {str(e)}")
        return {
            "success": False, 
            "error": f"Unexpected server error while creating ticket: {str(e)}"
        }
