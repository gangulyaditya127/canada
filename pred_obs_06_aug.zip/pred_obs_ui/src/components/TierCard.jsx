import Timeline from './Timeline';
import { toSec } from '../utils/time';

export default function TierCard({ tier, onViewAll }) {
  const totalSrc = tier.sources.reduce((s, x) => s + x.n, 0) || 1;
  const isDeg = tier.level === 'deg';
  
  const sevPills = [];
  if (tier.sev.crit) sevPills.push(<span key="c" className="sev-pill crit">{tier.sev.crit} Critical</span>);
  if (tier.sev.high) sevPills.push(<span key="h" className="sev-pill high">{tier.sev.high} High</span>);
  
  const sortedAlerts = [...tier.alerts].sort((a, b) => toSec(a.time) - toSec(b.time));

  return (
    <div className={'stat-card' + (tier.isRoot ? ' rc' : '')}>
      <div className={'stat-head' + (isDeg ? ' deg' : '')}>
        <div className="ico">{tier.icon}</div>
        <div className="name">{tier.name}</div>
        <span className="rc-flag">★ Root Cause</span>
      </div>
      
      <div className={'summary-block' + (isDeg ? ' deg' : '')}>
        <div className="lb">Summary</div>
        <div className="msg">{tier.summary}</div>
      </div>

      {/* Clickable Big Count Block that triggers opening all alerts */}
      <div 
        className={'big-count' + (isDeg ? ' deg' : '')} 
        onClick={() => onViewAll(tier)}
        style={{ cursor: 'pointer' }}
        title="Click to view all alert details"
      >
        <div className="num">{tier.alertCount}</div>
        <div className="lbl">Alerts on this tier (View All)</div>
      </div>

      <div className="sev-strip">{sevPills}</div>
      
      <div className="src-mix">
        <div className="lb">Where alerts came from</div>
        <div className="src-bar">
          {tier.sources.map((s, i) => (
            <span key={i} style={{ width: (s.n / totalSrc) * 100 + '%', background: s.c }} />
          ))}
        </div>
        <div className="src-legend">
          {tier.sources.map((s, i) => (
            <span key={i} className="li"><span className="dot" style={{ background: s.c }} />{s.k}·{s.n}</span>
          ))}
        </div>
      </div>

      <div className="causes-block">
        <div className="lb">Top 3 causes (30-day)</div>
        {tier.topCauses.slice(0, 3).map((c, i) => (
          <div key={i} className="cause-row">
            <span className="cause-rank">{i + 1}</span>
            <div className="cause-body">
              <div className="cause-name">{c.name}</div>
              <div className="cause-bar-wrap"><div className="cause-bar" style={{ width: c.pct + '%' }} /></div>
            </div>
            <span className="cause-pct">{c.pct}%</span>
          </div>
        ))}
      </div>

      <div className="timeline-block">
        <div className="lb"><span>Today's alert timeline</span><span className="rt">{sortedAlerts.length} alerts</span></div>
        <Timeline alerts={sortedAlerts} />
      </div>
      
      {/* Footer containing the old "View all alerts" button has been completely removed */}
    </div>
  );
}