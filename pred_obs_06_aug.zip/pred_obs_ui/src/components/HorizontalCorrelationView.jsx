import { useState, useEffect, useRef } from 'react';
import VerticalCorrelation from './VerticalCorrelation';

export default function HorizontalCorrelationView({ cluster, drilldownData }) {
  // --- PLAY / PAUSE / RESET ANIMATION STATE ---
  const [isPlaying, setIsPlaying] = useState(false);
  const [visibleCount, setVisibleCount] = useState(0); // Number of incidents currently shown
  const [speed, setSpeed] = useState(1);              // 1x, 2x, 3x speed
  const timerRef = useRef(null);
  const [selectedNode, setSelectedNode] = useState(null);

  // Initialize visibility when cluster is provided
  useEffect(() => {
    if (cluster && cluster.incidents) {
      setVisibleCount(cluster.incidents.length);
    }
  }, [cluster]);

  // Handle Play / Pause timer
  useEffect(() => {
    if (!isPlaying) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    const intervalMs = { 1: 1500, 2: 800, 3: 400 }[speed] || 1000;
    timerRef.current = setInterval(() => {
      setVisibleCount((prev) => {
        if (!cluster || prev >= cluster.incidents.length) {
          setIsPlaying(false);
          clearInterval(timerRef.current);
          return prev;
        }
        return prev + 1;
      });
    }, intervalMs);
    return () => clearInterval(timerRef.current);
  }, [isPlaying, speed, cluster]);

  const handlePlayPause = () => {
    if (!isPlaying && cluster && visibleCount >= cluster.incidents.length) {
      // If playing from the end, restart from 1
      setVisibleCount(1);
    }
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setVisibleCount(0);
  };

  const handleShowAll = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
    if (cluster) setVisibleCount(cluster.incidents.length);
  };

  const handleNodeClick = (nodeName) => {
    if (selectedNode === nodeName) {
      setSelectedNode(null);
    } else {
      setSelectedNode(nodeName);
    }
  };

  if (!cluster) return <div style={{ padding: 40 }}>No horizontal cluster found for the selected time window.</div>;

  // 1. CALCULATE INCIDENT COUNTS PER SERVICE FOR CIRCLE DISPLAY
  const serviceCounts = {};
  (cluster.incidents || []).forEach((inc) => {
    const key = inc.short_name || inc.service;
    serviceCounts[key] = (serviceCounts[key] || 0) + 1;
  });

  // 2. DYNAMIC TRIANGULAR / SQUARE / POLYGON POSITION GENERATOR
  const numNodes = cluster.cascade_chain.length;
  const nodePositions = cluster.cascade_chain.map((item, idx) => {
    const isRoot = idx === 0;
    let x = 180;
    let y = 180;
    if (numNodes === 2) {
      x = idx === 0 ? 100 : 260;
      y = 180;
    } else if (numNodes === 3) {
      if (idx === 0) { x = 180; y = 70; }
      else if (idx === 1) { x = 80; y = 260; }
      else { x = 280; y = 260; }
    } else if (numNodes === 4) {
      if (idx === 0) { x = 180; y = 60; }
      else if (idx === 1) { x = 290; y = 170; }
      else if (idx === 2) { x = 180; y = 280; }
      else { x = 70; y = 170; }
    } else {
      const angle = (idx * (360 / numNodes) - 90) * (Math.PI / 180);
      x = 180 + 110 * Math.cos(angle);
      y = 180 + 110 * Math.sin(angle);
    }

    return {
      ...item,
      x,
      y,
      isRoot,
      color: isRoot ? '#c8102e' : '#d97706',
      // Slightly increased radius so both service name & count fit cleanly inside the circle
      radius: isRoot ? 38 : 32
    };
  });

  // 3. MAP SERVICE NAMES TO NODE COLORS FOR INCIDENT CARDS
  const serviceColorMap = {};
  nodePositions.forEach((node) => {
    serviceColorMap[node.short_name] = node.color;
    serviceColorMap[node.service] = node.color;
  });

  const getEdgeCoordinates = (n1, n2) => {
    const dx = n2.x - n1.x;
    const dy = n2.y - n1.y;
    const dist = Math.sqrt(dx * dx + dy * dy) || 1;
    const unitX = dx / dist;
    const unitY = dy / dist;
    const startX = n1.x + unitX * (n1.radius + 6);
    const startY = n1.y + unitY * (n1.radius + 6);
    const endX = n2.x - unitX * (n2.radius + 12);
    const endY = n2.y - unitY * (n2.radius + 12);
    return { startX, startY, endX, endY };
  };

  const visibleIncidents = cluster.incidents.slice(0, visibleCount);
  const visibleServices = new Set(visibleIncidents.map((inc) => inc.service));
  let activeNodeCount = 0;
  for (let i = 0; i < cluster.cascade_chain.length; i++) {
    if (visibleServices.has(cluster.cascade_chain[i].service)) {
      activeNodeCount = i + 1;
    } else {
      break;
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      
      {/* TOP METRIC RIBBON */}
      <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
        <div className="stat-card rc" style={{ padding: '18px 20px', flex: '1', minWidth: '380px' }}>
          <span style={{ background: 'var(--status-critical)', color: '#fff', padding: '4px 10px', borderRadius: '12px', fontSize: '10px', fontWeight: 700, textTransform: 'uppercase', fontFamily: 'var(--disp)' }}>
            Root Cause ({cluster.root_incident_number})
          </span>
          <div style={{ color: '#991b1b', fontSize: '15px', fontWeight: 600, marginTop: '8px', fontFamily: 'var(--disp)' }}>
            {cluster.root_cause}
          </div>
        </div>
        {/* ROOT CAUSE TIME CARD */}
        <div className="stat-card" style={{ padding: '12px 20px', minWidth: '180px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase' }}>Root Cause Time</div>
          <div style={{ fontSize: '22px', fontWeight: 700, color: 'var(--status-critical)', fontFamily: 'var(--disp)', marginTop: '4px' }}>
            {cluster.root_incident_opened ? cluster.root_incident_opened.split('T')[1] || cluster.root_incident_opened : 'N/A'}
          </div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '2px', fontFamily: 'var(--mono)' }}>
            {cluster.root_incident_opened ? cluster.root_incident_opened.split('T')[0] : ''}
          </div>
        </div>
        {/* TOTAL INCIDENTS CARD */}
        <div className="stat-card" style={{ padding: '12px 20px', minWidth: '160px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase' }}>Total Incidents</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: 'var(--text)', fontFamily: 'var(--disp)', marginTop: '4px' }}>
            {cluster.incident_count} Grouped
          </div>
        </div>
      </div>

      {/* TWO COLUMN GRID: LEFT CASCADE GRAPH | RIGHT INCIDENTS LIST */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: '20px', marginBottom: '4px' }}>
        
        {/* LEFT SIDE: SVG CASCADE */}
        <div className="stat-card" style={{ padding: '18px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '8px' }}>
            <h3 style={{ margin: 0, fontSize: '13px', color: 'var(--status-critical)', textTransform: 'uppercase' }}>
              Application Cascade Graph ({cluster.cascade_chain.length} Applications)
            </h3>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Click nodes to explore vertical clusters</div>
          </div>
          <div style={{ display: 'flex', gap: '6px', alignItems: 'center', marginBottom: '10px' }}>
              <button
                className="cta-btn"
                style={{ padding: '5px 12px', fontSize: '11px' }}
                onClick={handlePlayPause}
              >
                {isPlaying ? '  Pause' : '  Play Cascade'}
              </button>
              <button
                className="cta-btn ghost"
                style={{ padding: '5px 10px', fontSize: '11px' }}
                onClick={handleReset}
              >
                Reset
              </button>
              <button
                className="cta-btn ghost"
                style={{ padding: '5px 10px', fontSize: '11px' }}
                onClick={handleShowAll}
              >
                Show All
              </button>
              <select
                value={speed}
                onChange={(e) => setSpeed(Number(e.target.value))}
                style={{ padding: '4px 6px', fontSize: '11px', borderRadius: '4px', border: '1px solid var(--border)', background: '#fff', color: 'var(--text)', cursor: 'pointer' }}
              >
                <option value={1}>1x</option>
                <option value={2}>2x</option>
                <option value={3}>3x</option>
              </select>
          </div>
          <div style={{ background: 'var(--bg-panel)', borderRadius: '8px', border: '1px solid var(--border)', padding: '16px', flex: 1, minHeight: '440px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg viewBox="0 0 360 340" style={{ width: '100%', height: '100%', display: 'block' }}>
              <defs>
                <marker id="cascade-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="var(--status-critical)" />
                </marker>
              </defs>
              {nodePositions.map((node, i) => {
                if (i === 0 || i >= activeNodeCount) return null;
                const prev = nodePositions[i - 1];
                const { startX, startY, endX, endY } = getEdgeCoordinates(prev, node);
                return (
                  <g key={`edge-${i}`}>
                    <line x1={startX} y1={startY} x2={endX} y2={endY} stroke="var(--status-critical)" strokeWidth="2.8" strokeDasharray="6 4" markerEnd="url(#cascade-arrow)" style={{ animation: 'dashMove 0.6s linear infinite' }} />
                    <circle cx={(startX + endX) / 2} cy={(startY + endY) / 2} r="10" fill="#fff" stroke="var(--status-critical)" strokeWidth="1.5" />
                    <text x={(startX + endX) / 2} y={(startY + endY) / 2 + 3} textAnchor="middle" fill="#991b1b" fontSize="10" fontWeight="700">
                      {i}
                    </text>
                  </g>
                );
              })}
              {nodePositions.map((node, i) => {
                const isReached = i < activeNodeCount;
                const isSelected = selectedNode === node.short_name;
                const count = serviceCounts[node.short_name] || serviceCounts[node.service] || 0;
                
                return (
                  <g 
                    key={node.short_name} 
                    onClick={() => handleNodeClick(node.short_name)}
                    style={{ opacity: isReached ? 1 : 0.4, transition: 'all 0.4s ease', cursor: 'pointer' }}
                  >
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={node.radius}
                      fill={node.isRoot ? 'var(--status-critical-bg)' : '#fff'}
                      stroke={isSelected ? '#2563eb' : node.color}
                      strokeWidth={isSelected ? 4 : (node.isRoot ? 3.5 : 2.5)}
                      style={{ filter: node.isRoot ? 'drop-shadow(0 0 10px rgba(200, 16, 46, 0.3))' : 'none' }}
                    />
                    {/* LINE 1: Short Service Name */}
                    <text x={node.x} y={node.y - 3} textAnchor="middle" fill={isSelected ? '#2563eb' : 'var(--text)'} fontSize="13" fontWeight="700" fontFamily="var(--disp)">
                      {node.short_name}
                    </text>
                    {/* LINE 2: Incident Count inside Circle */}
                    <text x={node.x} y={node.y + 14} textAnchor="middle" fill={isSelected ? '#1d4ed8' : node.color} fontSize="11" fontWeight="700" fontFamily="var(--mono)">
                      ({count})
                    </text>

                    <text x={node.x} y={node.y + 52} textAnchor="middle" fill="var(--text-muted)" fontSize="11" fontFamily="var(--mono)">
                      {node.service}
                    </text>
                    {node.isRoot && (
                      <text x={node.x} y={node.y - 48} textAnchor="middle" fill="#991b1b" fontSize="10" fontWeight="700">
                        ROOT CAUSE
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* RIGHT SIDE: SCROLLABLE INCIDENTS DETAILS */}
        <div className="stat-card" style={{ padding: '18px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
            <h3 style={{ margin: 0, fontSize: '13px', color: 'var(--status-critical)', textTransform: 'uppercase' }}>
              Incident Details ({visibleCount} / {cluster.incident_count} Shown)
            </h3>
            <span style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--mono)' }}>
              {isPlaying ? '   Correlating Live...' : 'Paused'}
            </span>
          </div>
          <div style={{ flex: 1, maxHeight: '520px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '10px', paddingRight: '4px' }}>
            {visibleIncidents.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--text-muted)', fontSize: '13px' }}>
                Click <strong>"  Play Cascade"</strong> above to watch incidents appear and trace the edges across services.
              </div>
            ) : (
              visibleIncidents.map((inc) => {
                const isHighlighted = selectedNode === inc.short_name;
                // Match left border & badge to the exact color of the service's node in the SVG graph
                const serviceColor = serviceColorMap[inc.short_name] || serviceColorMap[inc.service] || '#64748b';

                return (
                  <div
                    key={inc.number}
                    style={{
                      border: '1px solid var(--border)',
                      borderLeft: `5px solid ${serviceColor}`,
                      borderRadius: '6px',
                      padding: '12px',
                      background: isHighlighted ? '#eff6ff' : '#fff',
                      animation: 'fadeIn 0.3s ease',
                      transition: 'all 0.2s ease'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', flexWrap: 'wrap', gap: '6px' }}>
                      <span style={{ fontWeight: 700, color: serviceColor, fontSize: '13px' }}>
                        {inc.number} &middot; {inc.opened}
                      </span>
                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                        <span 
                          className="kbd" 
                          style={{ 
                            background: isHighlighted ? '#bfdbfe' : 'var(--bg-panel)', 
                            color: isHighlighted ? '#1e3a8a' : serviceColor, 
                            fontWeight: 'bold',
                            border: `1px solid ${serviceColor}40`
                          }}
                        >
                          {inc.short_name || inc.service}
                        </span>
                        <span className="kbd">Priority: {inc.priority}</span>
                        <span className="kbd">Severity: {inc.severity}</span>
                      </div>
                    </div>
                    <div style={{ fontSize: '13px', color: 'var(--text)', fontFamily: 'var(--mono)', marginBottom: '8px', lineHeight: 1.4 }}>
                      {inc.short_description}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Conditionally Render Vertical Correlation for BEN */}
      {selectedNode === 'BEN' && drilldownData && (
        <div style={{ marginTop: '4px', padding: '1.5rem', background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '12px' }}>
          <h3 style={{ color: '#1e40af', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ background: '#3b82f6', color: 'white', padding: '2px 8px', borderRadius: '12px', fontSize: '0.75rem', fontWeight: 'bold' }}>DRILLDOWN</span>
            Vertical Correlation for {selectedNode}
          </h3>
          <VerticalCorrelation corrData={drilldownData} isEvent2={true} />
        </div>
      )}

      {/* BOTTOM CARD: LLM-GENERATED ROOT CAUSE & CORRELATION RATIONALE */}
      <div className="stat-card rc" style={{ padding: '22px 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
          <span className="exec-badge" style={{ margin: 0 }}>AI SRE Analysis &amp; Correlation Rationale</span>
          <span style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--mono)' }}>Generated by OpenAI / Gemini LLM</span>
        </div>
        <div style={{ display: 'grid', gap: '14px', fontSize: '13.5px', lineHeight: '1.6' }}>
          <div>
            <b style={{ color: '#991b1b', display: 'block', marginBottom: '2px' }}>Likely Root Cause:</b>
            <span dangerouslySetInnerHTML={{ __html: cluster.llm_analysis?.likely_root_cause || "Analyzing root cause..." }} />
          </div>
          <div style={{ borderTop: '1px dashed var(--border)', paddingTop: '10px' }}>
            <b style={{ color: 'var(--text)', display: 'block', marginBottom: '2px' }}>Business &amp; Operational Impact:</b>
            <span dangerouslySetInnerHTML={{ __html: cluster.llm_analysis?.business_impact || "Analyzing business impact..." }} />
          </div>
          <div style={{ borderTop: '1px dashed var(--border)', paddingTop: '10px' }}>
            <b style={{ color: 'var(--text)', display: 'block', marginBottom: '2px' }}>Correlation Rule Applied:</b>
            <span dangerouslySetInnerHTML={{ __html: cluster.llm_analysis?.correlation_rule_applied || "Analyzing correlation rules..." }} />
          </div>
        </div>
      </div>
    </div>
  );
}