import React from "react";

export default function VerticalCorrelation({ corrData, isEvent2 }) {
  if (!corrData) return <div>No vertical correlation data available.</div>;
  const incident = corrData.incident;

  return (
    <>
      {!isEvent2 ? (
        <div className="exec-row">
          <div className="exec-card rc">
            <span className="exec-badge">Root Cause</span>
            <h2>
              {incident?.root_cause || "Unknown Root Cause"}
            </h2>
            <p className="exec-desc" dangerouslySetInnerHTML={{ __html: incident?.root_cause_desc || "Loading incident details..." }}>
            </p>
            <div className="exec-metrics">
              <div className="exec-metric">
                <div className="m-val">{(corrData?.children?.length ?? 0) + 1}</div>
                <div className="m-lbl">raw alerts grouped</div>
              </div>
              <div className="exec-metric">
                <div className="m-val">{incident?.tools_contributing ?? "-"}</div>
                <div className="m-lbl">tools contributing</div>
              </div>
              <div className="exec-metric">
                <div className="m-val">{incident?.correlation_confidence_pct ?? "-"}%</div>
                <div className="m-lbl">correlation confidence</div>
              </div>
            </div>
          </div>
          <div className="exec-side">
            <h3>Business Impact</h3>
            <div className="impact-row">
              <span className="lb2">Journey affected</span>
              <span className="vv">Health & Dental Claims</span>
            </div>
            <div className="impact-row">
              <span className="lb2">Sub-journey</span>
              <span className="vv">Claims Adjudication</span>
            </div>
            <div className="impact-row">
              <span className="lb2">Availability</span>
              <span className="vv bad">94.20 %</span>
            </div>
            <div className="impact-row">
              <span className="lb2">Frustrated users</span>
              <span className="vv bad">10 % · {incident?.frustrated_user_count ?? 152} members</span>
            </div>
            <div className="impact-row">
              <span className="lb2">Incident ID</span>
              <span className="vv">{incident?.id ?? "INC0048291"}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="card" style={{ display: 'flex', gap: '2rem', background: '#fef2f2', border: '1px solid #fca5a5' }}>
          <div style={{ flex: 1, borderRight: '1px dashed #fca5a5', paddingRight: '2rem' }}>
            <span className="badge critical" style={{ background: 'var(--status-critical)', color: 'white', border: 'none', marginBottom: '1rem', display: 'inline-block', padding: '4px 8px', borderRadius: '4px', fontSize: '10px', fontWeight: 'bold' }}>ROOT CAUSE</span>
            <div style={{ color: 'var(--status-critical)', fontWeight: 700, fontSize: '1.1rem', marginBottom: '0.5rem', fontFamily: 'var(--disp)' }}>
              {incident?.root_cause || corrData.parent?.description || "Unknown Root Cause"}
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-main)', marginTop: '0.5rem' }} dangerouslySetInnerHTML={{ __html: incident?.root_cause_desc || "Loading incident details..." }}></div>
          </div>
          
          <div style={{ width: '300px', display: 'flex', flexDirection: 'column', gap: '1rem', justifyContent: 'center' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px dashed #fca5a5', paddingBottom: '0.5rem' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Raw Alerts Grouped</span>
              <span style={{ fontWeight: 700, color: 'var(--status-critical)' }}>{(corrData?.children?.length ?? 0) + 1}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px dashed #fca5a5', paddingBottom: '0.5rem' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Tools Contributing</span>
              <span style={{ fontWeight: 700, color: 'var(--status-critical)' }}>{incident?.tools_contributing ?? "-"}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Correlation Confidence</span>
              <span style={{ fontWeight: 700, color: 'var(--status-critical)' }}>{incident?.correlation_confidence_pct ?? "-"}%</span>
            </div>
          </div>
        </div>
      )}

      <section className="analysis-section" style={{ marginTop: '24px' }}>
        <div className="sec-head">
          <div className="sec-step" style={{ background: 'var(--text-muted)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
          </div>
          <div>
            <h2 className="sec-title">Clustered Incidents Timeline</h2>
            <p className="sec-sub">
              Cluster: {corrData.parent?.extractedJob} | Pattern: {corrData.parent?.grammar} | Application: {corrData.parent?.service}
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {/* PARENT ROW */}
          {corrData.parent && (
            <div style={{ 
              background: 'var(--bg-panel)', 
              border: '1px solid var(--status-warning)', 
              borderRadius: '8px', 
              padding: '16px' 
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontWeight: 'bold', color: 'var(--status-warning)' }}>{corrData.parent.id} (PARENT)</span>
                <span style={{ color: 'var(--text-muted)' }}>{corrData.parent.time}</span>
              </div>
              <div style={{ fontFamily: 'monospace', color: 'var(--text-main)' }}>
                {corrData.parent.description}
              </div>
            </div>
          )}

          {/* CHILDREN ROWS */}
          {(corrData.children || []).map(child => (
            <div key={child.id} style={{ 
              background: 'var(--bg-panel)', 
              border: '1px solid var(--border)', 
              borderRadius: '8px', 
              padding: '16px',
              marginLeft: '40px',
              position: 'relative'
            }}>
              <div style={{
                position: 'absolute',
                left: '-24px',
                top: '24px',
                width: '24px',
                height: '2px',
                background: 'var(--border)'
              }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <span style={{ fontWeight: 'bold', color: 'var(--status-ok)' }}>{child.id} (CHILD)</span>
                  {child.missedBySplunk && (
                    <span style={{
                      background: 'var(--status-critical)',
                      color: '#fff',
                      padding: '2px 8px',
                      borderRadius: '12px',
                      fontSize: '10px',
                      fontWeight: 'bold',
                      letterSpacing: '0.5px'
                    }}>MISSED BY SPLUNK</span>
                  )}
                </div>
                <div style={{ display: 'flex', gap: '16px', color: 'var(--text-muted)' }}>
                  <span>Delta: {child.delta}</span>
                  <span>{child.time}</span>
                </div>
              </div>
              <div style={{ fontFamily: 'monospace', color: 'var(--text-main)', marginBottom: '12px' }}>
                {child.description}
              </div>
              
              {/* CONFIDENCE BAR */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '12px' }}>
                <span style={{ color: 'var(--text-muted)' }}>Confidence Score:</span>
                <div style={{ flex: 1, background: 'var(--bg)', height: '6px', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ 
                    width: `${child.confidence * 100}%`, 
                    background: child.confidence >= 0.9 ? 'var(--status-ok)' : 'var(--status-warning)', 
                    height: '100%' 
                  }} />
                </div>
                <span style={{ fontWeight: 'bold' }}>{(child.confidence * 100).toFixed(0)}%</span>
              </div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '4px' }}>
                Boosters: {(child.boosters || []).join(', ')}
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
