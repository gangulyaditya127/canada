import React from 'react';
import { nowLong } from '../utils/time';

export default function StepsView({ journeyKey, subJourneys, onBack, onOpenStep }) {
  const j = subJourneys[journeyKey];
  if (!j) return null;

  // Helper for availability text color
  const getAvailColor = (avail, isCritical) => {
    if (isCritical || avail < 80) return 'var(--cl-red)';
    if (avail >= 95) return 'var(--green)';
    return 'var(--amber)';
  };

  return (
    <div className="view">
      <button className="back-btn" onClick={onBack}>&larr; Go back</button>
      <div className="eyebrow">Journey Execution Experience</div>
      <h1>{j.title}</h1>
      <div className="timestamp">{nowLong()}</div>
      <div className="sub-hint">
        Click on sub-journey name to inspect its incident for event correlation.
      </div>

      <div className="table-panel">
        <table className="j-table" style={{ borderCollapse: 'collapse', width: '100%' }}>
          <thead>
            <tr>
              {/* 1. RENAMED: "Steps" -> "Sub-journey" */}
              <th style={{ width: '22%' }}>Sub-journey</th>
              <th className="n" style={{ width: '18%', textAlign: 'center' }}>
                Happy + Unhappy + Frustrated
              </th>
              {/* 2. RENAMED: "Actions / API" -> "Services" */}
              <th style={{ width: '24%' }}>Applications</th>
              <th className="n" style={{ width: '10%' }}>Average Resp time</th>
              <th className="n" style={{ width: '8%' }}>P(95)</th>
              <th className="n" style={{ width: '8%' }}>Error Rate</th>
              <th className="n" style={{ width: '10%' }}>Availability</th>
            </tr>
          </thead>
          <tbody>
            {j.steps.map((step, stepIdx) => {
              // Ensure there is at least one service row to render
              const services = step.services && step.services.length > 0
                ? step.services
                : [{
                    id: step.id,
                    name: step.api || 'REST API',
                    shortName: '',
                    avg: step.avg || 0,
                    p95: step.p95 || 0,
                    err: step.err || 0,
                    avail: step.avail || 100.0,
                  }];

              const rowSpanCount = services.length;

              return services.map((svc, svcIdx) => {
                // Determine if this specific service row is degraded/critical
                let isSvcCritical = svc.err >= 5 || svc.avail < 80 ;
                let displayAvail = Number(svc.avail);

                // Override for DEBS and eClaims for demo purposes
                if (svc.name === 'Data Entry Benefits System - AS' || svc.shortName === 'DEBS' || 
                    svc.name === 'eClaims - AS' || svc.shortName === 'eClaims') {
                  displayAvail = 95.0;
                  isSvcCritical = true;
                }

                const rowTextColor = isSvcCritical ? 'var(--cl-red)' : 'inherit';

                return (
                  <tr
                    key={`${step.id}-${svc.id || svcIdx}`}
                    style={{
                      // Top border separates major steps; inner service rows have subtle separators
                      borderTop: svcIdx === 0 
                        ? '1px solid var(--border)' 
                        : '1px solid rgba(230, 213, 213, 0.4)',
                    }}
                  >
                    {/* COLUMN 1 & 2: Rendered ONLY on the first service row of each step and merged down */}
                    {svcIdx === 0 && (
                      <>
                        {/* 3. CLICKABLE SUB-JOURNEY CELL ONLY */}
                        <td
                          rowSpan={rowSpanCount}
                          onClick={() => onOpenStep(step.id)}
                          style={{
                            verticalAlign: 'middle',
                            borderRight: '1px solid var(--border)',
                            fontWeight: 700,
                            fontFamily: 'var(--disp)',
                            fontSize: '14px',
                            color: step.critical ? 'var(--cl-red)' : 'var(--text)',
                            padding: '16px 18px',
                            cursor: 'pointer',
                            transition: 'all 0.15s ease',
                          }}
                          title={`Click to open Vertical Correlation for ${step.name}`}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.backgroundColor = 'var(--cl-red-tint)';
                            e.currentTarget.style.textDecoration = 'underline';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.backgroundColor = 'transparent';
                            e.currentTarget.style.textDecoration = 'none';
                          }}
                        >
                          {step.name}
                        </td>

                        {/* Column 2: Happy + Unhappy + Frustrated Split (Non-clickable) */}
                        <td
                          rowSpan={rowSpanCount}
                          style={{
                            verticalAlign: 'middle',
                            borderRight: '1px solid var(--border)',
                            textAlign: 'center',
                            padding: '16px 14px',
                          }}
                        >
                          {step.hu ? (
                            <div
                              style={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                gap: '12px',
                                fontFamily: 'var(--disp)',
                                fontWeight: 700,
                                fontSize: '14px',
                              }}
                            >
                              <span style={{ color: 'var(--green)' }}>{step.hu[0]}%</span>
                              <span style={{ color: 'var(--amber)' }}>{step.hu[1]}%</span>
                              <span style={{ color: 'var(--cl-red)' }}>{step.hu[2]}%</span>
                            </div>
                          ) : (
                            <span style={{ color: 'var(--text-dimmer)' }}>—</span>
                          )}
                        </td>
                      </>
                    )}

                    {/* COLUMN 3: Service / Action Name */}
                    <td style={{ padding: '12px 18px' }}>
                      <span
                        style={{
                          fontWeight: isSvcCritical ? 700 : 600,
                          color: rowTextColor,
                          fontFamily: 'var(--disp)',
                          fontSize: '13.5px',
                        }}
                      >
                        {svc.name} {svc.shortName ? `(${svc.shortName})` : ''}
                      </span>
                    </td>

                    {/* COLUMN 4: Average Resp Time */}
                    <td
                      className="num-cell"
                      style={{
                        color: rowTextColor,
                        fontWeight: isSvcCritical ? 700 : 400,
                        padding: '12px 18px',
                      }}
                    >
                      {svc.avg} ms
                    </td>

                    {/* COLUMN 5: P(95) */}
                    <td
                      className="num-cell"
                      style={{
                        color: rowTextColor,
                        fontWeight: isSvcCritical ? 700 : 400,
                        padding: '12px 18px',
                      }}
                    >
                      {svc.p95} ms
                    </td>

                    {/* COLUMN 6: Error Rate */}
                    <td
                      className="num-cell"
                      style={{
                        color: svc.err >= 5 ? 'var(--cl-red)' : 'inherit',
                        fontWeight: svc.err >= 5 ? 700 : 400,
                        padding: '12px 18px',
                      }}
                    >
                      {svc.err} %
                    </td>

                    {/* COLUMN 7: Availability */}
                    <td
                      className="num-cell"
                      style={{
                        color: getAvailColor(displayAvail, isSvcCritical),
                        fontWeight: 700,
                        padding: '12px 18px',
                      }}
                    >
                      {displayAvail.toFixed(2)} %
                    </td>
                  </tr>
                );
              });
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}