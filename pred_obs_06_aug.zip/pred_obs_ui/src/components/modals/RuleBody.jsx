export default function RuleBody({ rule, onOpenAlert }) {
  const inputs = rule.combine.inputs;
  const N = inputs.length;
  const rowH = 64, marginY = 30;
  const svgH = Math.max(N * rowH + marginY * 2, 260);
  const inputBoxW = 220, inputX = 20;
  const combineX = 290, combineW = 280;
  const outputX = 610, outputW = 280;
  const combineY = svgH / 2 - 40, outputY = svgH / 2 - 45;

  return (
    <>
      <div className="rule-graph">
        <div style={{fontFamily:'var(--disp)',fontWeight:700,fontSize:12,marginBottom:10}}>Rule graph — inputs → combine → correlated incident</div>
        <svg viewBox={`0 0 920 ${svgH}`} className="rgraph">
          {inputs.map((i, idx) => {
            const y = marginY + idx * rowH;
            return (
              <g key={idx}>
                <rect x={inputX} y={y} width={inputBoxW} height={rowH - 14} className="rg-node trigger" rx="6" />
                <foreignObject x={inputX + 8} y={y + 6} width={inputBoxW - 16} height={rowH - 12 - 6}>
                  <div xmlns="http://www.w3.org/1999/xhtml" style={{fontFamily:"'Space Grotesk',sans-serif",fontSize:11,color:'#2a1418',lineHeight:1.35,wordBreak:'break-word'}}>
                    <div style={{fontWeight:700}}>{i.tool}</div>
                    <div style={{fontFamily:"'IBM Plex Mono',monospace",fontSize:9.5,color:'#7a5a5f',marginTop:2}}>{i.signal}</div>
                  </div>
                </foreignObject>
                <path
                  d={`M ${inputX + inputBoxW} ${y + (rowH - 14) / 2} C ${inputX + inputBoxW + 30} ${y + (rowH - 14) / 2}, ${combineX - 30} ${combineY + 40}, ${combineX} ${combineY + 40}`}
                  className="rg-edge"
                />
              </g>
            );
          })}
          <rect x={combineX} y={combineY} width={combineW} height={80} className="rg-node combine" rx="6" />
          <foreignObject x={combineX + 8} y={combineY + 6} width={combineW - 16} height={80 - 12}>
            <div xmlns="http://www.w3.org/1999/xhtml" style={{fontFamily:"'Space Grotesk',sans-serif",fontSize:11,color:'#2a1418',lineHeight:1.35,wordBreak:'break-word'}}>
              <div style={{fontWeight:700}}>Combine logic</div>
              <div style={{fontFamily:"'IBM Plex Mono',monospace",fontSize:9.5,color:'#7a5a5f',marginTop:3}}>{rule.combine.logic}</div>
            </div>
          </foreignObject>
          <path
            d={`M ${combineX + combineW} ${combineY + 40} L ${outputX} ${outputY + 45}`}
            className="rg-edge emphasized"
          />
          <rect x={outputX} y={outputY} width={outputW} height={90} className="rg-node output" rx="6" />
          <foreignObject x={outputX + 8} y={outputY + 6} width={outputW - 16} height={90 - 12}>
            <div xmlns="http://www.w3.org/1999/xhtml" style={{fontFamily:"'Space Grotesk',sans-serif",fontSize:11,color:'#2a1418',lineHeight:1.35,wordBreak:'break-word'}}>
              <div style={{fontWeight:700,color:'#9c0b23'}}>Correlated Incident</div>
              <div style={{fontSize:10.5,marginTop:3}}>{rule.output}</div>
            </div>
          </foreignObject>
        </svg>
      </div>
      <div className="explain-box"><h5>Plain-English</h5><p>{rule.plain}</p></div>
      <div className="explain-box"><h5>Trigger</h5><p><b>When:</b> {rule.trigger.when}</p><p><b>Target:</b> {rule.trigger.target}</p></div>
      <div className="explain-box">
        <h5>Combine logic</h5>
        <p><code>{rule.combine.logic}</code></p>
        <div style={{marginTop:6}}>
          {rule.combine.inputs.map((i, k) => (
            <div key={k} className="kv-row"><span className="kk">{i.tool}</span><span className="vv">{i.signal}</span></div>
          ))}
        </div>
      </div>
      <div className="explain-box">
        <h5>Why this correlation makes sense</h5>
        {rule.explain.map((p, i) => <p key={i}>{p}</p>)}
      </div>
      <div className="explain-box">
        <h5>Action taken</h5>
        <p>{rule.output}</p>
        <div className="rule-badges" style={{marginTop:8}}>
          {rule.involves.map(x => (
            <span key={x} className="rule-badge" onClick={() => onOpenAlert(x)}>{x} · view alert</span>
          ))}
        </div>
      </div>
    </>
  );
}
