export default function AlertDetailBody({ alert, relatedRules, onOpenRule }) {
  return (
    <>
      <div className="alert-hero">
        <span className="a-sev">{alert.sev}</span>
        <span className="a-src">{alert.src} · {alert.component}</span>
        <div className="a-name">{alert.name}</div>
        <div className="a-desc">{alert.desc}</div>
      </div>
      <div className="a-meta-grid">
        {alert.metrics.map(([k, v]) => (
          <div key={k} className="a-meta"><div className="k">{k}</div><div className="v">{v}</div></div>
        ))}
      </div>
      <div className="explain-box">
        <h5>Historical occurrence</h5>
        <p>Seen <b>{alert.occurrences7d} times</b> in the last 7 days · <b>{alert.occurrences30d} times</b> in the last 30 days.</p>
        <p><b>First seen today:</b> {alert.firstSeen}</p>
      </div>
      <div className="explain-box">
        <h5>Related correlations</h5>
        <p>{relatedRules.length > 0 ? 'This alert is part of:' : 'Not currently part of any active correlation.'}</p>
        <div className="rule-badges" style={{marginTop:8}}>
          {relatedRules.map(r => (
            <span key={r.id} className="rule-badge" onClick={() => onOpenRule(r.id)}>{r.id} · {r.name}</span>
          ))}
        </div>
      </div>
    </>
  );
}
