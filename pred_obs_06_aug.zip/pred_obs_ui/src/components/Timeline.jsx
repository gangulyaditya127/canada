import { toSec, fmtHMS } from '../utils/time';

export default function Timeline({ alerts }) {
  if (!alerts.length) return <div className="tl" />;
  const times = alerts.map(a => toSec(a.time));
  const minT = Math.min(...times), maxT = Math.max(...times);
  const range = Math.max(maxT - minT, 60);
  const pad = Math.max(range * 0.15, 10);
  const winStart = minT - pad, winEnd = maxT + pad;
  const winLen = winEnd - winStart;
  const ticks = [0, 0.33, 0.66, 1].map(f => winStart + f * winLen);
  return (
    <div className="tl">
      <div className="tl-axis" />
      {ticks.map((t, i) => {
        const pct = ((t - winStart) / winLen) * 100;
        return (
          <span key={'k'+i}>
            <div className="tl-tick" style={{ left: pct + '%' }} />
            <div className="tl-tick-lbl" style={{ left: pct + '%' }}>{fmtHMS(Math.round(t))}</div>
          </span>
        );
      })}
      {alerts.map((a, i) => {
        const s = toSec(a.time);
        const pct = ((s - winStart) / winLen) * 100;
        return (
          <div key={a.ref+i} className={'tl-dot' + (a.sev === 'high' ? ' high' : '')} style={{ left: pct + '%' }}>
            <div className="tl-tooltip">{a.time} · {a.ref}</div>
          </div>
        );
      })}
    </div>
  );
}
