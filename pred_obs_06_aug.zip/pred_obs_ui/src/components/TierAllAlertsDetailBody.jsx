import AlertDetailBody from './AlertDetailBody';

export default function TierAllAlertsDetailBody({ tier, rawAlerts, rules }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {tier.alerts.map((tierAlert) => {
        const a = rawAlerts[tierAlert.ref];
        if (!a) return null;
        const related = rules.filter(r => r.involves.includes(tierAlert.ref));
        
        return (
          <div key={tierAlert.ref} style={{ borderBottom: '1px solid var(--border)', paddingBottom: '20px' }}>
            <AlertDetailBody alert={a} relatedRules={related} onOpenRule={() => {}} />
          </div>
        );
      })}
    </div>
  );
}