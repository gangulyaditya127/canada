# Canada Life · ARE Observability (React)

React (Vite) port of the observability prototype. Same look & behaviour as the source
HTML, but all data is externalised as JSON in `public/data/*.json` and loaded through
`src/services/observabilityService.js`. Swap that service with a real API client when
your backend is ready — components do not need to change.

## Run
```bash
npm install
npm run dev      # open http://localhost:5173
```

## Build
```bash
npm run build    # produces dist/ ready for static hosting
npm run preview
```

## Project structure
```
observability-react/
├── index.html
├── package.json
├── vite.config.js
├── public/
│   └── data/                      ← all datasets live here as JSON
│       ├── journeys.json
│       ├── subJourneys.json
│       ├── tiers.json
│       ├── rawAlerts.json
│       ├── corrData.json
│       └── rules.json
└── src/
    ├── main.jsx
    ├── App.jsx                    ← top-level state + routing
    ├── styles.css                 ← identical CSS to the HTML prototype
    ├── services/
    │   └── observabilityService.js  ← fetch layer (swap for real API)
    ├── utils/
    │   └── time.js
    ├── context/
    │   ├── ModalContext.jsx       ← single-modal manager (Esc / backdrop close)
    │   └── ToastContext.jsx
    └── components/
        ├── TopBar.jsx
        ├── JourneysView.jsx
        ├── StepsView.jsx
        ├── AnalysisView.jsx       ← sections 1 (tiers) + 2 (correlation)
        ├── DetailView.jsx         ← rules list
        ├── TierCard.jsx
        ├── Timeline.jsx           ← auto-scaled per-tier timeline
        ├── CorrelationDiagram.jsx ← swim-lane SVG
        └── modals/
            ├── AlertDetailBody.jsx
            ├── TierAlertsBody.jsx
            └── RuleBody.jsx
```

## Data contract
Every dataset is loaded through `observabilityService`, e.g.
```js
import { observabilityService } from './services/observabilityService';
const tiers = await observabilityService.getTiers();
```
Wire it to a real backend:
```js
async function fetchJson(path) {
  const res = await fetch(`${API_BASE}/${path.replace('.json','')}`);
  return res.json();
}
```
No component depends on where the data comes from.

## Routing
Simple in-memory routing lives in `App.jsx` (`view` state).
Views: `journeys` → `steps` → `analysis` → `detail`.
Swap in React Router later without touching any presentational component.
