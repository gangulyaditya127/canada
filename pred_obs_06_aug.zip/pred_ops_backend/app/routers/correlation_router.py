from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from app.database import get_db
from app.services import correlation_service

router = APIRouter(prefix="/api/correlation", tags=["correlation"])

@router.get("/clusters")
def get_clusters(
    service_id: int = Query(..., description="The target service ID (e.g. 12 for Benefits - AS)"),
    opened_datetime: str = Query(..., description="The reference datetime in ISO format (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    clusters = correlation_service.build_clusters(service_id, ref_time, db)
    return {
        "service_id": service_id,
        "reference_datetime": opened_datetime,
        "total_clusters_found": len(clusters),
        "clusters": clusters
    }


@router.get("/top_cluster")
def get_top_cluster(
    service_id: int = Query(..., description="The target service ID (e.g. 12 for Benefits - AS)"),
    opened_datetime: str = Query(..., description="The reference datetime in ISO format (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    enriched_cluster = correlation_service.build_dynamic_enriched_top_cluster(service_id, ref_time, db)
    if not enriched_cluster:
        return {"error": f"No clusters found for service_id={service_id} and time window."}
        
    return enriched_cluster
@router.get("/splunk_children")
def get_splunk_children(
    parent_id: str = Query(..., description="The parent incident ID to search for"),
    db: Session = Depends(get_db)
):
    """
    Returns a list of incident IDs natively grouped by Splunk under a given parent_id.
    """
    return correlation_service.get_splunk_children(parent_id, db)

from app.core.config import settings

@router.get("/horizontal_clusters")
def get_all_horizontal_map_clusters(
    opened_datetime: str = Query(..., description="Reference ISO datetime (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    clusters = correlation_service.build_horizontal_map_clusters(ref_time, db)
    return {
        "reference_datetime": opened_datetime,
        "window_minutes": settings.HORIZONTAL_WINDOW_MINUTES,
        "total_clusters_found": len(clusters),
        "clusters": clusters
    }


@router.get("/horizontal_top_cluster")
def get_top_horizontal_map_cluster(
    opened_datetime: str = Query(..., description="Reference ISO datetime (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    top_cluster = correlation_service.get_top_horizontal_map_cluster(ref_time, db)
    if not top_cluster:
        return {"error": "No horizontal map clusters found for the given time window."}
        
    return {
        "reference_datetime": opened_datetime,
        "window_minutes": settings.HORIZONTAL_WINDOW_MINUTES,
        "top_cluster": top_cluster
    }
