import re
from datetime import datetime, timedelta
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import text


def generalize_desc(desc: str) -> str:
    """Apply the pattern identification logic to generalize a short description."""
    if not desc:
        return "UNKNOWN"
    desc = str(desc).upper()

    # Domain specific masking
    desc = re.sub(r'USER \w+', 'USER <USER_ID>', desc)
    desc = re.sub(r'REGION \w+', 'REGION <REGION>', desc)
    desc = re.sub(r'TRANSACTION \w+', 'TRANSACTION <JOB_NAME>', desc)
    desc = re.sub(r'JOB \w+', 'JOB <JOB_NAME>', desc)

    # Generic alphanumeric ID masking
    desc = re.sub(r'\b[A-Z0-9]*\d[A-Z0-9]*\b', '<ID>', desc)
    desc = re.sub(r'\s+', ' ', desc).strip()

    return desc

def fetch_incidents_for_window(db: Session, service_id: int, window_start: datetime, window_end: datetime) -> list:
    """
    Fetch incidents from the DB for a given service_id within a time window,
    filtered by Caller='ITSI Event Management' and Channel='Monitoring'.
    """
    query = text("""
        SELECT number, opened, short_description, parent_incident,
               assignment_group, service, priority, state, severity, service_id
        FROM incidents
        WHERE service_id = :svc_id
          AND caller = 'ITSI Event Management'
          AND channel = 'Monitoring'
          AND opened >= :start
          AND opened < :end
        ORDER BY opened ASC
    """)
    result = db.execute(query, {
        "svc_id": service_id,
        "start": window_start,
        "end": window_end
    })
    rows = result.fetchall()
    incidents = []
    for row in rows:
        incidents.append({
            "number": row[0],
            "opened": row[1].isoformat() if row[1] else None,
            "short_description": row[2],
            "parent_incident": row[3],
            "assignment_group": row[4],
            "service": row[5],
            "priority": row[6],
            "state": row[7],
            "severity": row[8],
            "service_id": row[9]
        })
    return incidents


def build_clusters(service_id: int, opened_datetime: datetime, db: Session) -> list:
    # ---- STEP 1: Fetch current hour window ----
    current_window_end = opened_datetime
    current_window_start = opened_datetime - timedelta(hours=1)
    current_incidents = fetch_incidents_for_window(db, service_id, current_window_start, current_window_end)
    if not current_incidents:
        return []

    # ---- STEP 2: Cluster by pattern ----
    pattern_groups = {}
    for inc in current_incidents:
        pattern = generalize_desc(inc["short_description"])
        if pattern not in pattern_groups:
            pattern_groups[pattern] = []
        pattern_groups[pattern].append(inc)

    qualifying_clusters = {p: incs for p, incs in pattern_groups.items() if len(incs) >= 2}
    if not qualifying_clusters:
        return []

    # ---- STEP 3: For each cluster, check previous hour ----
    prev_window_end = current_window_start
    prev_window_start = current_window_start - timedelta(hours=1)
    prev_incidents = fetch_incidents_for_window(db, service_id, prev_window_start, prev_window_end)

    prev_pattern_groups = {}
    for inc in prev_incidents:
        pattern = generalize_desc(inc["short_description"])
        if pattern not in prev_pattern_groups:
            prev_pattern_groups[pattern] = []
        prev_pattern_groups[pattern].append(inc)

    # ---- STEP 4 & 5 & 6: Determine parent for each cluster ----
    cluster_results = []
    for pattern, current_cluster_incidents in qualifying_clusters.items():
        prev_matching = prev_pattern_groups.get(pattern, [])
        if prev_matching:
            all_incidents = prev_matching + current_cluster_incidents
            all_incidents_sorted = sorted(all_incidents, key=lambda x: x["opened"] or "")
            earliest = all_incidents_sorted[0]
            if earliest.get("parent_incident") and earliest["parent_incident"].strip():
                parent_id = earliest["parent_incident"]
                parent_incident_obj = earliest
            else:
                parent_id = earliest["number"]
                parent_incident_obj = earliest
        else:
            all_incidents = current_cluster_incidents
            all_incidents_sorted = sorted(all_incidents, key=lambda x: x["opened"] or "")
            earliest = all_incidents_sorted[0]
            parent_id = earliest["number"]
            parent_incident_obj = earliest

        children = []
        for inc in all_incidents_sorted:
            if inc["number"] == parent_incident_obj["number"]:
                continue
            delta_str = ""
            if inc["opened"] and parent_incident_obj["opened"]:
                try:
                    inc_time = datetime.fromisoformat(inc["opened"])
                    parent_time = datetime.fromisoformat(parent_incident_obj["opened"])
                    delta_minutes = int((inc_time - parent_time).total_seconds() / 60)
                    delta_str = f"{delta_minutes} min"
                except Exception:
                    delta_str = "N/A"
            children.append({
                "id": inc["number"],
                "time": inc["opened"],
                "description": inc["short_description"],
                "delta": delta_str,
                "assigned_parent_id": parent_id
            })
        cluster_results.append({
            "pattern": pattern,
            "incident_count": len(all_incidents),
            "has_previous_hour_match": len(prev_matching) > 0,
            "previous_hour_incident_count": len(prev_matching),
            "parent": {
                "id": parent_id,
                "incident_number": parent_incident_obj["number"],
                "time": parent_incident_obj["opened"],
                "description": parent_incident_obj["short_description"],
                "is_inherited_parent": bool(parent_id != parent_incident_obj["number"])
            },
            "children": children
        })

    cluster_results.sort(key=lambda x: x["incident_count"], reverse=True)
    return cluster_results


def build_dynamic_enriched_top_cluster(service_id: int, opened_datetime: datetime, db: Session) -> Optional[dict]:
    from app.models.models import PatternFamily

    clusters = build_clusters(service_id, opened_datetime, db)
    if not clusters:
        return None
    top = clusters[0]
    parent_desc = top["parent"]["description"]

    pattern_family = db.query(PatternFamily).filter(PatternFamily.pattern_name == top["pattern"]).first()

    grammar = "DYNAMIC_PATTERN"
    root_cause_desc = "Cluster detected matching a known pattern family."

    if pattern_family and pattern_family.root_cause_template:
        root_cause_desc = pattern_family.root_cause_template
        pattern_str = pattern_family.pattern_name
        escaped_pattern = re.escape(pattern_str)
        regex_pattern = re.sub(r'<.*?>', r'(.+?)', escaped_pattern)
        match = re.match(regex_pattern + '$', parent_desc, re.IGNORECASE)
        if match:
            groups = match.groups()
            for i, val in enumerate(groups):
                placeholder = f"{{var_{i+1}}}"
                root_cause_desc = root_cause_desc.replace(placeholder, val)

    enriched_children = []
    all_window_incidents = fetch_incidents_for_window(db, service_id, opened_datetime - timedelta(hours=2), opened_datetime)
    incidents_by_id = {inc["number"]: inc for inc in all_window_incidents}

    parent_incident_data = incidents_by_id.get(top["parent"]["incident_number"])
    for child in top["children"]:
        child_inc = incidents_by_id.get(child["id"])
        base_confidence = 0.70
        boosters = []

        if parent_incident_data and child_inc:
            if parent_incident_data.get("service") and child_inc.get("service") == parent_incident_data.get("service"):
                boosters.append("Same Service")
                base_confidence += 0.10
            if parent_incident_data.get("assignment_group") and child_inc.get("assignment_group") == parent_incident_data.get("assignment_group"):
                boosters.append("Same Assignment Group")
                base_confidence += 0.10

        if child["delta"] != "N/A":
            try:
                minutes = int(child["delta"].split()[0])
                if minutes < 15:
                    boosters.append("< 15m proximity")
                    base_confidence += 0.10
            except ValueError:
                pass

        confidence = min(0.99, base_confidence)
        enriched_children.append({
            "id": child["id"],
            "time": child["time"].replace("T", " ") if child["time"] else "",
            "description": child["description"],
            "delta": child["delta"],
            "confidence": round(confidence, 2),
            "boosters": boosters,
            "severity": child_inc.get("severity", "Unknown") if child_inc else "Unknown",
            "service": child_inc.get("service") if child_inc else "Unknown",
            "service_id": child_inc.get("service_id") if child_inc else None
        })

    corr_data = {
        "incident": {
            "id": top["parent"]["id"],
            "root_cause": parent_desc,
            "root_cause_desc": root_cause_desc,
            "raw_alerts_grouped": len(top["children"]),
            "tools_contributing": 1,
            "correlation_confidence_pct": 94,
            "frustrated_user_count": top["incident_count"] * 50
        },
        "parent": {
            "id": top["parent"]["id"],
            "time": top["parent"]["time"].replace("T", " ") if top["parent"]["time"] else "",
            "description": parent_desc,
            "grammar": grammar,
            "extractedJob": "Dynamic Extraction",
            "service": parent_incident_data.get("service") if parent_incident_data else "Unknown",
            "severity": parent_incident_data.get("severity", "Unknown") if parent_incident_data else "Unknown"
        },
        "children": enriched_children
    }
    return corr_data
def build_enriched_top_cluster(subjourney_id: str, opened_datetime: datetime, db: Session) -> Optional[dict]:
    """
    Fetches clusters, takes the top one, and enriches it into the exact JSON format expected by the UI.
    """
    clusters = build_clusters(subjourney_id, opened_datetime, db)
    if not clusters:
        return None

    # Take the top cluster (already sorted by incident_count descending in build_clusters)
    top = clusters[0]
    
    # 1. Extract dynamic entities from parent description
    parent_desc = top["parent"]["description"]
    extracted_job = "Unknown Job"
    
    # Look for 'TRANSACTION [JOB_NAME]' or 'JOB [JOB_NAME]'
    job_match = re.search(r'(?:TRANSACTION|JOB) (\w+)', parent_desc, re.IGNORECASE)
    if job_match:
        extracted_job = job_match.group(1)

    region_match = re.search(r'REGION (\w+)', parent_desc, re.IGNORECASE)
    extracted_region = region_match.group(1) if region_match else "Unknown Region"

    # Define grammar name based on pattern string (naive mapping for UI)
    grammar = "TRANSACTION_ABEND" if "TRANSACTION" in top["pattern"] else "GENERIC_ABEND"
    if "HEALTH SCORE" in top["pattern"]:
        grammar = "HEALTH_SCORE_ALERT"

    # Construct RCA HTML
    if grammar == "TRANSACTION_ABEND":
        root_cause_desc = f"Transaction Abend detected for job <b>{extracted_job}</b> in region <b>{extracted_region}</b>. This matches the known {grammar} pattern family."
    else:
        root_cause_desc = f"Cluster detected matching the known <b>{grammar}</b> pattern family."

    # 2. Enrich children with confidence and boosters
    enriched_children = []
    # Fetch original parent incident to compare attributes
    parent_incident_data = next(
        (inc for inc in fetch_incidents_for_window(db, subjourney_id, opened_datetime - timedelta(hours=2), opened_datetime) 
         if inc["number"] == top["parent"]["incident_number"]), 
        None
    )
    
    # We'll map the raw db objects again for the children to get their full attributes for booster comparison.
    # To do this efficiently, we fetch the full 2 hour window of incidents.
    all_window_incidents = fetch_incidents_for_window(db, subjourney_id, opened_datetime - timedelta(hours=2), opened_datetime)
    incidents_by_id = {inc["number"]: inc for inc in all_window_incidents}

    for child in top["children"]:
        child_inc = incidents_by_id.get(child["id"])
        
        base_confidence = 0.70
        boosters = []
        
        if parent_incident_data and child_inc:
            if parent_incident_data.get("service") and child_inc.get("service") == parent_incident_data.get("service"):
                boosters.append("Same Service")
                base_confidence += 0.10
                
            if parent_incident_data.get("assignment_group") and child_inc.get("assignment_group") == parent_incident_data.get("assignment_group"):
                boosters.append("Same Assignment Group")
                base_confidence += 0.10
        
        # Check delta proximity
        if child["delta"] != "N/A":
            try:
                minutes = int(child["delta"].split()[0])
                if minutes < 15:
                    boosters.append("< 15m proximity")
                    base_confidence += 0.10
            except ValueError:
                pass
                
        # Cap confidence at 0.99
        confidence = min(0.99, base_confidence)
        
        enriched_children.append({
            "id": child["id"],
            "time": child["time"].replace("T", " ") if child["time"] else "",
            "description": child["description"],
            "delta": child["delta"],
            "confidence": round(confidence, 2),
            "boosters": boosters,
            "severity": child_inc.get("severity", "Unknown") if child_inc else "Unknown",
            "service": child_inc.get("service") if child_inc else "Unknown",
            "service_id": child_inc.get("service_id") if child_inc else None
        })

    # Assemble the final enriched JSON
    corr_data = {
        "incident": {
            "id": top["parent"]["id"],
            "root_cause": parent_desc,
            "root_cause_desc": root_cause_desc,
            "raw_alerts_grouped": len(top["children"]),
            "tools_contributing": 1,
            "correlation_confidence_pct": 94,
            "frustrated_user_count": top["incident_count"] * 50  # Mock business impact metric
        },
        "parent": {
            "id": top["parent"]["id"],
            "time": top["parent"]["time"].replace("T", " ") if top["parent"]["time"] else "",
            "description": parent_desc,
            "grammar": grammar,
            "extractedJob": extracted_job,
            "service": parent_incident_data.get("service") if parent_incident_data else "Unknown",
            "severity": parent_incident_data.get("severity", "Unknown") if parent_incident_data else "Unknown"
        },
        "children": enriched_children
    }

    return corr_data

def get_splunk_children(parent_id: str, db: Session) -> List[str]:
    """
    Fetches all child incident IDs natively grouped by Splunk under a given parent_id.
    """
    query = text("""
        SELECT number 
        FROM incidents
        WHERE parent_incident = :parent_id
    """)
    result = db.execute(query, {"parent_id": parent_id})
    return [row[0] for row in result.fetchall()]

from datetime import datetime, timedelta
from typing import List, Dict, Any
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.core.config import settings
from app.models.models import ServiceCorrelationMap

def load_active_service_maps(db: Session) -> Dict[str, Dict[str, Any]]:
    rows = db.query(ServiceCorrelationMap).filter(ServiceCorrelationMap.is_active == True).all()
    maps: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        if r.map_id not in maps:
            maps[r.map_id] = {
                "map_id": r.map_id,
                "map_name": r.map_name,
                "services": {},
                "subjourneys": []
            }
        maps[r.map_id]["services"][r.service_name.strip()] = r.subjourney_id
        if r.subjourney_id and r.subjourney_id not in maps[r.map_id]["subjourneys"]:
            maps[r.map_id]["subjourneys"].append(r.subjourney_id)
    return maps


import json
import re
from datetime import datetime, timedelta
from typing import List, Dict, Any
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.core.config import settings
from app.models.models import ServiceCorrelationMap, Subjourney
from app.services.llm_call import invoke

def get_service_short_name_map(db: Session) -> Dict[str, str]:
    """
    Fetches mapping_name -> short_name from the subjourneys table.
    e.g. {'Benefits - AS': 'BEN', 'Data Entry Benefits System - AS': 'DEBS'}
    """
    rows = db.query(Subjourney).all()
    short_map = {}
    for r in rows:
        if r.mapping_name and r.short_name:
            short_map[r.mapping_name.strip()] = r.short_name.strip()
    return short_map
import json
import re
from datetime import datetime, timedelta
from typing import List, Dict, Any
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.core.config import settings
from app.models.models import SubJourneyServiceMap, ComponentServiceMap
from app.services.llm_call import invoke


def fetch_horizontal_monitoring_incidents(db: Session, window_start: datetime, window_end: datetime) -> List[Dict[str, Any]]:
    """
    Fetch all monitoring incidents within the horizontal window, including configuration_item.
    """
    query_str = """
        SELECT number, opened, short_description, severity, urgency, 
               impact, priority, service, state, parent_incident, service_id, configuration_item
        FROM incidents
        where
           opened >= :start
          AND opened < :end
        ORDER BY opened ASC
    """
    result = db.execute(text(query_str), {"start": window_start, "end": window_end})
    
    incidents = []
    for row in result.fetchall():
        incidents.append({
            "number": row[0],
            "opened": row[1].isoformat() if row[1] else None,
            "short_description": row[2] or "",
            "severity": str(row[3] or "Unknown").strip(),
            "urgency": str(row[4] or "Unknown").strip(),
            "impact": str(row[5] or "Unknown").strip(),
            "priority": str(row[6] or "Unknown").strip(),
            "service": str(row[7]).strip() if row[7] else "Unknown",
            "state": str(row[8] or "Unknown").strip(),
            "parent_incident": row[9],
            "service_id": row[10],
            "configuration_item": str(row[11]).strip() if row[11] else None
        })
    return incidents

import json
import re
from datetime import datetime, timedelta
from typing import List, Dict, Any
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.core.config import settings
from app.models.models import SubJourneyServiceMap, ComponentServiceMap, Component
from app.services.llm_call import invoke


def generate_horizontal_llm_analysis(
    root_inc: Dict[str, Any], 
    all_incs: List[Dict[str, Any]], 
    component_name: str, 
    mapped_services: List[str]
) -> Dict[str, str]:
    """
    Calls OpenAI/Gemini to generate Likely Root Cause, Business Impact, and Correlation Rule Applied,
    explicitly referencing the Component Name and explaining how mapped services were discovered.
    """
    try:
        inc_context = "\n".join([
            f"- [{inc['opened']}] {inc['number']} ({inc['service']}): {inc['short_description']}"
            for inc in all_incs
        ])
        services_str = ", ".join(mapped_services)
        
        prompt = f"""
You are an expert SRE at Canada Life. Synthesize a horizontal cross-service incident correlation analysis.
Root Cause Incident: {root_inc['number']} ({root_inc['service']}) opened at {root_inc['opened']}
Root Cause Configuration Item (Component Name): {component_name}
Mapped Applications discovered from Component Name '{component_name}': {services_str}
Short Description: {root_inc['short_description']}
All Correlated Incidents in Cascade:
{inc_context}

Return ONLY a strict JSON object with exactly these three keys (use HTML formatting like <b>, <code> where helpful):
  "likely_root_cause": "Detailed 2-3 sentence technical explanation of why incident {root_inc['number']} on configuration item '{component_name}' was identified as the root cause. Explicitly mention that we dynamically fetched all applications mapped to component '{component_name}' ({services_str}) to trace this outage.",
  "business_impact": "Detailed 2-3 sentence explanation of how these cascading failures propagated across the mapped  ({services_str}) and impacted end-user operations.",
  "correlation_rule_applied": "Explanation of how the engine used the shared Configuration Item '{component_name}' mapping and same-day arrival window to correlate these {len(all_incs)} incidents across {len(mapped_services)} distinct applications."
"""
        system_prompt = "You are an AI SRE assistant that outputs strict JSON only."
        raw_resp = invoke(prompt, system_prompt=system_prompt)
        
        clean_json = re.sub(r"^```json\s*|\s*```$", "", raw_resp.strip(), flags=re.MULTILINE)
        return json.loads(clean_json)
    except Exception as e:
        print(f"[HORIZONTAL-LLM] Fallback triggered due to error: {e}")
        services_str = ", ".join(mapped_services)
        return {
            "likely_root_cause": f"<b>{root_inc['number']}</b> ({root_inc['short_description']}). Earliest failure occurred on configuration item <b>{component_name}</b>. From component <b>{component_name}</b>, we dynamically fetched all mapped Application Services (<b>{services_str}</b>) and traced the fault propagation.",
            "business_impact": f"Cascading degradation across {len(all_incs)} incidents propagated from <b>{root_inc['service']}</b> into downstream mapped services (<b>{services_str}</b>), delaying member processing and support operations.",
            "correlation_rule_applied": f"<b>Dynamic Component-Service Mapping Rule</b>: Automatically grouped {len(all_incs)} co-occurring incidents within the configured time window across services sharing configuration item <b>{component_name}</b>."
        }


def build_horizontal_map_clusters(opened_datetime: datetime, db: Session) -> List[Dict[str, Any]]:
    """
    Horizontal Correlation Workflow matching by Configuration Item (Component Name):
    1. Fetch all monitoring incidents in the window.
    2. Pick the earliest incident -> get its configuration_item (now treated as Component Name).
    3. Query component_service_map + Component + sub_journey_services to get all mapped service_ids for that component name.
    4. Filter incidents in the window where inc['service_id'] matches any mapped service_id.
    """
    window_minutes = settings.HORIZONTAL_WINDOW_MINUTES
    window_end = opened_datetime
    window_start = opened_datetime - timedelta(minutes=window_minutes)

    # 1. Fetch all monitoring incidents in window
    incidents = fetch_horizontal_monitoring_incidents(db, window_start, window_end)
    if not incidents:
        return []

    # 2. Pick earliest incident chronologically
    sorted_all_incs = sorted(incidents, key=lambda x: x["opened"] or "")
    earliest_inc = sorted_all_incs[0]
    
    # Treat configuration_item as the Component Name
    root_component_name = earliest_inc.get("configuration_item")
    if not root_component_name:
        root_component_name = "UNKNOWN_CI"

    # 3. Query component_service_map joined with Component to discover all services mapped to this component_name
    #    (Filter on Component.component_name OR ComponentServiceMap.component_id as a fallback)
    mapped_rows = (
        db.query(SubJourneyServiceMap)
        .join(ComponentServiceMap, ComponentServiceMap.service_id == SubJourneyServiceMap.id)
        .join(Component, Component.component_id == ComponentServiceMap.component_id)
        .filter(
            (Component.component_name == root_component_name) | 
            (ComponentServiceMap.component_id == root_component_name)
        )
        .all()
    )

    # Collect mapped service IDs, service names, short names, and subjourney IDs
    mapped_service_ids = set()
    mapped_service_names = set()
    short_name_map = {}
    subjourney_ids = set()

    for r in mapped_rows:
        mapped_service_ids.add(r.id)
        svc_name = r.service_name.strip()
        mapped_service_names.add(svc_name)
        
        short_nm = r.short_name.strip() if r.short_name else svc_name[:4].upper()
        short_name_map[r.id] = short_nm
        short_name_map[svc_name] = short_nm
        
        if r.subjourney_id:
            subjourney_ids.add(r.subjourney_id.strip())

    # If no mappings found in DB for this CI, fall back to including at least the earliest incident's service
    if not mapped_service_ids and earliest_inc.get("service_id"):
        mapped_service_ids.add(earliest_inc["service_id"])
        mapped_service_names.add(earliest_inc["service"])
        short_name_map[earliest_inc["service_id"]] = earliest_inc["service"][:4].upper()

    # 4. Filter incidents by service_id or service name
    cluster_incidents = [
        inc for inc in sorted_all_incs 
        if inc.get("service_id") in mapped_service_ids or inc["service"] in mapped_service_names
    ]

    if not cluster_incidents:
        return []

    # 5. Build unique cascade chain ordered by incident arrival
    cascade_chain = []
    for inc in cluster_incidents:
        svc_id = inc.get("service_id")
        svc_name = inc["service"]
        
        short_nm = short_name_map.get(svc_id) or short_name_map.get(svc_name, svc_name[:4].upper())
        inc["short_name"] = short_nm
        
        item = {"service": svc_name, "short_name": short_nm}
        if item not in cascade_chain:
            cascade_chain.append(item)

    # 6. Generate LLM Analysis using component_name instead of component_id
    llm_analysis = generate_horizontal_llm_analysis(
        root_inc=earliest_inc,
        all_incs=cluster_incidents,
        component_name=root_component_name,
        mapped_services=list(mapped_service_names)
    )

    # 7. Construct cluster response matching frontend expectations
    cluster_obj = {
        "map_id": f"MAP-{root_component_name}",
        "map_name": f"Component Ecosystem ({root_component_name})",
        "subjourney_ids": list(subjourney_ids),
        "root_cause": earliest_inc["short_description"],
        "root_incident_number": earliest_inc["number"],
        "root_incident_opened": earliest_inc["opened"],
        "incident_count": len(cluster_incidents),
        "cascade_chain": cascade_chain,
        "incidents": cluster_incidents,
        "llm_analysis": llm_analysis
    }

    return [cluster_obj]
def get_top_horizontal_map_cluster(opened_datetime: datetime, db: Session) -> Dict[str, Any]:
    clusters = build_horizontal_map_clusters(opened_datetime, db)
    return clusters[0] if clusters else {}