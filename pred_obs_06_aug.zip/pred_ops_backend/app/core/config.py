import os
from dotenv import load_dotenv
load_dotenv()
class Settings:
    # ... existing settings ...
    HORIZONTAL_WINDOW_MINUTES: int = int(os.getenv("HORIZONTAL_WINDOW_MINUTES", "115"))
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL   = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    GEMINI_LLM_MODEL   = os.getenv("GEMINI_LLM_MODEL",)
    OPENAI_ENABLED = os.getenv("OPENAI_ENABLED", "false").lower() == "true"

settings = Settings()