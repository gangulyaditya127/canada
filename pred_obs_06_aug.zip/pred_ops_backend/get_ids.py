import urllib.parse
from sqlalchemy import create_engine, text

DB_USER = "postgres"
DB_PASS = urllib.parse.quote_plus("p@ssw0rd")
DB_HOST = "localhost"
DB_PORT = "5433"
DB_NAME = "pops_canada_2"

db_url = f"postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(db_url)

with engine.connect() as conn:
    print("--- Services ---")
    res = conn.execute(text("SELECT id, service_name FROM sub_journey_services"))
    for row in res:
        print(row)
        
    print("\n--- Components ---")
    res = conn.execute(text("SELECT component_id, component_name FROM components"))
    for row in res:
        print(row)
