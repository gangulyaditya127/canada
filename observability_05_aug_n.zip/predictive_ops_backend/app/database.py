import urllib.parse
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Configure the database URL
DB_USER = "postgres"
DB_PASS = urllib.parse.quote_plus("p@ssw0rd")
DB_HOST = "localhost"
DB_PORT = "5433"
DB_NAME = "predictive_ops"

SQLALCHEMY_DATABASE_URL = f"postgresql+psycopg2://postgres:StrongPassword123@10.73.74.37:5432/observability"

engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
