from pydantic import BaseModel, Field
from typing import List, Optional



class ServiceMapOut(BaseModel):
    id: int
    subjourney_id: str
    service_name: str
    short_name: str
    is_primary: Optional[bool] = True
    resp: Optional[int] = 0
    p95: Optional[int] = 0
    errRate: Optional[float] = Field(default=0.0, alias="errRate")
    avail: Optional[float] = 100.0

    class Config:
        from_attributes = True
        populate_by_name = True


class SubjourneyOut(BaseModel):
    id: str
    name: str
    journey_id: str
    mapping_name: Optional[str] = ""
    status: Optional[str] = "ok"
    happy: Optional[int] = 0
    unhappy: Optional[int] = 0
    frustrated: Optional[int] = 0
    alerts: Optional[int] = 0
    
    # Nested list of mapped services from sub_journey_services table
    service_mappings: List[ServiceMapOut] = []

    class Config:
        from_attributes = True
class JourneyOut(BaseModel):
    id: str
    name: str
    
    # DB populated fields
    status: Optional[str] = "ok"
    users: Optional[int] = 0
    happy: Optional[int] = 0
    unhappy: Optional[int] = 0
    frustrated: Optional[int] = 0
    avail: Optional[float] = 100.0
    alerts: Optional[int] = 0
    subJourneysCount: int = 0
    
    class Config:
        from_attributes = True
