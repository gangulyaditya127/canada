import { useState, useEffect, useRef } from 'react';
import { observabilityService } from '../services/observabilityService';

export default function HorizontalCorrelationView({ onBack }) {
  const [cluster, setCluster] = useState(null);
  const [loading, setLoading] = useState(true);

  // --- PLAY / PAUSE / RESET ANIMATION STATE ---
  const [isPlaying, setIsPlaying] = useState(false);
  const [visibleCount, setVisibleCount] = useState(0); // Number of incidents currently shown
  const [speed, setSpeed] = useState(1);              // 1x, 2x, 3x speed
  const timerRef = useRef(null);

  useEffect(() => {
    observabilityService.getHorizontalTopCluster().then((data) => {
      setCluster(data);
      setLoading(false);
      // Automatically display all incidents on initial load (or set to 0 if you want it empty until played)
      if (data && data.incidents) {
        setVisibleCount(data.incidents.length);
      }
    });
  }, []);

  // Handle Play / Pause timer
  useEffect(() => {
    if (!isPlaying) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    const intervalMs = { 1: 1500, 2: 800, 3: 400 }[speed] || 1000;

    timerRef.current = setInterval(() => {
      setVisibleCount((prev) => {
        if (!cluster || prev >= cluster.incidents.length) {
          setIsPlaying(false);
          clearInterval(timerRef.current);
          return prev;
        }
        return prev + 1;
      });
    }, intervalMs);

    return () => clearInterval(timerRef.current);
  }, [isPlaying, speed, cluster]);

  const handlePlayPause = () => {
    if (!isPlaying && cluster && visibleCount >= cluster.incidents.length) {
      // If playing from the end, restart from 1
      setVisibleCount(1);
    }
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setVisibleCount(0);
  };

  const handleShowAll = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
    if (cluster) setVisibleCount(cluster.incidents.length);
  };

  if (loading) return <div className="view" style={{ padding: 40 }}>Loading Horizontal Correlation...</div>;
  if (!cluster) return <div className="view" style={{ padding: 40 }}>No horizontal cluster found for the selected time window.</div>;

  // 1. DYNAMIC TRIANGULAR / SQUARE / POLYGON POSITION GENERATOR
  const numNodes = cluster.cascade_chain.length;
  const nodePositions = cluster.cascade_chain.map((item, idx) => {
    const isRoot = idx === 0;
    let x = 180;
    let y = 180;

    if (numNodes === 2) {
      x = idx === 0 ? 100 : 260;
      y = 180;
    } else if (numNodes === 3) {
      // 3 Services: Triangle (Top -> Bottom Left -> Bottom Right)
      if (idx === 0) { x = 180; y = 70; }
      else if (idx === 1) { x = 80; y = 260; }
      else { x = 280; y = 260; }
    } else if (numNodes === 4) {
      // 4 Services: Diamond / Square (Top -> Right -> Bottom -> Left)
      if (idx === 0) { x = 180; y = 60; }
      else if (idx === 1) { x = 290; y = 170; }
      else if (idx === 2) { x = 180; y = 280; }
      else { x = 70; y = 170; }
    } else {
      const angle = (idx * (360 / numNodes) - 90) * (Math.PI / 180);
      x = 180 + 110 * Math.cos(angle);
      y = 180 + 110 * Math.sin(angle);
    }

    return {
      ...item,
      x,
      y,
      isRoot,
      color: isRoot ? '#c8102e' : idx === 1 ? '#d97706' : '#0f7a4d',
      radius: isRoot ? 34 : 28
    };
  });

  // 2. HELPER TO DRAW ACCURATE EDGES FROM CIRCLE PERIMETER TO CIRCLE PERIMETER
  const getEdgeCoordinates = (n1, n2) => {
    const dx = n2.x - n1.x;
    const dy = n2.y - n1.y;
    const dist = Math.sqrt(dx * dx + dy * dy) || 1;
    const unitX = dx / dist;
    const unitY = dy / dist;

    const startX = n1.x + unitX * (n1.radius + 6);
    const startY = n1.y + unitY * (n1.radius + 6);
    const endX = n2.x - unitX * (n2.radius + 12);
    const endY = n2.y - unitY * (n2.radius + 12);

    return { startX, startY, endX, endY };
  };

  // Determine which incidents and which cascade edges should be visible right now
  const visibleIncidents = cluster.incidents.slice(0, visibleCount);
  const visibleServices = new Set(visibleIncidents.map((inc) => inc.service));

  // Determine how many services in the cascade chain have been reached
  let activeNodeCount = 0;
  for (let i = 0; i < cluster.cascade_chain.length; i++) {
    if (visibleServices.has(cluster.cascade_chain[i].service)) {
      activeNodeCount = i + 1;
    } else {
      break;
    }
  }

  return (
    <div className="view">
      <button className="back-btn" onClick={onBack}>&larr; Go back</button>
      <h1>Cross-Application Outage Cascade</h1>
      <div className="timestamp">
        {/* Map Object: <strong>{cluster.map_name}</strong> &middot; Subjourneys: {cluster.subjourney_ids.join(', ')} */}
        <strong>The single incident that ties the cluster together based on discovered horizontal correlation pattern.</strong>
      </div>

      {/* TOP METRIC RIBBON */}
      <div style={{ display: 'flex', gap: '14px', margin: '16px 0 24px 0', flexWrap: 'wrap' }}>
        <div className="stat-card rc" style={{ padding: '18px 20px', flex: '1', minWidth: '380px' }}>
          <span style={{ background: 'var(--cl-red)', color: '#fff', padding: '4px 10px', borderRadius: '12px', fontSize: '10px', fontWeight: 700, textTransform: 'uppercase', fontFamily: 'var(--disp)' }}>
            Root Cause ({cluster.root_incident_number})
          </span>
          <div style={{ color: 'var(--cl-red-dark)', fontSize: '15px', fontWeight: 600, marginTop: '8px', fontFamily: 'var(--disp)' }}>
            {cluster.root_cause}
          </div>
        </div>

        {/* ROOT CAUSE TIME CARD */}
        <div className="stat-card" style={{ padding: '12px 20px', minWidth: '180px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Root Cause Time</div>
          <div style={{ fontSize: '22px', fontWeight: 700, color: 'var(--cl-red)', fontFamily: 'var(--disp)', marginTop: '4px' }}>
            {cluster.root_incident_opened ? cluster.root_incident_opened.split('T')[1] || cluster.root_incident_opened : 'N/A'}
          </div>
          <div style={{ fontSize: '11px', color: 'var(--text-dim)', marginTop: '2px', fontFamily: 'var(--mono)' }}>
            {cluster.root_incident_opened ? cluster.root_incident_opened.split('T')[0] : ''}
          </div>
        </div>

        {/* TOTAL INCIDENTS CARD */}
        <div className="stat-card" style={{ padding: '12px 20px', minWidth: '160px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Total Incidents</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: 'var(--text)', fontFamily: 'var(--disp)', marginTop: '4px' }}>
            {cluster.incident_count} Grouped
          </div>
        </div>
      </div>

      {/* UNIQUE CASCADE CHAIN (HORIZONTAL RIBBON) */}
      <div className="stat-card" style={{ padding: '16px', marginBottom: '20px' }}>
        <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-dim)', marginBottom: '8px', textTransform: 'uppercase' }}>
          Cascade Chain (Services in sequence):
        </div>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
          {cluster.cascade_chain.map((item, i) => {
            const isReached = i < activeNodeCount;
            return (
              <span key={item.service} style={{ display: 'flex', alignItems: 'center', gap: '8px', opacity: isReached ? 1 : 0.35 }}>
                <span className="sev-pill crit" style={{ background: i === 0 ? 'var(--cl-red)' : i === 1 ? 'var(--amber)' : 'var(--green)', color: '#fff', padding: '6px 12px', fontSize: '12px' }}>
                  {item.short_name} ({item.service})
                </span>
                {i < cluster.cascade_chain.length - 1 && <span style={{ fontWeight: 700, color: 'var(--text-dim)' }}>&rarr;</span>}
              </span>
            );
          })}
        </div>
      </div>

      {/* TWO COLUMN GRID: LEFT TRIANGULAR/SQUARE GRAPH | RIGHT INCIDENTS LIST */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: '20px', marginBottom: '24px' }}>
        
        {/* LEFT SIDE: SVG CASCADE EDGE NAVIGATION WITH PLAY CONTROLS */}
        <div className="stat-card" style={{ padding: '18px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '8px' }}>
            <h3 style={{ margin: 0, fontSize: '13px', color: 'var(--cl-red)', textTransform: 'uppercase' }}>
              Service Cascade Graph ({cluster.cascade_chain.length} Services)
            </h3>

            {/* PLAY / PAUSE / RESET CONTROLS */}
            <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
              <button
                className="cta-btn"
                style={{ padding: '5px 12px', fontSize: '11px' }}
                onClick={handlePlayPause}
              >
                {isPlaying ? '  Pause' : '  Play Cascade'}
              </button>
              <button
                className="cta-btn ghost"
                style={{ padding: '5px 10px', fontSize: '11px' }}
                onClick={handleReset}
              >
                Reset
              </button>
              <button
                className="cta-btn ghost"
                style={{ padding: '5px 10px', fontSize: '11px' }}
                onClick={handleShowAll}
              >
                Show All
              </button>
              {/* SPEED SELECTOR */}
              <select
                value={speed}
                onChange={(e) => setSpeed(Number(e.target.value))}
                style={{ padding: '4px 6px', fontSize: '11px', borderRadius: '4px', border: '1px solid var(--border)', background: '#fff', color: 'var(--text)', cursor: 'pointer' }}
              >
                <option value={1}>1x</option>
                <option value={2}>2x</option>
                <option value={3}>3x</option>
              </select>
            </div>
          </div>

          {/* CHANGED: minHeight increased from '360px' to '440px' for better grid alignment */}
          <div style={{ background: 'var(--panel2)', borderRadius: '8px', border: '1px solid var(--border)', padding: '16px', flex: 1, minHeight: '440px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg viewBox="0 0 360 340" style={{ width: '100%', height: '100%', display: 'block' }}>
              
              {/* SVG MARKER ARROWHEAD DEFINITION */}
              <defs>
                <marker id="cascade-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="var(--cl-red)" />
                </marker>
              </defs>

              {/* DRAW SEQUENCE EDGES (ONLY DRAW IF THAT STEP HAS BEEN REACHED BY PLAY ANIMATION) */}
              {nodePositions.map((node, i) => {
                if (i === 0 || i >= activeNodeCount) return null;
                const prev = nodePositions[i - 1];
                const { startX, startY, endX, endY } = getEdgeCoordinates(prev, node);
                return (
                  <g key={`edge-${i}`}>
                    <line
                      x1={startX}
                      y1={startY}
                      x2={endX}
                      y2={endY}
                      stroke="var(--cl-red)"
                      strokeWidth="2.8"
                      strokeDasharray="6 4"
                      markerEnd="url(#cascade-arrow)"
                      style={{ animation: 'dashMove 0.6s linear infinite' }}
                    />
                    {/* Sequence Number Tag on Edge */}
                    <circle
                      cx={(startX + endX) / 2}
                      cy={(startY + endY) / 2}
                      r="10"
                      fill="#fff"
                      stroke="var(--cl-red)"
                      strokeWidth="1.5"
                    />
                    <text
                      x={(startX + endX) / 2}
                      y={(startY + endY) / 2 + 3}
                      textAnchor="middle"
                      fill="var(--cl-red-dark)"
                      fontSize="10"
                      fontWeight="700"
                    >
                      {i}
                    </text>
                  </g>
                );
              })}

              {/* DRAW SERVICE NODES WITH SHORT NAMES */}
              {nodePositions.map((node, i) => {
                const isReached = i < activeNodeCount;
                return (
                  <g key={node.short_name} style={{ opacity: isReached ? 1 : 0.4, transition: 'opacity 0.4s ease' }}>
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={node.radius}
                      fill={node.isRoot ? 'var(--cl-red-tint)' : '#fff'}
                      stroke={node.color}
                      strokeWidth={node.isRoot ? 3.5 : 2.5}
                      style={{ filter: node.isRoot ? 'drop-shadow(0 0 10px rgba(200, 16, 46, 0.3))' : 'none' }}
                    />
                    <text x={node.x} y={node.y + 5} textAnchor="middle" fill="var(--text)" fontSize="14" fontWeight="700" fontFamily="var(--disp)">
                      {node.short_name}
                    </text>
                    <text x={node.x} y={node.y + 48} textAnchor="middle" fill="var(--text-dim)" fontSize="11" fontFamily="var(--mono)">
                      {node.service}
                    </text>
                    {node.isRoot && (
                      <text x={node.x} y={node.y - 44} textAnchor="middle" fill="var(--cl-red-dark)" fontSize="10" fontWeight="700">
                        ROOT CAUSE
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* RIGHT SIDE: SCROLLABLE INCIDENTS DETAILS (SHOWS VISIBLE INCIDENTS AS THEY CORRELATE) */}
        <div className="stat-card" style={{ padding: '18px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
            <h3 style={{ margin: 0, fontSize: '13px', color: 'var(--cl-red)', textTransform: 'uppercase' }}>
              Incident Details ({visibleCount} / {cluster.incident_count} Shown)
            </h3>
            <span style={{ fontSize: '11px', color: 'var(--text-dim)', fontFamily: 'var(--mono)' }}>
              {isPlaying ? '   Correlating Live...' : 'Paused'}
            </span>
          </div>

          {/* CHANGED: maxHeight increased from '400px' to '520px' to eliminate dead whitespace at the bottom */}
          <div style={{ flex: 1, maxHeight: '520px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '10px', paddingRight: '4px' }}>
            {visibleIncidents.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--text-dim)', fontSize: '13px' }}>
                Click <strong>"  Play Cascade"</strong> above to watch incidents appear and trace the edges across services.
              </div>
            ) : (
              visibleIncidents.map((inc) => {
                const isRoot = inc.number === cluster.root_incident_number;
                return (
                  <div
                    key={inc.number}
                    style={{
                      border: '1px solid var(--border)',
                      borderLeft: isRoot ? '4px solid var(--cl-red)' : '4px solid var(--amber)',
                      borderRadius: '6px',
                      padding: '12px',
                      background: '#fff',
                      animation: 'fadeIn 0.3s ease',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', flexWrap: 'wrap', gap: '6px' }}>
                      <span style={{ fontWeight: 700, color: isRoot ? 'var(--cl-red)' : 'var(--text)', fontSize: '13px' }}>
                        {inc.number} &middot; {inc.opened}
                      </span>
                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                        <span className="kbd" style={{ background: 'var(--panel2)', fontWeight: 'bold' }}>{inc.short_name || inc.service}</span>
                        <span className="kbd">Priority: {inc.priority}</span>
                        <span className="kbd">Severity: {inc.severity}</span>
                      </div>
                    </div>
                    <div style={{ fontSize: '13px', color: 'var(--text)', fontFamily: 'var(--mono)', marginBottom: '8px', lineHeight: 1.4 }}>
                      {inc.short_description}
                    </div>
                    <div style={{ fontSize: '11px', color: 'var(--text-dim)', display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
                      <span><strong>Impact:</strong> {inc.impact}</span>
                      <span><strong>Urgency:</strong> {inc.urgency}</span>
                      <span><strong>State:</strong> {inc.state}</span>
                      {inc.parent_incident && <span><strong>Parent:</strong> {inc.parent_incident}</span>}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* BOTTOM CARD: LLM-GENERATED ROOT CAUSE & CORRELATION RATIONALE */}
      <div className="stat-card rc" style={{ padding: '22px 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
          <span className="exec-badge" style={{ margin: 0 }}>AI SRE Analysis &amp; Correlation Rationale</span>
          <span style={{ fontSize: '11px', color: 'var(--text-dim)', fontFamily: 'var(--mono)' }}>Generated by OpenAI / Gemini LLM</span>
        </div>

        <div style={{ display: 'grid', gap: '14px', fontSize: '13.5px', lineHeight: '1.6' }}>
          <div>
            <b style={{ color: 'var(--cl-red-dark)', display: 'block', marginBottom: '2px' }}>Likely Root Cause:</b>
            <span dangerouslySetInnerHTML={{ __html: cluster.llm_analysis?.likely_root_cause || "Analyzing root cause..." }} />
          </div>
          <div style={{ borderTop: '1px dashed var(--border)', paddingTop: '10px' }}>
            <b style={{ color: 'var(--text)', display: 'block', marginBottom: '2px' }}>Business &amp; Operational Impact:</b>
            <span dangerouslySetInnerHTML={{ __html: cluster.llm_analysis?.business_impact || "Analyzing business impact..." }} />
          </div>
          <div style={{ borderTop: '1px dashed var(--border)', paddingTop: '10px' }}>
            <b style={{ color: 'var(--text)', display: 'block', marginBottom: '2px' }}>Correlation Rule Applied:</b>
            <span dangerouslySetInnerHTML={{ __html: cluster.llm_analysis?.correlation_rule_applied || "Analyzing correlation rules..." }} />
          </div>
        </div>
      </div>
    </div>
  );
}