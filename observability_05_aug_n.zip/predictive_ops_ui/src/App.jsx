import { useEffect, useState } from 'react';
import { observabilityService } from './services/observabilityService';
import { ToastProvider } from './context/ToastContext';
import { ModalProvider } from './context/ModalContext';
import TopBar from './components/TopBar';
import JourneysView from './components/JourneysView';
import StepsView from './components/StepsView';
import CorrelationExecutionView from './components/CorrelationExecutionView';
import RuleDiscoveryView from './components/RuleDiscoveryView';
// Add import at top:
import HorizontalCorrelationView from './components/HorizontalCorrelationView';


const CRUMB_LABELS = {
  journeys: 'Journeys',
  steps: 'Journey',
  correlation: 'Correlation Execution',
};

function AppInner() {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [view, setView] = useState('journeys');
  const [selectedJourney, setSelectedJourney] = useState(null);
  const [selectedStep, setSelectedStep] = useState(null);

  useEffect(() => {
    observabilityService.getAll()
      .then(setData)
      .catch(e => setErr(e.message));
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [view]);

  if (err) return <div style={{ padding: 40 }}>Error: {err}</div>;
  if (!data) return <div style={{ padding: 40 }}>Loading…</div>;

  const { journeys, subJourneys, corrData, rules } = data;

  const nav = (id) => setView(id);

  const openSteps = async (jid) => {
    try {
      const specificSubJourneys = await observabilityService.getSubJourneys(jid);

      if (Object.keys(specificSubJourneys).length === 0) {
        return false;
      }

      setData(prevData => ({
        ...prevData,
        subJourneys: {
          ...prevData.subJourneys,
          ...specificSubJourneys
        }
      }));

      setSelectedJourney(jid);
      setView('steps');
      return true;
    } catch (e) {
      setErr(e.message);
      return false;
    }
  };

  const openCorrelation = async (stepId) => {
    try {
      const scopedCorrData = await observabilityService.getCorrData(stepId);

      setData(prevData => ({
        ...prevData,
        corrData: scopedCorrData,
      }));

      setSelectedStep(stepId);
      setView('correlation');
    } catch (e) {
      setErr(e.message);
    }
  };

  const crumbs = [{ id: 'journeys', label: CRUMB_LABELS.journeys }];
  if (['steps', 'correlation'].includes(view)) {
    crumbs.push({ id: 'steps', label: (selectedJourney && subJourneys[selectedJourney]?.title) || 'Journey' });
  }
  if (['correlation'].includes(view)) {
    crumbs.push({ id: 'correlation', label: CRUMB_LABELS.correlation });
  }

  let subjourneyStepName = '';
  if (selectedJourney && selectedStep) {
    const s = subJourneys[selectedJourney]?.steps.find(x => x.id === selectedStep);
    if (s) subjourneyStepName = s.name;
  }
  const analysisBreadcrumb = selectedJourney && subJourneys[selectedJourney]
    ? `${subJourneys[selectedJourney].title} · ${subjourneyStepName || 'Upload Receipts'}`
    : 'Correlation Execution';

  return (
    <>
      <TopBar crumbs={crumbs} onNav={nav} />
      <div className="main">
        {view === 'journeys' && (
          <JourneysView journeys={journeys} subJourneys={subJourneys} onOpenSteps={openSteps} />
        )}
        {view === 'steps' && (
          <StepsView
            journeyKey={selectedJourney}
            subJourneys={subJourneys}
            onBack={() => nav('journeys')}
            onOpenStep={openCorrelation}
          />
        )}
        {view === 'correlation' && (
          <CorrelationExecutionView
            corrData={corrData}
            breadcrumb={analysisBreadcrumb}
            onBack={() => nav('steps')}
          />
        )}
        {/* // Inside AppInner() return statement, replace or add view handler: */}
          {view === 'horizontal-correlation' && (
            <HorizontalCorrelationView onBack={() => nav('journeys')} />
          )}
      </div>
      <footer>© Canada Life · Agentic Incident Correlation Prototype</footer>
    </>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <ModalProvider>
        <AppInner />
      </ModalProvider>
    </ToastProvider>
  );
}