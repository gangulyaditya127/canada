file_path = r'c:\Users\MrAditya\Downloads\pred_obs_08_aug\pred_obs_ui\src\components\HorizontalCorrelationView.jsx'
with open(file_path, 'r', encoding='utf-8') as f:
    for i, line in enumerate(f):
        if 'const handleNodeClick' in line:
            start = i
            break
    f.seek(0)
    lines = f.readlines()
    print("".join(lines[start:start+15]))
