import { useState, useEffect, useRef } from 'react';
import VerticalCorrelation from './VerticalCorrelation';
import { useModal } from '../context/ModalContext';
import { useToast } from '../context/ToastContext';
import { observabilityService } from '../services/observabilityService';

export default function HorizontalCorrelationView({ cluster, drilldownData, createdTickets = {}, onTicketCreated }) {
  const { openModal, closeModal } = useModal();
  const { showToast } = useToast();

  // --- PLAY / PAUSE / RESET ANIMATION STATE ---
  const [isPlaying, setIsPlaying] = useState(false);
  const [visibleCount, setVisibleCount] = useState(0); // Number of alerts currently shown
  const [speed, setSpeed] = useState(1);              // 1x, 2x, 3x speed
  const timerRef = useRef(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [localDrilldownData, setLocalDrilldownData] = useState(null);
  const [isLoadingDrilldown, setIsLoadingDrilldown] = useState(false);

  // --- SERVICENOW TICKET STATE ---
  const [isCreatingTicket, setIsCreatingTicket] = useState(false);
  const [createdTicketNumber, setCreatedTicketNumber] = useState(null);
  const [createdTicketUrl, setCreatedTicketUrl] = useState(null);

  // Use unique ID for this specific cluster
  const rootCauseId = cluster?.root_incident_number || cluster?.parent?.incident_number || cluster?.root_cause || 'HORIZONTAL_CLUSTER';

  // STRICT CHECK: Only show ticket badge if created for THIS specific rootCauseId
  const existingTicket = createdTickets[rootCauseId] || 
                         (createdTicketNumber ? { ticketNumber: createdTicketNumber, url: createdTicketUrl } : null);

  // Initialize visibility when cluster is provided
  useEffect(() => {
    if (cluster && cluster.incidents) {
      setVisibleCount(cluster.incidents.length);
    }
  }, [cluster]);

  // Handle Play / Pause timer
  useEffect(() => {
    if (!isPlaying) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    const intervalMs = { 1: 1500, 2: 800, 3: 400 }[speed] || 1000;
    timerRef.current = setInterval(() => {
      setVisibleCount((prev) => {
        if (!cluster || prev >= cluster.incidents.length) {
          setIsPlaying(false);
          clearInterval(timerRef.current);
          return prev;
        }
        return prev + 1;
      });
    }, intervalMs);
    return () => clearInterval(timerRef.current);
  }, [isPlaying, speed, cluster]);

  const handlePlayPause = () => {
    if (!isPlaying && cluster && visibleCount >= cluster.incidents.length) {
      setVisibleCount(1);
    }
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setVisibleCount(0);
  };

  const handleShowAll = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
    if (cluster) setVisibleCount(cluster.incidents.length);
  };

  const handleNodeClick = (nodeName) => {
    if (selectedNode === nodeName) {
      setSelectedNode(null);
    } else {
      setSelectedNode(nodeName);
      if (nodeName === 'BEN' && cluster && cluster.incidents) {
        setIsLoadingDrilldown(true);
        
        const benNode = (cluster.cascade_chain || []).find(n => n.short_name === 'BEN');
        const benServiceName = benNode ? benNode.service : 'Benefit-AS';
        
        const matchedIncs = cluster.incidents.filter(inc => 
          inc.short_name === 'BEN' || 
          inc.service === benServiceName
        );
        
        matchedIncs.sort((a, b) => new Date(a.opened || 0) - new Date(b.opened || 0));
        
        if (matchedIncs.length > 0) {
          const parentInc = matchedIncs[0];
          const parentTimeStr = parentInc.opened || "";
          let parentTimeObj = null;
          if (parentTimeStr) {
            parentTimeObj = new Date(parentTimeStr);
          }
          
          const children = [];
          for (let i = 1; i < matchedIncs.length; i++) {
            const inc = matchedIncs[i];
            let deltaStr = "N/A";
            let baseConfidence = 0.80;
            const boosters = ["Same Component Name"];
            
            if (inc.opened && parentTimeObj) {
              const childTime = new Date(inc.opened);
              const diffMins = Math.floor((childTime - parentTimeObj) / 60000);
              deltaStr = `${diffMins} min`;
              if (diffMins < 15) {
                boosters.push("< 15m proximity");
                baseConfidence += 0.10;
              }
            }
            
            if (inc.service && parentInc.service === inc.service) {
              boosters.push("Same Service");
              baseConfidence += 0.10;
            }
            
            const confidence = Math.min(0.99, baseConfidence);
            
            children.push({
              id: inc.number,
              time: inc.opened ? inc.opened.replace("T", " ") : "",
              description: inc.short_description,
              delta: deltaStr,
              confidence: Number(confidence.toFixed(2)),
              boosters: boosters,
              severity: inc.severity || "Unknown",
              service: inc.service || "Unknown",
              service_id: inc.service_id
            });
          }
          
          const rootCauseDesc = `Identified a direct correlation of ${matchedIncs.length} alerts for the CICS component derived from the horizontal cluster. The initial failure was observed on ${parentTimeStr.replace("T", " ")}.`;
          
          const localData = {
            incident: {
              id: parentInc.number,
              root_cause: parentInc.short_description,
              root_cause_desc: rootCauseDesc,
              raw_alerts_grouped: matchedIncs.length,
              tools_contributing: 1,
              correlation_confidence_pct: 98,
              frustrated_user_count: matchedIncs.length * 50
            },
            parent: {
              id: parentInc.number,
              time: parentTimeStr.replace("T", " "),
              description: parentInc.short_description,
              grammar: "Component Match",
              extractedJob: "CICS",
              service: parentInc.service || "Unknown",
              severity: parentInc.severity || "Unknown"
            },
            children: children
          };
          
          setLocalDrilldownData(localData);
        } else {
          setLocalDrilldownData(null);
        }
        setIsLoadingDrilldown(false);
      }
    }
  };

  // --- HANDLER FOR CREATE SERVICENOW TICKET ---
  const handleCreateServiceNowTicket = async () => {
    if (!cluster) return;
    
    // Sort incidents by time
    const sortedIncidents = [...(cluster.incidents || [])].sort((a, b) => new Date(a.opened || 0) - new Date(b.opened || 0));
    const alerts = sortedIncidents.map(inc => ({
      number: inc.number,
      short_description: inc.short_description || "",
      opened: inc.opened ? inc.opened.replace('T', ' ') : "",
      service: inc.service || ""
    }));
    
    // Only pass actual children (exclude the root cause incident itself)
    const childIds = sortedIncidents.map(inc => inc.number).filter(id => id !== rootCauseId);

    setIsCreatingTicket(true);
    try {
      const res = await observabilityService.createServiceNowTicketHorizontal(rootCauseId, alerts);
      
      if (!res.success || res.error) {
        showToast(`<b>Error:</b> ${res.error || 'Failed to create ServiceNow ticket.'}`);
        return;
      }

      const snNum = res.servicenow_ticket_number;
      const snUrl = res.servicenow_url || `https://tataconsultancyservicesdemo5.service-now.com/now/nav/ui/classic/params/target/incident.do%3Fsys_id%3D${res.sys_id}`;
      
      setCreatedTicketNumber(snNum);
      setCreatedTicketUrl(snUrl);
      if (onTicketCreated) {
        onTicketCreated(rootCauseId, snNum, snUrl);
      }

      openModal({
        title: 'ServiceNow Ticket Created Successfully',
        id: `Ticket Number: ${snNum}`,
        body: (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{
              background: 'var(--green-tint)',
              border: '1px solid var(--green)',
              borderLeft: '4px solid var(--green)',
              padding: '14px',
              borderRadius: '6px',
              color: 'var(--text-main)',
              fontSize: '13.5px'
            }}>
              <strong>ServiceNow Incident {snNum}</strong> created for root cause alert <strong>{rootCauseId}</strong>. All the remaining <strong>{childIds.length}</strong> alert(s) has been stamped as child to <strong>{rootCauseId}</strong>.
            </div>

            <table className="aa-table" style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
              <tbody>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Created SN Ticket</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)' }}>
                    <a 
                      href={snUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      style={{ 
                        color: 'var(--green-dark)', 
                        textDecoration: 'underline',
                        cursor: 'pointer'
                      }}
                      title="Click to open this Incident in ServiceNow in a new tab"
                    >
                      {snNum} ↗
                    </a>
                  </td>
                </tr>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Root Cause Alert</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)', color: 'var(--status-critical)' }}>{rootCauseId}</td>
                </tr>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Children Stamped</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)' }}>{childIds.length} alerts</td>
                </tr>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Application</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)' }}>{res.cmdb_ci || 'Benefit - AS'}</td>
                </tr>
                <tr>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Assignment Group</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)' }}>{res.assignment_group || 'ARE_TEAM'}</td>
                </tr>
              </tbody>
            </table>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '10px' }}>
              <button
                className="cta-btn"
                style={{ padding: '8px 18px', fontSize: '12px', background: 'var(--green)', borderColor: 'var(--green)' }}
                onClick={() => closeModal()}
              >
                Close &amp; Continue
              </button>
            </div>
          </div>
        )
      });

      showToast(`<b>ServiceNow Ticket Created:</b> <b>${snNum}</b> linked to root cause alert <b>${rootCauseId}</b>.`);
    } catch (e) {
      console.error(e);
      showToast(`<b>Error:</b> ${e.message || 'Could not create ServiceNow ticket.'}`);
    } finally {
      setIsCreatingTicket(false);
    }
  };

  if (!cluster) return <div style={{ padding: 40 }}>No horizontal cluster found for the selected time window.</div>;

  // 1. CALCULATE ALERT COUNTS PER SERVICE FOR CIRCLE DISPLAY
  const serviceCounts = {};
  (cluster.incidents || []).forEach((inc) => {
    const key = inc.short_name || inc.service;
    serviceCounts[key] = (serviceCounts[key] || 0) + 1;
  });

  // 2. DYNAMIC TRIANGULAR / SQUARE / POLYGON POSITION GENERATOR
  const numNodes = cluster.cascade_chain.length;
  const nodePositions = cluster.cascade_chain.map((item, idx) => {
    const isRoot = idx === 0;
    let x = 180;
    let y = 180;
    if (numNodes === 2) {
      x = idx === 0 ? 100 : 260;
      y = 180;
    } else if (numNodes === 3) {
      if (idx === 0) { x = 180; y = 70; }
      else if (idx === 1) { x = 80; y = 260; }
      else { x = 280; y = 260; }
    } else if (numNodes === 4) {
      if (idx === 0) { x = 180; y = 60; }
      else if (idx === 1) { x = 290; y = 170; }
      else if (idx === 2) { x = 180; y = 280; }
      else { x = 70; y = 170; }
    } else {
      const angle = (idx * (360 / numNodes) - 90) * (Math.PI / 180);
      x = 180 + 110 * Math.cos(angle);
      y = 180 + 110 * Math.sin(angle);
    }
      let color = '#d97706';
      if (isRoot) {
        color = '#c8102e';
      } else if (item.short_name === 'ECL' || (item.service && item.service.toLowerCase().includes('eclaims'))) {
        color = '#2563eb'; // Blue for eclaims
      } else if (item.short_name === 'DEBS' || (item.service && item.service.toLowerCase().includes('data entry'))) {
        color = '#d97706'; // Amber for debs
      }
      
      return {
        ...item,
        x,
        y,
        isRoot,
        color: color,
        radius: isRoot ? 38 : 32
      };
  });

  // 3. MAP SERVICE NAMES TO NODE COLORS FOR ALERT CARDS
  const serviceColorMap = {};
  nodePositions.forEach((node) => {
    serviceColorMap[node.short_name] = node.color;
    serviceColorMap[node.service] = node.color;
  });

  const getEdgeCoordinates = (n1, n2) => {
    const dx = n2.x - n1.x;
    const dy = n2.y - n1.y;
    const dist = Math.sqrt(dx * dx + dy * dy) || 1;
    const unitX = dx / dist;
    const unitY = dy / dist;
    const startX = n1.x + unitX * (n1.radius + 6);
    const startY = n1.y + unitY * (n1.radius + 6);
    const endX = n2.x - unitX * (n2.radius + 12);
    const endY = n2.y - unitY * (n2.radius + 12);
    return { startX, startY, endX, endY };
  };

  const visibleIncidents = cluster.incidents.slice(0, visibleCount);
  const visibleServices = new Set(visibleIncidents.map((inc) => inc.service));
  let activeNodeCount = 0;
  for (let i = 0; i < cluster.cascade_chain.length; i++) {
    if (visibleServices.has(cluster.cascade_chain[i].service)) {
      activeNodeCount = i + 1;
    } else {
      break;
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      
      {/* RIGHT-ALIGNED TOP ACTION BAR: SHOWS TICKET BADGE OR CREATE BUTTON */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '12px' }}>
        {existingTicket ? (
          <span style={{
            background: 'var(--green-tint)',
            color: 'var(--green-dark)',
            border: '1px solid var(--green)',
            padding: '6px 12px',
            borderRadius: '20px',
            fontSize: '12px',
            fontWeight: 700,
            fontFamily: 'var(--mono)'
          }}>
            ✓ Ticket Created: {' '}
            <a 
              href={existingTicket.url} 
              target="_blank" 
              rel="noopener noreferrer"
              style={{ color: 'var(--green-dark)', textDecoration: 'underline' }}
            >
              {existingTicket.ticketNumber} ↗
            </a>
          </span>
        ) : (
          <button
            className="cta-btn"
            disabled={isCreatingTicket}
            onClick={handleCreateServiceNowTicket}
            style={{
              padding: '8px 18px',
              fontSize: '12px',
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              background: isCreatingTicket ? 'var(--text-muted)' : 'var(--cl-red)',
              borderColor: isCreatingTicket ? 'var(--text-muted)' : 'var(--cl-red)',
              cursor: isCreatingTicket ? 'wait' : 'pointer',
              boxShadow: 'var(--shadow-sm)'
            }}
          >
            <span>{isCreatingTicket ? '⏳' : '🚀'}</span>
            {isCreatingTicket ? 'Creating Ticket...' : 'Create ServiceNow Ticket'}
          </button>
        )}
      </div>

      {/* TOP METRIC RIBBON */}
      <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
        <div className="stat-card rc" style={{ padding: '18px 20px', flex: '1', minWidth: '380px' }}>
          <span style={{ background: 'var(--status-critical)', color: '#fff', padding: '4px 10px', borderRadius: '12px', fontSize: '10px', fontWeight: 700, textTransform: 'uppercase', fontFamily: 'var(--disp)' }}>
            Root Cause ({cluster.root_incident_number})
          </span>
          <div style={{ color: '#991b1b', fontSize: '15px', fontWeight: 600, marginTop: '8px', fontFamily: 'var(--disp)' }}>
            {cluster.root_cause}
          </div>
        </div>

        {/* TOTAL ALERTS CARD */}
        <div className="stat-card" style={{ padding: '12px 20px', minWidth: '160px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase' }}>Total Alerts</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: 'var(--text)', fontFamily: 'var(--disp)', marginTop: '4px' }}>
            {cluster.incident_count} Grouped
          </div>
        </div>
      </div>

      {/* TWO COLUMN GRID: LEFT CASCADE GRAPH | RIGHT ALERTS LIST */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: '20px', marginBottom: '4px' }}>
        
        {/* LEFT SIDE: SVG CASCADE */}
        <div className="stat-card" style={{ padding: '18px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '8px' }}>
            <h3 style={{ margin: 0, fontSize: '13px', color: 'var(--status-critical)', textTransform: 'uppercase' }}>
              Application Cascade Graph ({cluster.cascade_chain.length} Applications)
            </h3>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Click nodes to explore vertical clusters</div>
          </div>
          <div style={{ display: 'flex', gap: '6px', alignItems: 'center', marginBottom: '10px' }}>
              <button
                className="cta-btn"
                style={{ padding: '5px 12px', fontSize: '11px' }}
                onClick={handlePlayPause}
              >
                {isPlaying ? '  Pause' : '  Play Cascade'}
              </button>
              <button
                className="cta-btn ghost"
                style={{ padding: '5px 10px', fontSize: '11px' }}
                onClick={handleReset}
              >
                Reset
              </button>
              <button
                className="cta-btn ghost"
                style={{ padding: '5px 10px', fontSize: '11px' }}
                onClick={handleShowAll}
              >
                Show All
              </button>
              <select
                value={speed}
                onChange={(e) => setSpeed(Number(e.target.value))}
                style={{ padding: '4px 6px', fontSize: '11px', borderRadius: '4px', border: '1px solid var(--border)', background: '#fff', color: 'var(--text)', cursor: 'pointer' }}
              >
                <option value={1}>1x</option>
                <option value={2}>2x</option>
                <option value={3}>3x</option>
              </select>
          </div>
          <div style={{ background: 'var(--bg-panel)', borderRadius: '8px', border: '1px solid var(--border)', padding: '16px', flex: 1, minHeight: '440px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg viewBox="0 0 360 340" style={{ width: '100%', height: '100%', display: 'block' }}>
              <defs>
                <marker id="cascade-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="var(--status-critical)" />
                </marker>
              </defs>
              {nodePositions.map((node, i) => {
                if (i === 0 || i >= activeNodeCount) return null;
                const prev = nodePositions[i - 1];
                const { startX, startY, endX, endY } = getEdgeCoordinates(prev, node);
                return (
                  <g key={`edge-${i}`}>
                    <line x1={startX} y1={startY} x2={endX} y2={endY} stroke="var(--status-critical)" strokeWidth="2.8" strokeDasharray="6 4" markerEnd="url(#cascade-arrow)" style={{ animation: 'dashMove 0.6s linear infinite' }} />
                    <circle cx={(startX + endX) / 2} cy={(startY + endY) / 2} r="10" fill="#fff" stroke="var(--status-critical)" strokeWidth="1.5" />
                    <text x={(startX + endX) / 2} y={(startY + endY) / 2 + 3} textAnchor="middle" fill="#991b1b" fontSize="10" fontWeight="700">
                      {i}
                    </text>
                  </g>
                );
              })}
              {nodePositions.map((node, i) => {
                const isReached = i < activeNodeCount;
                const isSelected = selectedNode === node.short_name;
                const count = serviceCounts[node.short_name] || serviceCounts[node.service] || 0;
                
                return (
                  <g 
                    key={node.short_name} 
                    onClick={() => handleNodeClick(node.short_name)}
                    style={{ opacity: isReached ? 1 : 0.4, transition: 'all 0.4s ease', cursor: 'pointer' }}
                  >
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={node.radius}
                      fill={node.isRoot ? 'var(--status-critical-bg)' : '#fff'}
                      stroke={isSelected ? '#2563eb' : node.color}
                      strokeWidth={isSelected ? 4 : (node.isRoot ? 3.5 : 2.5)}
                      style={{ filter: node.isRoot ? 'drop-shadow(0 0 10px rgba(200, 16, 46, 0.3))' : 'none' }}
                    />
                    <text x={node.x} y={node.y - 3} textAnchor="middle" fill={isSelected ? '#2563eb' : 'var(--text)'} fontSize="13" fontWeight="700" fontFamily="var(--disp)">
                      {node.short_name}
                    </text>
                    <text x={node.x} y={node.y + 14} textAnchor="middle" fill={isSelected ? '#1d4ed8' : node.color} fontSize="11" fontWeight="700" fontFamily="var(--mono)">
                      ({count})
                    </text>
                    <text x={node.x} y={node.y + 52} textAnchor="middle" fill="var(--text-muted)" fontSize="11" fontFamily="var(--mono)">
                      {node.service}
                    </text>
                    {node.isRoot && (
                      <text x={node.x} y={node.y - 48} textAnchor="middle" fill="#991b1b" fontSize="10" fontWeight="700">
                        ROOT CAUSE
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* RIGHT SIDE: SCROLLABLE ALERTS DETAILS */}
        <div className="stat-card" style={{ padding: '18px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
            <h3 style={{ margin: 0, fontSize: '13px', color: 'var(--status-critical)', textTransform: 'uppercase' }}>
              Alert Details ({visibleCount} / {cluster.incident_count} Shown)
            </h3>
            <span style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--mono)' }}>
              {isPlaying ? '   Correlating Live...' : 'Paused'}
            </span>
          </div>
          <div style={{ flex: 1, maxHeight: '520px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '10px', paddingRight: '4px' }}>
            {visibleIncidents.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--text-muted)', fontSize: '13px' }}>
                Click <strong>"  Play Cascade"</strong> above to watch alerts appear and trace the edges across services.
              </div>
            ) : (
              visibleIncidents.map((inc) => {
                const isHighlighted = selectedNode === inc.short_name;
                const serviceColor = serviceColorMap[inc.short_name] || serviceColorMap[inc.service] || '#64748b';
                return (
                  <div
                    key={inc.number}
                    style={{
                      border: '1px solid var(--border)',
                      borderLeft: `5px solid ${serviceColor}`,
                      borderRadius: '6px',
                      padding: '12px',
                      background: isHighlighted ? '#eff6ff' : '#fff',
                      animation: 'fadeIn 0.3s ease',
                      transition: 'all 0.2s ease'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', flexWrap: 'wrap', gap: '6px' }}>
                      <span style={{ fontWeight: 700, color: serviceColor, fontSize: '13px' }}>
                        {inc.number} &middot; {inc.opened ? inc.opened.replace('T', ' ') : ''}
                      </span>
                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                        <span 
                          className="kbd" 
                          style={{ 
                            background: isHighlighted ? '#bfdbfe' : 'var(--bg-panel)', 
                            color: isHighlighted ? '#1e3a8a' : serviceColor, 
                            fontWeight: 'bold',
                            border: `1px solid ${serviceColor}40`
                          }}
                        >
                          {inc.short_name || inc.service}
                        </span>
                        <span className="kbd">Priority: {inc.priority}</span>
                        <span className="kbd">Severity: {inc.severity}</span>
                      </div>
                    </div>
                    <div style={{ fontSize: '13px', color: 'var(--text)', fontFamily: 'var(--mono)', marginBottom: '8px', lineHeight: 1.4 }}>
                      {inc.short_description}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Conditionally Render Vertical Correlation for BEN */}
      {selectedNode === 'BEN' && (
        <div style={{ marginTop: '4px', padding: '1.5rem', background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '12px' }}>
          <h3 style={{ color: '#1e40af', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ background: '#3b82f6', color: 'white', padding: '2px 8px', borderRadius: '12px', fontSize: '0.75rem', fontWeight: 'bold' }}>DRILLDOWN</span>
            Vertical Correlation for {selectedNode}
          </h3>
          {isLoadingDrilldown ? (
            <div style={{ padding: '20px', textAlign: 'center', color: '#1e40af' }}>Loading correlation data...</div>
          ) : localDrilldownData ? (
            <VerticalCorrelation 
              corrData={localDrilldownData} 
              isEvent2={true}
              createdTickets={createdTickets}
              onTicketCreated={onTicketCreated}
            />
          ) : (
            <div style={{ padding: '20px', textAlign: 'center', color: '#1e40af' }}>No additional correlation data found.</div>
          )}
        </div>
      )}

      {/* BOTTOM CARD: LLM-GENERATED ROOT CAUSE & CORRELATION RATIONALE */}
      <div className="stat-card rc" style={{ padding: '22px 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
          <span className="exec-badge" style={{ margin: 0 }}>AI SRE Analysis &amp; Correlation Rationale</span>
          {/* <span style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--mono)' }}>Generated by OpenAI / Gemini LLM</span> */}
        </div>
        <div style={{ display: 'grid', gap: '14px', fontSize: '13.5px', lineHeight: '1.6' }}>
          <div>
            <b style={{ color: '#991b1b', display: 'block', marginBottom: '2px' }}>Root Cause:</b>
            <span dangerouslySetInnerHTML={{ __html: cluster.llm_analysis?.likely_root_cause || "Analyzing root cause..." }} />
          </div>
          <div style={{ borderTop: '1px dashed var(--border)', paddingTop: '10px' }}>
            <b style={{ color: 'var(--text)', display: 'block', marginBottom: '2px' }}>Business &amp; Operational Impact:</b>
            <span dangerouslySetInnerHTML={{ __html: cluster.llm_analysis?.business_impact || "Analyzing business impact..." }} />
          </div>
          <div style={{ borderTop: '1px dashed var(--border)', paddingTop: '10px' }}>
            <b style={{ color: 'var(--text)', display: 'block', marginBottom: '2px' }}>Correlation Rule Applied:</b>
            <span dangerouslySetInnerHTML={{ __html: cluster.llm_analysis?.correlation_rule_applied || "Analyzing correlation rules..." }} />
          </div>
        </div>
      </div>

      {/* --- BACK TO TOP BUTTON RIGHT AFTER HORIZONTAL VIEW --- */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'flex-end', 
        alignItems: 'center', 
        marginTop: '8px', 
        paddingTop: '6px', 
        borderTop: '1px dashed var(--border)' 
      }}>
        <button
          className="back-btn"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          style={{
            fontSize: '12px',
            fontWeight: 600,
            color: 'var(--cl-red)',
            cursor: 'pointer',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px'
          }}
        >
          <span>↑</span> Back to Top
        </button>
      </div>
      {/* ------------------------------------------------------ */}
    </div>
  );
}