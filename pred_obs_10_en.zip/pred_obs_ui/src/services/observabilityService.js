import { journeys as mockJourneys, subJourneys as mockSubJourneys, correlationCluster, ruleDiscoveryData } from '../data/mockData';

// const API_BASE = 'http://localhost:8000/api';

// After:
const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api';
// --- ADD THIS UTILITY FUNCTION AT THE TOP ---
function shiftTimeToNow(clusterData, isHorizontal = false) {
  if (!clusterData) return clusterData;
  const now = new Date();
  
  if (isHorizontal) {
    if (!clusterData.incidents || clusterData.incidents.length === 0) return clusterData;
    
    // Find the oldest alert in the cascade (root cause)
    const sortedIncs = [...clusterData.incidents].sort((a, b) => new Date(a.opened) - new Date(b.opened));
    const oldestTime = new Date(sortedIncs[0].opened);
    
    // Calculate the difference between NOW and the oldest alert (minus 15 mins to make it look recent)
    const timeDiffMs = now.getTime() - oldestTime.getTime() - (15 * 60 * 1000);
    
    // Shift the root incident opened time
    if (clusterData.root_incident_opened) {
      clusterData.root_incident_opened = new Date(new Date(clusterData.root_incident_opened).getTime() + timeDiffMs)
        .toISOString().replace('T', ' ').substring(0, 19);
    }
    
    // Shift every child alert
    clusterData.incidents = clusterData.incidents.map(inc => {
      const shiftedDate = new Date(new Date(inc.opened).getTime() + timeDiffMs);
      return {
        ...inc,
        opened: shiftedDate.toISOString().replace('T', ' ').substring(0, 19)
      };
    });

  } else {
    // Vertical Correlation Shift
    if (!clusterData.parent || !clusterData.parent.time) return clusterData;
    
    // Parse parent time. Can be "2026-08-06 14:10:22" or "15-06-2025 10:20:15 AM"
    let pTimeStr = clusterData.parent.time.replace(/-/g, '/'); // simple safety
    const parentTime = new Date(clusterData.parent.time);
    
    if (isNaN(parentTime)) return clusterData; // Fallback if parsing fails

    const timeDiffMs = now.getTime() - parentTime.getTime() - (15 * 60 * 1000);

    // Formatter to match "YYYY-MM-DD HH:mm:ss"
    const formatShifted = (dateStr) => {
      const d = new Date(new Date(dateStr).getTime() + timeDiffMs);
      return d.toISOString().replace('T', ' ').substring(0, 19);
    };

    clusterData.parent.time = formatShifted(clusterData.parent.time);
    
    if (clusterData.children) {
      clusterData.children = clusterData.children.map(c => ({
        ...c,
        time: c.time ? formatShifted(c.time) : c.time
      }));
    }
  }
  
  return clusterData;
}
export const observabilityService = {
  getAll: async () => {
    try {
      const res = await fetch(`${API_BASE}/journeys`);
      if (!res.ok) throw new Error("Failed to fetch journeys");
      const fetchedJourneys = await res.json();
      return {
        journeys: fetchedJourneys,
        subJourneys: mockSubJourneys,
        corrData: correlationCluster,
        rules: ruleDiscoveryData
      };
    } catch (e) {
      console.error("API failed, falling back to mock data", e);
      return {
        journeys: mockJourneys,
        subJourneys: mockSubJourneys,
        corrData: correlationCluster,
        rules: ruleDiscoveryData
      };
    }
  },
  getSubJourneys: async (jid) => {
    try {
      const res = await fetch(`${API_BASE}/journeys/${jid}/subjourneys`);
      if (!res.ok) throw new Error("Failed to fetch subjourneys");
      const fetchedSubJourneys = await res.json();
      
      const journeyRes = await fetch(`${API_BASE}/journeys`);
      const allJourneys = await journeyRes.json();
      const parentJourney = allJourneys.find(j => j.id === jid) || { name: 'Journey' };
      
      return {
        [jid]: {
          title: parentJourney.name,
          steps: fetchedSubJourneys.map(s => ({
            id: s.id,
            name: s.name,
            status: s.status,
            hu: [s.happy || 0, s.unhappy || 0, s.frustrated || 0],
            critical: s.status === 'warning' || s.status === 'critical',
            // --- Map nested services from backend table ---
            services: (s.service_mappings || []).map(svc => ({
              id: svc.id,
              name: svc.service_name,
              shortName: svc.short_name,
              avg: svc.resp || 0,
              p95: svc.p95 || 0,
              err: svc.errRate || 0,
              avail: svc.avail || 100.0,
              openAlerts: svc.open_alerts !== undefined ? svc.open_alerts : null,
              components: (svc.component_mappings || []).map(cm => cm.component.component_name).join(', ')
            }))
          }))
        }
      };
    } catch (e) {
      console.error("API failed, falling back to mock data", e);
      return { [jid]: mockSubJourneys[jid] };
    }
  },

  getCorrData: async (serviceId, openedDatetime) => {
    try {
      // 1. Fetch Vertical Correlation Cluster by service_id
      const timeParam = openedDatetime || '2026-06-15T12:00:00';
      // Ensure svcParam is an integer to avoid FastAPI 422 validation errors.
      // If serviceId is a string like "s3" from the step ID, we default to 12.
      let svcParam = parseInt(serviceId, 10);
      if (isNaN(svcParam)) {
        svcParam = 12;
      }
      
      const res = await fetch(`${API_BASE}/correlation/top_cluster?service_id=${svcParam}&opened_datetime=${timeParam}`);
      
      if (!res.ok) {
        if (res.status === 404) return null;
        console.warn('API error fetching correlation, falling back to mock.', res.statusText);
        return correlationCluster;
      }
      const data = await res.json();
      
      if (data.error) {
        console.warn('Backend returned error:', data.error);
        // return correlationCluster;
        return null
      }

      // 2. RESTORED: Fetch Splunk children to flag missed incidents
      try {
        const splunkRes = await fetch(`${API_BASE}/correlation/splunk_children?parent_id=${encodeURIComponent(data.parent.id)}`);
        if (splunkRes.ok) {
          const splunkChildrenIds = await splunkRes.json();
          if (data.children && Array.isArray(data.children)) {
            data.children = data.children.map(c => ({
              ...c,
              missedBySplunk: !splunkChildrenIds.includes(c.id)
            }));
          }
        }
      } catch (splunkErr) {
        console.error('Failed to fetch splunk children:', splunkErr);
      }

      return data;
    } catch (e) {
      console.error("API failed for getCorrData, falling back to mock data", e);
      return correlationCluster;
    }
  },
  getCicsVerticalCorrData: async (serviceId, componentName, openedDatetime) => {
    try {
      const timeParam = openedDatetime || '2026-06-15T12:00:00';
      const compName = componentName || 'CICS';
      let svcParam = parseInt(serviceId, 10);
      if (isNaN(svcParam)) {
        svcParam = 12;
      }
      
      const res = await fetch(`${API_BASE}/correlation/cics_vertical_cluster?service_id=${svcParam}&component_name=${compName}&opened_datetime=${timeParam}`);
      
      if (!res.ok) {
        if (res.status === 404) return null;
        console.warn('API error fetching cics vertical correlation, falling back to null.', res.statusText);
        return null;
      }
      const data = await res.json();
      
      if (data.error) {
        return null;
      }
      
      return data;
    } catch (e) {
      console.error("API failed for getCicsVerticalCorrData", e);
      return null;
    }
  },
  getRules: async () => {
    return ruleDiscoveryData;
  },
  minePatterns: async () => { return true; },
  listPatterns: async () => { return []; },
  synthesizePattern: async () => { return {}; },
  listProposals: async () => { return []; },
  approveProposal: async () => { return true; },
  rejectProposal: async () => { return true; },
  getHorizontalTopCluster: async () => {
    try {
      const res = await fetch(`${API_BASE}/correlation/horizontal_top_cluster?opened_datetime=2026-08-09T09:50:12`);
      if (!res.ok) throw new Error("Failed to fetch horizontal top cluster");
      const data = await res.json();
      if (data.error) return null;
      return data.top_cluster;
    } catch (e) {
      console.error("API failed for getHorizontalTopCluster", e);
      return null;
    }
  },
  createServiceNowTicket: async (incidentId, llmDescription = null, childAlertIds = []) => {
    try {
      const params = new URLSearchParams({ incident_id: incidentId });
      if (llmDescription) {
        params.append('llm_description', llmDescription);
      }
      if (childAlertIds && childAlertIds.length > 0) {
        childAlertIds.forEach(id => params.append('child_alert_ids', id));
      }

      const res = await fetch(`${API_BASE}/correlation/create_servicenow_ticket?${params.toString()}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!res.ok) throw new Error(`Failed to create ServiceNow ticket: ${res.status}`);
      return await res.json();
    } catch (e) {
      console.error("API failed for createServiceNowTicket:", e);
      return {
        success: false,
        error: e.message || "Failed to create ServiceNow ticket."
      };
    }
  },
  createServiceNowTicketHorizontal: async (rootIncidentId, alerts) => {
    try {
      const payload = {
        incident_id: rootIncidentId,
        alerts: alerts
      };
      
      const res = await fetch(`${API_BASE}/correlation/create_servicenow_ticket_horizontal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error(`Failed to create horizontal ServiceNow ticket: ${res.status}`);
      return await res.json();
    } catch (e) {
      console.error("API failed for createServiceNowTicketHorizontal:", e);
      return {
        success: false,
        error: e.message || "Failed to create horizontal ServiceNow ticket."
      };
    }
  },
};