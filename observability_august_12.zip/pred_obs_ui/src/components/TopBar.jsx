import React from 'react';

export default function TopBar({ crumbs, onNav }) {
  return (
    <div className="topbar">
      <div className="brand">
        {/* <div className="brand-mark">CL</div> */}
        <div>
          {/* <div className="brand-name">Canada Life</div> */}
          <div className="brand-sub">ARE · Observability</div>
        </div>
      </div>
      <div className="crumbs">
        {crumbs.map((c, i) => (
          <React.Fragment key={c.id}>
            <button
              className={'c' + (i === crumbs.length - 1 ? ' active' : '')}
              onClick={() => onNav(c.id)}
            >
              {c.label}
            </button>
            {i < crumbs.length - 1 && <span className="sep">/</span>}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}