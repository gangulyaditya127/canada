import React, { useState } from "react";
import VerticalCorrelation from "./VerticalCorrelation";
import HorizontalCorrelationView from "./HorizontalCorrelationView";
import { useModal } from "../context/ModalContext";

export default function CorrelationExecutionView({
  corrData,
  horizontalData,
  verticalData2,
  services,
  breadcrumb,
  onBack
}) {
  const { openModal } = useModal();

  // Tracks created ServiceNow tickets by parent ID -> { ticketNumber, url }
  const [createdTickets, setCreatedTickets] = useState({});

  const handleTicketCreated = (parentId, ticketNumber, url) => {
    setCreatedTickets(prev => ({
      ...prev,
      [parentId]: { ticketNumber, url }
    }));
  };

  // Safely extract Journey Name and Subjourney Name regardless of separator (' ', '-', '>', or spaces)
 // Correctly split on separators (" - ", " > ", em-dashes, or 2+ spaces), NOT single spaces between words
  // Split on middle dots (·, •), hyphens (-), arrows (>), or 2+ spaces
  const parts = breadcrumb 
    ? breadcrumb.split(/\s*[\u00B7\u2022\u2219\->]\s*|\s{2,}/).map(s => s.trim()).filter(Boolean) 
    : [];
    
  const journeyName = parts[0] || 'Health and Dental Claims';
  const subjourneyName = parts.length > 1 ? parts[parts.length - 1] : 'Claim Adjudication';

  // --- METRIC CALCULATIONS FOR TOP-RIGHT SUMMARY TABLE ---
  const verticalTotal = (corrData?.parent ? 1 : 0) + (corrData?.children?.length || 0);
  const horizontalTotal = horizontalData?.incidents?.length || 0;
  const totalIncidentsCorrelated = verticalTotal + horizontalTotal;
  const verticalMissed = (corrData?.children || []).filter(c => c.missedBySplunk).length;
  // All horizontal alerts except the 1 root cause are counted as missed by Splunk
  const horizontalMissed = Math.max(0, horizontalTotal - 1);
  const splunkMissed = verticalMissed + horizontalMissed;
  const splunkMapped = Math.max(0, totalIncidentsCorrelated - splunkMissed);

  // Opens a popup modal displaying all alerts associated with the clicked service
  const handleOpenServiceModal = (svc, incidents) => {
    openModal({
      title: `${svc.name} ${svc.shortName ? `(${svc.shortName})` : ''}   Associated Alerts`,
      id: `${incidents.length} Alert(s) Found`,
      body: (
        <div>
          {incidents.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)', fontSize: '0.95rem' }}>
              No alerts recorded for this service in the selected time window.
            </div>
          ) : (
            <table className="aa-table" style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={{ padding: '12px 10px', textAlign: 'left', borderBottom: '1px solid var(--border)' }}>Number</th>
                  <th style={{ padding: '12px 10px', textAlign: 'left', borderBottom: '1px solid var(--border)' }}>Short Description</th>
                  <th style={{ padding: '12px 10px', textAlign: 'left', borderBottom: '1px solid var(--border)' }}>Severity</th>
                </tr>
              </thead>
              <tbody>
                {incidents.map((inc, idx) => {
                  const num = inc.number || inc.id || inc.incident_number || 'N/A';
                  const desc = inc.short_description || inc.description || inc.root_cause || 'No description available';
                  const sev = inc.severity || 'Unknown';
                  return (
                    <tr key={`${num}-${idx}`} style={{ borderBottom: '1px solid var(--border)' }}>
                      <td style={{ padding: '12px 10px', fontWeight: 700, fontFamily: 'var(--mono)', color: 'var(--cl-red)' }}>
                        {num}
                      </td>
                      <td style={{ padding: '12px 10px', fontSize: '12.5px', lineHeight: 1.4, maxWidth: '500px' }}>
                        {desc}
                      </td>
                      <td style={{ padding: '12px 10px' }}>
                        <span className="badge" style={{ background: 'var(--panel2)', border: '1px solid var(--border)', fontWeight: 600 }}>
                          {sev}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      )
    });
  };

  return (
    <div className="view main-content">
      {/* TOP HEADER BLOCK WITH RIGHT-ALIGNED SUMMARY TABLE */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        gap: '20px',
        marginBottom: '2rem'
      }}>
        {/* LEFT COLUMN: BACK BUTTON & TITLES */}
        <div style={{ flex: '1', minWidth: '340px' }}>
          <button className="back-btn" onClick={onBack} style={{ marginBottom: '1rem' }}>
            &larr; Go back
          </button>
          <div style={{ color: 'var(--status-critical)', fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '0.5rem' }}>
            {journeyName} - SUBJOURNEY - {subjourneyName}
          </div>
          <h1 className="page-title" style={{ fontSize: '1.75rem', fontWeight: 700, color: 'var(--text-main)', margin: '0 0 0.25rem 0' }}>
            Event Correlation Across Applications
          </h1>
          <p className="page-subtitle" style={{ margin: 0, fontStyle: 'italic' }}>
            Accelerating automated alert clustering and AI-driven root cause analysis
          </p>
        </div>

        {/* RIGHT COLUMN: CORRELATION EFFICIENCY SUMMARY TABLE */}
        <div style={{
          background: '#fff',
          border: '1px solid var(--border)',
          borderRadius: '8px',
          boxShadow: 'var(--shadow-sm)',
          overflow: 'hidden',
          minWidth: '330px'
        }}>
          <div style={{
            background: 'var(--panel2)',
            padding: '10px 14px',
            borderBottom: '1px solid var(--border)',
            fontFamily: 'var(--disp)',
            fontSize: '11px',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
            color: 'var(--text-dim)'
          }}>
            Correlation Efficiency Summary
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
            <tbody>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                <td style={{ padding: '10px 14px', color: 'var(--text-main)', fontWeight: 600 }}>
                  Total Clustered Alerts
                </td>
                <td style={{ padding: '10px 14px', textAlign: 'right', fontWeight: 800, fontFamily: 'var(--mono)', fontSize: '15px', color: 'var(--text-main)' }}>
                  {totalIncidentsCorrelated}
                </td>
              </tr>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                <td style={{ padding: '10px 14px', color: 'var(--text-main)', fontWeight: 600 }}>
                  <span style={{ display: 'inline-block', width: '8px', height: '8px', borderRadius: '50%', background: 'var(--status-ok)', marginRight: '8px' }}></span>
                  Correlated(Splunk)
                </td>
                <td style={{ padding: '10px 14px', textAlign: 'right', fontWeight: 700, fontFamily: 'var(--mono)', color: 'var(--status-ok)' }}>
                  {splunkMapped-1}
                </td>
              </tr>
              <tr>
                <td style={{ padding: '10px 14px', color: 'var(--text-main)', fontWeight: 600 }}>
                  <span style={{ display: 'inline-block', width: '8px', height: '8px', borderRadius: '50%', background: 'var(--status-critical)', marginRight: '8px' }}></span>
                  Not Correlated
                </td>
                <td style={{ padding: '10px 14px', textAlign: 'right', fontWeight: 700, fontFamily: 'var(--mono)', color: 'var(--status-critical)' }}>
                  {splunkMissed+1}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* AI ALERT SUMMARY */}
      <div style={{ marginBottom: '1rem' }}>
        <p style={{ fontSize: '1.05rem', color: 'var(--text-main)', fontWeight: 500, margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '1.25rem' }}> </span>
          The analysis engine has detected <strong>2 correlated alert clusters</strong> occurring across the {subjourneyName} application stack.
        </p>
      </div>

      {/* SWAPPED SECTION JUMP LINKS: CICS PERF FIRST, BATCH FAILURE SECOND */}
      <div className="section-jump">
        <a href="#event-1" className="sj" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
          CICS Perf Alert Cluster
        </a>
        <a href="#event-2" className="sj" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
          Batch Failure Alert Cluster
        </a>
      </div>

      {/* APPLICATIONS ROW (Box Views) */}
      <section className="analysis-section" style={{ marginTop: '24px' }}>
        <div className="sec-head">
          <div className="sec-step" style={{ padding: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
          </div>
          <div>
            <h2 className="sec-title">Applications</h2>
            <p className="sec-sub">Monitoring application health and alert counts across the subjourney stack. Click any card to inspect its alerts.</p>
          </div>
        </div>
        <div className="grid-4">
          {(services || []).map(svc => {
            let components = svc.components || 'N/A';
            let incCount = 0;
            let crit = 0;
            let high = 0;
            const talliedIds = new Set();
            const matchedIncidents = [];
            const tally = (incObj) => {
              if (!incObj) return;
              const incId = incObj.id || incObj.number || incObj.incident_number;
              if (!incId || talliedIds.has(incId)) return;
              talliedIds.add(incId);
              matchedIncidents.push(incObj);
              incCount++;
              if (typeof incObj.severity === 'string') {
                const s = incObj.severity.toLowerCase().trim();
                if (s.includes('crit')) {
                  crit++;
                } else if (s.includes('high') || s.includes('warn') || s.includes('med')) {
                  high++;
                }
              }
            };
            const isMatch = (inc) => (inc.service === svc.name || inc.service_id === svc.id);
            // Event 1 (corrData)
            if (corrData) {
              if (corrData.parent && isMatch(corrData.parent)) tally(corrData.parent);
              if (corrData.children) {
                corrData.children.forEach(c => {
                  if (isMatch(c)) tally(c);
                });
              }
            }
            // Event 2 (horizontalData)
            if (horizontalData && horizontalData.incidents) {
              horizontalData.incidents.forEach(inc => {
                if (isMatch(inc)) tally(inc);
              });
            }
            // Removed Event 2 drilldown (verticalData2) tallying because drilldown is derived locally
            let status = 'ok';
            if (crit > 0) status = 'critical';
            else if (high > 0) status = 'warning';
            
            const borderTopColor = status === 'critical' ? 'var(--status-critical)' : (status === 'warning' ? 'var(--status-warning)' : 'var(--status-ok)');
            return (
              <div
                key={svc.id}
                className="card"
                onClick={() => handleOpenServiceModal(svc, matchedIncidents)}
                style={{
                  borderTop: `4px solid ${borderTopColor}`,
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  display: 'grid',
                  gridTemplateRows: 'auto 1fr auto',
                  minHeight: '210px',
                  padding: '1rem 1.15rem'
                }}
                title="Click to view all associated alerts"
              >
                <div 
                  className="card-header" 
                  style={{ 
                    alignItems: 'flex-start',
                    margin: '0 0 0.5rem 0'
                  }}
                >
                  <span style={{ lineHeight: '1.25', paddingRight: '8px', fontSize: '0.92rem', fontWeight: 700 }}>
                    {svc.name} {svc.shortName ? `(${svc.shortName})` : ''}
                  </span>
                  <span className={`badge ${status}`} style={{ flexShrink: 0 }}>
                    {status.toUpperCase()}
                  </span>
                </div>
                <div 
                  style={{ 
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    padding: '0.5rem 0', 
                    borderBottom: '1px dashed var(--border-color)',
                    marginBottom: '0.75rem'
                  }}
                >
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, letterSpacing: '0.05em' }}>
                    Alert Count
                  </div>
                  <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-main)', lineHeight: 1.05, marginTop: '2px' }}>
                    {incCount}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>
                    Components Associated
                  </div>
                  <div style={{ fontSize: '0.82rem', fontWeight: 600, color: 'var(--text-main)', marginTop: '3px', wordBreak: 'break-word', lineHeight: '1.3' }}>
                    {components}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* SWAPPED EVENTS ROW: HORIZONTAL FIRST, VERTICAL SECOND */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', marginTop: '2rem' }}>
        
        {/* EVENT 1: HORIZONTAL CORRELATION (CICS PERF ALERT CLUSTER) */}
        <section id="event-1" className="analysis-section">
          <div className="sec-head">
            <div className="sec-step" style={{ padding: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
            </div>
            <div>
              <h2 className="sec-title">CICS Perf Alert Cluster</h2>
              <p className="sec-sub">The system has identified a major event cascading across multiple applications in this subjourney.</p>
            </div>
          </div>
          <HorizontalCorrelationView 
            cluster={horizontalData} 
            drilldownData={verticalData2}
            createdTickets={createdTickets}
            onTicketCreated={handleTicketCreated}
          />
        </section>

        {/* EVENT 2: VERTICAL CORRELATION (BATCH FAILURE ALERT CLUSTER) */}
        <section id="event-2" className="analysis-section">
          <div className="sec-head">
            <div className="sec-step" style={{ padding: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
            </div>
            <div>
              <h2 className="sec-title">Batch Failure Alert Cluster</h2>
              <p className="sec-sub">The system has identified a cluster of related alerts affecting a specific application layer.</p>
            </div>
          </div>
          <VerticalCorrelation 
            corrData={corrData} 
            createdTickets={createdTickets}
            onTicketCreated={handleTicketCreated}
          />
        </section>
      </div>
    </div>
  );
}