import React from 'react';
// Import the new full brand image directly from the same folder
import tcsBrandImage from './TCS_Application_Reliability_Engineering_Black_1.png';

export default function TopBar({ crumbs, onNav }) {
  return (
    <div className="topbar">
      <div className="brand" style={{ display: 'flex', alignItems: 'center' }}>
        
        {/* Use the new single image that contains both the logo and the text */}
        <img 
          src={tcsBrandImage} 
          alt="TCS Application Reliability Engineering" 
          style={{ height: '38px', objectFit: 'contain' }} 
        />

      </div>
      <div className="crumbs">
        {crumbs.map((c, i) => (
          <React.Fragment key={c.id}>
            <button
              className={'c' + (i === crumbs.length - 1 ? ' active' : '')}
              onClick={() => onNav(c.id)}
              style={i === crumbs.length - 1 ? { color: '#000000' } : {}} 
            >
              {c.label}
            </button>
            {i < crumbs.length - 1 && <span className="sep">/</span>}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}