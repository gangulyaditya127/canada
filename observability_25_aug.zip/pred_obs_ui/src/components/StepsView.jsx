import React from 'react';
import { nowLong } from '../utils/time';

export default function StepsView({ journeyKey, subJourneys, onBack, onOpenStep, isJvmResolved }) {
  const j = subJourneys[journeyKey];
  if (!j) return null;

  const getAvailColor = (avail, isCritical) => {
    if (isCritical || avail < 80) return 'var(--cl-red)';
    if (avail >= 95) return 'var(--green)';
    return 'var(--amber)';
  };

  return (
    <div className="view">
      <button className="back-btn" onClick={onBack}>&larr; Go back</button>
      <div className="eyebrow">Journey Execution Experience</div>
      <h1>{j.title}</h1>
      <div className="timestamp">{nowLong()}</div>
      <div className="sub-hint">
        Click on sub-journey name to inspect its incident for event correlation.
      </div>
      <div className="table-panel">
        <table className="j-table" style={{ borderCollapse: 'collapse', width: '100%' }}>
          <thead>
            <tr>
              <th style={{ width: '22%' }}>Sub-journey</th>
              <th className="n" style={{ width: '18%', textAlign: 'center' }}>Happy + Unhappy + Frustrated</th>
              <th style={{ width: '24%' }}>Applications</th>
              <th className="n" style={{ width: '10%' }}>Average Resp time</th>
              <th className="n" style={{ width: '8%' }}>P(95)</th>
              <th className="n" style={{ width: '8%' }}>Error Rate</th>
              <th className="n" style={{ width: '10%' }}>Availability</th>
              <th className="n" style={{ width: '10%' }}>Open Alerts</th>
            </tr>
          </thead>
          <tbody>
            {j.steps.map((step, stepIdx) => {
              const services = step.services && step.services.length > 0 ? step.services : [{ id: step.id, name: step.api || 'REST API', shortName: '', avg: step.avg || 0, p95: step.p95 || 0, err: step.err || 0, avail: step.avail || 100.0 }];
              const rowSpanCount = services.length;
              
              // Determine if step is critical based on remaining alerts/errors
              const isStepCritical = step.critical || services.some(s => {
                  let alerts = s.openAlerts != null ? s.openAlerts : 0;
                  if (isJvmResolved) {
                      if (s.shortName === 'BEN' || s.name.includes('Benefits')) alerts = Math.max(0, alerts - 3);
                      // FIXED: Subtract 1 for DEBS (4 - 1 = 3)
                      if (s.shortName === 'DEBS') alerts = Math.max(0, alerts - 1);
                      if (s.shortName === 'eClaims' || s.name.includes('eClaims')) alerts = Math.max(0, alerts - 1);
                  }
                  return alerts > 0 || s.err >= 5 || s.avail < 80;
              });

              return services.map((svc, svcIdx) => {
                let isSvcCritical = svc.err >= 5 || svc.avail < 80;
                let displayAvail = Number(svc.avail);
                let errRateDisplay = svc.err;
                let avgDisplay = svc.avg;
                let p95Display = svc.p95;

                // --- RESOLUTION LOGIC ---
                let currentAlerts = svc.openAlerts != null ? svc.openAlerts : 0;
                
                if (isJvmResolved) {
                   if (svc.shortName === 'BEN' ) {
                       currentAlerts = Math.max(0, currentAlerts - 3);
                   } else if (svc.shortName === 'DEBS') {
                       // FIXED: Subtract 1 for DEBS (4 - 1 = 3)
                       currentAlerts = Math.max(0, currentAlerts - 1); 
                   } else if (svc.shortName === 'eClaims' || svc.name.includes('eClaims')) {
                       currentAlerts = Math.max(0, currentAlerts - 1); 
                   }
                }
                
                let openAlertsDisplay = currentAlerts > 0 ? currentAlerts : '-';

                // If there are still alerts (like the 19, 3, and 4), the service stays critical (Red text)
                if (currentAlerts > 0) {
                    isSvcCritical = true;
                }

                // Hardcoded demo degradation (if not resolved yet)
                if (!isJvmResolved && (svc.name === 'Data Entry Benefits System - AS' || svc.shortName === 'DEBS' || svc.name === 'eClaims - AS' || svc.shortName === 'eClaims')) {
                  displayAvail = 95.0;
                  isSvcCritical = true;
                }

                // Force healthy performance numbers for DEBS, eClaims, and Benefits if JVM is resolved.
                if (isJvmResolved && (svc.shortName === 'DEBS' || svc.shortName === 'eClaims' || svc.shortName === 'BEN' || svc.name.includes('Benefits'))) {
                   displayAvail = 99.9;
                   errRateDisplay = 0.1;
                   avgDisplay = 120;
                   p95Display = 200;
                } 

                const rowTextColor = isSvcCritical ? 'var(--cl-red)' : 'inherit';

                return (
                  <tr key={`${step.id}-${svc.id || svcIdx}`} style={{ borderTop: svcIdx === 0 ? '1px solid var(--border)' : '1px solid rgba(230, 213, 213, 0.4)' }}>
                    {svcIdx === 0 && (
                      <>
                        <td
                          rowSpan={rowSpanCount}
                          onClick={() => onOpenStep(step.id)}
                          style={{
                            verticalAlign: 'middle', borderRight: '1px solid var(--border)', fontWeight: 700, fontFamily: 'var(--disp)',
                            fontSize: '14px', color: isStepCritical ? 'var(--cl-red)' : 'var(--text)', padding: '16px 18px', cursor: 'pointer', transition: 'all 0.15s ease'
                          }}
                          onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--cl-red-tint)'; e.currentTarget.style.textDecoration = 'underline'; }}
                          onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; e.currentTarget.style.textDecoration = 'none'; }}
                        >
                          {step.name}
                        </td>
                        <td rowSpan={rowSpanCount} style={{ verticalAlign: 'middle', borderRight: '1px solid var(--border)', textAlign: 'center', padding: '16px 14px' }}>
                          {step.hu ? (
                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '12px', fontFamily: 'var(--disp)', fontWeight: 700, fontSize: '14px' }}>
                              <span style={{ color: 'var(--green)' }}>{step.hu[0]}%</span>
                              <span style={{ color: 'var(--amber)' }}>{step.hu[1]}%</span>
                              <span style={{ color: 'var(--cl-red)' }}>{step.hu[2]}%</span>
                            </div>
                          ) : <span style={{ color: 'var(--text-dimmer)' }}> </span>}
                        </td>
                      </>
                    )}
                    <td style={{ padding: '12px 18px' }}>
                      <span style={{ fontWeight: isSvcCritical ? 700 : 600, color: rowTextColor, fontFamily: 'var(--disp)', fontSize: '13.5px' }}>
                        {svc.name} {svc.shortName ? `(${svc.shortName})` : ''}
                      </span>
                    </td>
                    <td className="num-cell" style={{ color: rowTextColor, fontWeight: isSvcCritical ? 700 : 400, padding: '12px 18px' }}>
                      {avgDisplay} ms
                    </td>
                    <td className="num-cell" style={{ color: rowTextColor, fontWeight: isSvcCritical ? 700 : 400, padding: '12px 18px' }}>
                      {p95Display} ms
                    </td>
                    <td className="num-cell" style={{ color: errRateDisplay >= 5 ? 'var(--cl-red)' : 'inherit', fontWeight: errRateDisplay >= 5 ? 700 : 400, padding: '12px 18px' }}>
                      {errRateDisplay} %
                    </td>
                    <td className="num-cell" style={{ color: getAvailColor(displayAvail, isSvcCritical), fontWeight: 700, padding: '12px 18px' }}>
                      {displayAvail.toFixed(2)} %
                    </td>
                    <td className="num-cell" style={{ color: currentAlerts > 0 ? 'var(--cl-red)' : 'inherit', fontWeight: currentAlerts > 0 ? 700 : 400, padding: '12px 18px' }}>
                      {openAlertsDisplay}
                    </td>
                  </tr>
                );
              });
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}