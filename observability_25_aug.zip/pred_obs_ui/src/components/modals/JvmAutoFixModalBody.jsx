import React, { useEffect, useState } from 'react';

const AGENT_STEPS = [
    { target: 'CDCPVCISMART-02', action: 'Run jvm_autofix.sh (Capture heap dump & restart JVM).', metric: 'Memory cleared 99% → 12%' },
    { target: 'LoadBalancer', action: 'Drain traffic from degraded node.', metric: 'Active connections → 0' },
    { target: 'AutoScaler', action: 'Provision replacement node.', metric: 'Capacity restored' }
];

const LOG_STREAM = [
    "[engine] 5 alerts received across 3 tool sources in the last 15m window.",
    "[engine] Mapping each alert onto component dependency graph...",
    "[heal] Self-Healing Agent engaged - runbook jvm-oom-recovery.v2 selected.",
    "[heal] Executing on CDCPVCISMART-02: Triggering /opt/scripts/jvm_autofix.sh to capture heap dump at /var/log/jvm/heapdump.hprof & restart JVM",
    "[heal] Executing on LoadBalancer: Drain traffic from degraded node",
    "[heal] Executing on AutoScaler: Provision replacement node",
    "[heal] Post-heal probes: AppDynamics · Splunk · Dynatrace -> all green.",
    "[heal] Incident INC-JVM-001 auto-resolved. No human intervention required."
];

export default function JvmAutoFixModalBody({ onComplete }) {
    const [logs, setLogs] = useState([]);
    const [activeStepIdx, setActiveStepIdx] = useState(-1);
    const [isFixing, setIsFixing] = useState(true);
    const [highlightIndex, setHighlightIndex] = useState(-1);

    useEffect(() => {
        let isMounted = true;
        LOG_STREAM.forEach((log, index) => {
            setTimeout(() => {
                if (!isMounted) return;
                setLogs(prev => [...prev, log]);
                
                if (log.includes('Executing on CDCPVCISMART-02')) { 
                    setActiveStepIdx(0); 
                    setHighlightIndex(index); 
                }
                else if (log.includes('Executing on LoadBalancer')) { 
                    setActiveStepIdx(1); 
                    setHighlightIndex(index); 
                }
                else if (log.includes('Executing on AutoScaler')) { 
                    setActiveStepIdx(2); 
                    setHighlightIndex(index); 
                }
                else if (log.includes('Post-heal probes')) { 
                    setActiveStepIdx(3); 
                    setHighlightIndex(-1); 
                }
                
                if (index === LOG_STREAM.length - 1) {
                    setIsFixing(false);
                    // Trigger the resolution instantly so it updates behind the modal
                    if (onComplete) onComplete();
                }
            }, index * 800);
        });
        return () => { isMounted = false; };
    }, [onComplete]);

    return (
        <div style={{ display: 'flex', gap: '24px', flexWrap: 'wrap', fontFamily: 'var(--mono, monospace)', position: 'relative' }}>
            {/* Left Panel: Self Healing Agent */}
            <div style={{ flex: '1', minWidth: '280px', border: '1px solid #10b981', borderRadius: '8px', padding: '16px', background: '#f8fafc', position: 'relative', overflow: 'hidden', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)' }}>
                <div style={{ position: 'absolute', top: 0, left: 0, bottom: 0, width: '4px', background: '#10b981' }}></div>
                
                <h3 style={{ color: '#0f766e', marginTop: 0, marginBottom: '4px', fontSize: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span>Self-Healing Agent</span>
                    <span style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#10b981', display: 'inline-block', opacity: isFixing ? 1 : 0.6, animation: isFixing ? 'pulse 1.5s infinite' : 'none' }}></span>
                </h3>
                <div style={{ fontSize: '11px', color: '#64748b', marginBottom: '20px' }}>runbook: jvm-oom-recovery.v2 | <b>script: /opt/scripts/jvm_autofix.sh</b></div>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    {AGENT_STEPS.map((step, i) => {
                        const isDone = activeStepIdx > i;
                        const isActive = activeStepIdx === i;
                        const opacity = (isActive || isDone) ? 1 : 0.4;
                        
                        return (
                            <div key={i} style={{ display: 'flex', gap: '12px', opacity, transition: 'opacity 0.3s' }}>
                                <div style={{ 
                                    width: '20px', height: '20px', borderRadius: '50%', 
                                    background: isDone ? '#10b981' : '#cbd5e1', 
                                    color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', flexShrink: 0
                                }}>
                                    {isDone ? '✓' : ''}
                                </div>
                                <div style={{ fontSize: '12.5px', color: '#334155', lineHeight: '1.4' }}>
                                    <span style={{ fontWeight: 700, color: '#0f172a' }}>{step.target}</span> &rarr; {step.action}
                                    {isDone && <div style={{ color: '#64748b', fontSize: '11px', marginTop: '2px' }}>{step.metric}</div>}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Right Panel: Agentic Reasoning Stream */}
            <div style={{ flex: '1.5', minWidth: '320px', border: '1px solid #fca5a5', borderRadius: '8px', padding: '16px', background: '#fff', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)' }}>
                <h3 style={{ color: '#c8102e', marginTop: 0, marginBottom: '16px', fontSize: '14px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 700 }}>
                    Agentic Reasoning Stream
                </h3>
                
                <div style={{ fontSize: '12px', lineHeight: '1.6', color: '#475569', height: '300px', overflowY: 'auto' }}>
                    {logs.map((log, i) => {
                        let prefixColor = '#c8102e';
                        if (log.startsWith('[heal]')) prefixColor = '#0f766e';
                        
                        const prefixMatch = log.match(/^\[.*?\]/);
                        const prefix = prefixMatch ? prefixMatch[0] : '';
                        const text = log.replace(prefix, '').trim();
                        const isHighlighted = highlightIndex === i;

                        return (
                            <div key={i} style={{ marginBottom: '10px' }}>
                                <strong style={{ color: prefixColor, marginRight: '8px' }}>{prefix}</strong>
                                <span style={{ 
                                    background: isHighlighted ? '#3b82f6' : 'transparent', 
                                    color: isHighlighted ? '#fff' : 'inherit',
                                    padding: isHighlighted ? '2px 4px' : '0',
                                    borderRadius: '2px'
                                }} dangerouslySetInnerHTML={{ __html: text.replace(/(AppServer|Benefits-AS|DEBS|eClaims|LoadBalancer|AutoScaler|INC-JVM-001)/g, '<b>$1</b>') }} />
                            </div>
                        );
                    })}
                    {isFixing && <div style={{ display: 'inline-block', width: '8px', height: '14px', background: '#cbd5e1', animation: 'blink 1s infinite' }}></div>}
                </div>
            </div>
            
            <style>{`
                @keyframes pulse { 0% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.5); opacity: 0.5; } 100% { transform: scale(1); opacity: 1; } }
                @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
            `}</style>
        </div>
    );
}