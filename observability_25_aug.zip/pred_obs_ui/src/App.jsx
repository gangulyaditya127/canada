import { useEffect, useState } from 'react';
import { observabilityService } from './services/observabilityService';
import { ToastProvider } from './context/ToastContext';
import { ModalProvider } from './context/ModalContext';
import TopBar from './components/TopBar';
import JourneysView from './components/JourneysView';
import StepsView from './components/StepsView';
import CorrelationExecutionView from './components/CorrelationExecutionView';

const CRUMB_LABELS = {
  journeys: 'Journeys',
  steps: 'Journey',
  correlation: 'Correlation Execution',
};

function AppInner() {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [view, setView] = useState('journeys');
  const [selectedJourney, setSelectedJourney] = useState(null);
  const [selectedStep, setSelectedStep] = useState(null);
  
  // NEW: Global state to track if JVM issue has been resolved by the self-healing agent
  const [isJvmResolved, setIsJvmResolved] = useState(false);

 useEffect(() => {
    // 1. First, hit your POST endpoint to wipe the DB and read the local CSV
    observabilityService.resetDemoAlerts().then(() => {
      
      // 2. Once the database is ready, fetch the fresh dashboard data
      observabilityService.getAll()
        .then(setData)
        .catch(e => setErr(e.message));
        
    });
  }, []);

  // useEffect(() => {
  //   observabilityService.getAll()
  //     .then(setData)
  //     .catch(e => setErr(e.message));
  // }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [view]);

  if (err) return <div style={{ padding: 40 }}>Error: {err}</div>;
  if (!data) return <div style={{ padding: 40 }}>Loading...</div>;

  const { journeys, subJourneys, corrData, rules, horizontalData, verticalData2, jvmOomData } = data;

  const nav = (id) => setView(id);

  const openSteps = async (jid) => {
    try {
      const specificSubJourneys = await observabilityService.getSubJourneys(jid);
      if (Object.keys(specificSubJourneys).length === 0) {
        return false;
      }
      setData(prevData => ({
        ...prevData,
        subJourneys: {
          ...prevData.subJourneys,
          ...specificSubJourneys
        }
      }));
      setSelectedJourney(jid);
      setView('steps');
      return true;
    } catch (e) {
      setErr(e.message);
      return false;
    }
  };

  const openCorrelation = async (stepId) => {
    try {
      const scopedCorrData = await observabilityService.getCorrData(stepId);
      const horizontalClusterData = await observabilityService.getHorizontalTopCluster();
      const scopedVerticalData2 = await observabilityService.getCorrData(12, '2026-08-06T14:59:00');
      const jvmClusterData = await observabilityService.getJvmOomCluster();

      setData(prevData => ({
        ...prevData,
        corrData: scopedCorrData,
        horizontalData: horizontalClusterData,
        verticalData2: scopedVerticalData2,
        jvmOomData: jvmClusterData
      }));
      setSelectedStep(stepId);
      setView('correlation');
    } catch (e) {
      setErr(e.message);
    }
  };

  const crumbs = [{ id: 'journeys', label: CRUMB_LABELS.journeys }];
  if (['steps', 'correlation'].includes(view)) {
    crumbs.push({ id: 'steps', label: (selectedJourney && subJourneys[selectedJourney]?.title) || 'Journey' });
  }
  if (['correlation'].includes(view)) {
    crumbs.push({ id: 'correlation', label: CRUMB_LABELS.correlation });
  }

  let subjourneyStepName = '';
  let stepServices = [];
  if (selectedJourney && selectedStep) {
    const s = subJourneys[selectedJourney]?.steps.find(x => x.id === selectedStep);
    if (s) {
      subjourneyStepName = s.name;
      stepServices = s.services || [];
    }
  }

  const analysisBreadcrumb = selectedJourney && subJourneys[selectedJourney]
    ? `${subJourneys[selectedJourney].title} > ${subjourneyStepName || 'Upload Receipts'}`
    : 'Correlation Execution';

  return (
    <>
      <TopBar crumbs={crumbs} onNav={nav} />
      <div className="main">
        {view === 'journeys' && (
          <JourneysView 
            journeys={journeys} 
            subJourneys={subJourneys} 
            onOpenSteps={openSteps} 
            isJvmResolved={isJvmResolved} 
          />
        )}
        {view === 'steps' && (
          <StepsView
            journeyKey={selectedJourney}
            subJourneys={subJourneys}
            onBack={() => nav('journeys')}
            onOpenStep={openCorrelation}
            isJvmResolved={isJvmResolved}
          />
        )}
        {view === 'correlation' && (
          <CorrelationExecutionView
            corrData={corrData}
            horizontalData={horizontalData}
            verticalData2={verticalData2}
            jvmOomData={jvmOomData}
            services={stepServices}
            breadcrumb={analysisBreadcrumb}
            onBack={() => nav('steps')}
            isJvmResolved={isJvmResolved}
            onResolveJvm={() => setIsJvmResolved(true)}
          />
        )}
      </div>
      <footer style={{ textAlign: 'center', padding: '20px', fontSize: '10.5px', color: 'var(--text-dimmer)' }}>
        Application Reliability Engineering · Agentic Incident Correlation
      </footer>
    </>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <ModalProvider>
        <AppInner />
      </ModalProvider>
    </ToastProvider>
  );
}