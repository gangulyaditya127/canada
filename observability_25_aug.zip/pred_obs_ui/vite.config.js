import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { port: 5173, open: true },
  build:{
    outDir:'dist/predictive-ops_tcs'
  },
  base:'/predictive-ops_tcs/'
});
