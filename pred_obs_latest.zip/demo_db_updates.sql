-- =========================================================================
-- DEMO DATABASE UPDATES
-- Description: Updates incident severities and maps components to services
-- for the Claims Adjudication subjourney application cards.
-- =========================================================================

-- -------------------------------------------------------------------------
-- 1. INCIDENT SEVERITY OVERRIDES
-- -------------------------------------------------------------------------
-- Update 4 incidents from '3 - Medium' to '1 - Critical'
UPDATE incidents 
SET severity = '1 - Critical' 
WHERE number IN ('INC2150158', 'INC2150172', 'INC2150183', 'INC2131025');

-- Update 5 incidents from '3 - Medium' to '2 - High'
UPDATE incidents 
SET severity = '2 - High' 
WHERE number IN ('INC2150191', 'INC2150225', 'INC2150281', 'INC2131094', 'INC2131093');


-- -------------------------------------------------------------------------
-- 2. COMPONENT-TO-SERVICE ASSOCIATIONS
-- -------------------------------------------------------------------------
-- Clear any existing mappings for these specific services to avoid duplicates
DELETE FROM component_service_map 
WHERE service_id IN (12, 13, 14, 15);

-- Insert the precise component mappings mapped to the frontend cards
INSERT INTO component_service_map (service_id, component_id) VALUES
    -- Service 12: Benefits - AS (BEN)
    (12, 'comp1'), -- CICSCN
    (12, 'comp2'), -- PAS
    (12, 'comp3'), -- 3270 TPX CICSCN-BEN
    (12, 'comp4'), -- CLAIM FAMILY REGISTER

    -- Service 13: Data Entry Benefits System - AS (DEBS)
    (13, 'comp1'), -- CICSCN
    (13, 'comp2'), -- PAS

    -- Service 14: Automation - AS (Auto)
    (14, 'comp5'), -- RPVCP1

    -- Service 15: eClaims - AS (eClaims)
    (15, 'comp1'), -- CICSCN
    (15, 'comp3'); -- 3270 TPX CICSCN-BEN
