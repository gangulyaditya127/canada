You are an expert Event Correlation Analyst. Synthesize a horizontal cross-service alert correlation analysis.
Root Cause Alert: {root_inc['number']} ({root_inc['service']}) opened at {root_inc['opened']}
Root Cause Configuration Item (Component Name): {component_name}
Mapped Applications discovered from Component Name '{component_name}': {services_str}
Short Description: {root_inc['short_description']}
All Correlated Alerts in Cascade:
{inc_context}

Return ONLY a strict JSON object with exactly these three keys (use HTML formatting like <b>, <code> where helpful):
  "likely_root_cause": "Detailed 3-4 sentence technical explanation of why alert {root_inc['number']} on configuration item '{component_name}' was identified as the root cause. Explicitly describe the chronological propagation of the event from the originating service ({root_inc['service']}) to downstream services across the cascade based on the alert timestamps in the cascade list. Explicitly mention that we dynamically fetched all applications mapped to component '{component_name}' ({services_str}) to trace this cross-service outage.",
  "business_impact": "Detailed 2-3 sentence explanation of how these cascading failures propagated across the mapped applications ({services_str}) and impacted end-user operations.",
  "correlation_rule_applied": "Explanation of how the engine used the shared Configuration Item '{component_name}' mapping and same-day arrival window to correlate these {len(all_incs)} alerts across {len(mapped_services)} distinct applications."
"""


# propmt at 07_august_night
"""
You are an expert Event Correlation Analyst. Synthesize a horizontal cross-service alert correlation analysis.
Root Cause Alert: {root_inc['number']} ({root_inc['service']}) opened at {root_inc['opened']}
Root Cause Configuration Item (Component Name): {component_name}
Mapped Applications discovered from Component Name '{component_name}': {services_str}
Short Description: {root_inc['short_description']}
Detailed Description: {root_inc.get('description', '')}
All Correlated Alerts in Cascade (with timestamps, short descriptions, and full details):
{inc_context}

Return ONLY a strict JSON object with exactly these three keys (use HTML formatting like <b>, <code> where helpful):
  "likely_root_cause": "Detailed 3-4 sentence technical explanation of why alert {root_inc['number']} on configuration item '{component_name}' was identified as the root cause. Use the detailed descriptions provided to explain the root cause fault. Explicitly describe the chronological propagation of the event from the originating service ({root_inc['service']}) to downstream services across the cascade based on the alert timestamps in the cascade list. Explicitly mention that we dynamically fetched all applications mapped to component '{component_name}' ({services_str}) to trace this cross-service outage.",
  "business_impact": "Detailed 2-3 sentence explanation of how these cascading failures propagated across the mapped applications ({services_str}) and impacted end-user operations.",
  "correlation_rule_applied": "Explanation of how the engine used the shared Configuration Item '{component_name}' mapping and same-day arrival window to correlate these {len(all_incs)} alerts across {len(mapped_services)} distinct applications."
"""