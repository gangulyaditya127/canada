from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from dotenv import load_dotenv
from app.database import get_db
from app.services import correlation_service
load_dotenv()
router = APIRouter(prefix="/api/correlation", tags=["correlation"])

@router.get("/clusters")
def get_clusters(
    service_id: int = Query(..., description="The target service ID (e.g. 12 for Benefits - AS)"),
    opened_datetime: str = Query(..., description="The reference datetime in ISO format (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    clusters = correlation_service.build_clusters(service_id, ref_time, db)
    return {
        "service_id": service_id,
        "reference_datetime": opened_datetime,
        "total_clusters_found": len(clusters),
        "clusters": clusters
    }


@router.get("/top_cluster")
def get_top_cluster(
    service_id: int = Query(..., description="The target service ID (e.g. 12 for Benefits - AS)"),
    opened_datetime: str = Query(..., description="The reference datetime in ISO format (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    enriched_cluster = correlation_service.build_dynamic_enriched_top_cluster(service_id, ref_time, db)
    if not enriched_cluster:
        return {"error": f"No clusters found for service_id={service_id} and time window."}
        
    return enriched_cluster
@router.get("/splunk_children")
def get_splunk_children(
    parent_id: str = Query(..., description="The parent incident ID to search for"),
    db: Session = Depends(get_db)
):
    """
    Returns a list of incident IDs natively grouped by Splunk under a given parent_id.
    """
    return correlation_service.get_splunk_children(parent_id, db)

from app.core.config import settings

@router.get("/horizontal_clusters")
def get_all_horizontal_map_clusters(
    opened_datetime: str = Query(..., description="Reference ISO datetime (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    clusters = correlation_service.build_horizontal_map_clusters(ref_time, db)
    return {
        "reference_datetime": opened_datetime,
        "window_minutes": settings.HORIZONTAL_WINDOW_MINUTES,
        "total_clusters_found": len(clusters),
        "clusters": clusters
    }


@router.get("/horizontal_top_cluster")
def get_top_horizontal_map_cluster(
    opened_datetime: str = Query(..., description="Reference ISO datetime (e.g. 2026-05-25T06:00:00)"),
    db: Session = Depends(get_db)
):
    try:
        ref_time = datetime.fromisoformat(opened_datetime)
    except ValueError:
        return {"error": f"Invalid datetime format: '{opened_datetime}'."}
        
    top_cluster = correlation_service.get_top_horizontal_map_cluster(ref_time, db)
    if not top_cluster:
        return {"error": "No horizontal map clusters found for the given time window."}
        
    return {
        "reference_datetime": opened_datetime,
        "window_minutes": settings.HORIZONTAL_WINDOW_MINUTES,
        "top_cluster": top_cluster
    }
import os
import re
import requests
from requests.auth import HTTPBasicAuth
from typing import Optional, List
from fastapi import APIRouter, Depends, Query, HTTPException, Body
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.models import Incident
from app.services.llm_call import invoke

def generate_vertical_llm_description(parent_inc: Incident, child_incs: List[Incident]) -> str:
    """
    Generates an SRE incident description for Vertical Correlation using parent and child alert data.
    """
    try:
        children_context = "\n".join([
            f"- [{c.opened}] {c.number}: {c.short_description} (Severity: {c.severity})"
            for c in child_incs
        ])
        prompt = f"""
You are an expert SRE at Canada Life. Synthesize a professional ServiceNow incident description for a vertical application alert cluster.
Root Cause Alert: {parent_inc.number} ({parent_inc.service}) opened at {parent_inc.opened}
Short Description: {parent_inc.short_description}
Correlated Child Alerts ({len(child_incs)} alerts):
{children_context}

Write a comprehensive 3-4 sentence technical incident description summarizing why alert {parent_inc.number} is the root cause and how the {len(child_incs)} child alerts represent downstream symptoms within the {parent_inc.service} application tier.Also mention the no of child incidnets in the output.  Return ONLY the plain text description.
"""
        system_prompt = "You are an AI SRE assistant that outputs clean technical summary text only."
        return invoke(prompt, system_prompt=system_prompt).strip()
    except Exception as e:
        print(f"[VERTICAL-LLM] Fallback triggered due to error: {e}")
        return f"Root Cause Alert {parent_inc.number} ({parent_inc.short_description}) in service {parent_inc.service}. Correlated with {len(child_incs)} child alerts in the same application tier."

@router.post("/create_servicenow_ticket")
def create_servicenow_ticket(
    incident_id: str = Query(..., description="Root cause alert number (e.g., INC2150158 or EVT46288)"),
    llm_description: Optional[str] = Query(None, description="LLM generated root cause description to use for ServiceNow ticket"),
    child_alert_ids: Optional[List[str]] = Query(None, description="List of child alert IDs to stamp with correlated_parent"),
    db: Session = Depends(get_db)
):
    try:
        # 1. Fetch the root cause alert directly from the database table
        inc = db.query(Incident).filter(Incident.number == incident_id).first()
        if not inc:
            return {
                "success": False, 
                "error": f"Root Cause Alert '{incident_id}' not found in database."
            }

        # 2. Identify child alerts (either passed from UI or found via parent_incident column in DB)
        if child_alert_ids and len(child_alert_ids) > 0:
            child_incs = db.query(Incident).filter(Incident.number.in_(child_alert_ids)).all()
        else:
            child_incs = db.query(Incident).filter(Incident.parent_incident == incident_id).all()

        # 3. Determine the Description to send to ServiceNow
        short_desc = (inc.short_description or "").strip()
        if llm_description and llm_description.strip():
            # Use the LLM description passed from Horizontal/Vertical UI
            desc = llm_description.strip()
        elif len(child_incs) > 0:
            # Generate vertical LLM description dynamically from child records
            desc = generate_vertical_llm_description(inc, child_incs)
        else:
            desc = (inc.description or inc.short_description or "").strip()
        
        # Extract leading digit for ServiceNow Table API (e.g., '1 - Critical' -> '1', fallback '3')
        impact_match = re.match(r"^(\d+)", str(inc.impact or "3").strip())
        impact_val = impact_match.group(1) if impact_match else "3"
        
        urgency_match = re.match(r"^(\d+)", str(inc.urgency or "3").strip())
        urgency_val = urgency_match.group(1) if urgency_match else "3"

        cmdb_ci_val = "Benefit - AS"
        assignment_group_val = "ARE_TEAM"

        payload = {
            "cmdb_ci": cmdb_ci_val,
            "assignment_group": assignment_group_val,
            "short_description": short_desc,
            "description": desc,
            "impact": 2,
            "urgency": 2,
            "priority": 3
        }

        # 4. Call ServiceNow REST Table API
        sn_instance = os.getenv("SERVICENOW_BASE_URL", "").rstrip("/")
        sn_user = os.getenv("SERVICENOW_USERNAME", "admin")
        sn_password = os.getenv("SERVICENOW_PASSWORD", "")
        
        if not sn_instance or not sn_password:
            return {
                "success": False, 
                "error": "ServiceNow API credentials (SERVICENOW_BASE_URL / SERVICENOW_PASSWORD) are not configured."
            }

        url = f"{sn_instance}/api/now/table/incident"
        res = requests.post(
            url,
            auth=HTTPBasicAuth(sn_user, sn_password),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            json=payload,
            timeout=10,
            # proxies={"http": "185.46.212.90:443","https":"185.46.212.90.443"}
        )

        sn_result = res.json().get("result", {})
        sn_ticket_number = sn_result.get("number")
        sn_sys_id = sn_result.get("sys_id")

        if not sn_ticket_number:
            return {
                "success": False, 
                "error": "ServiceNow API responded successfully but did not return a ticket number."
            }

        # Build direct URL to open the incident record in ServiceNow
        sn_instance = os.getenv("SERVICENOW_BASE_URL", "").rstrip("/")
        sn_url = f"{sn_instance}/now/nav/ui/classic/params/target/incident.do%3Fsys_id%3D{sn_sys_id}" if sn_sys_id else f"{sn_instance}/now/nav/ui/classic/params/target/incident_list.do"

        # 5. Save `correlated_incident` on root alert AND `correlated_parent` on all child alerts
        try:
            inc.correlated_incident = sn_ticket_number
            
            # TASK 1: Stamp correlated_parent column for each child alert
                           
            db.commit()
            db.refresh(inc)
        except Exception as db_err:
            db.rollback()
            return {
                "success": False, 
                "error": f"Ticket {sn_ticket_number} created in ServiceNow, but failed to save DB correlation columns: {str(db_err)}"
            }

        return {
            "success": True,
            "source_incident_id": incident_id,
            "servicenow_ticket_number": sn_ticket_number,
            "sys_id": sn_sys_id,                 # <-- RETURN SYS_ID
            "servicenow_url": sn_url,            # <-- RETURN DIRECT TICKET URL
            "cmdb_ci": cmdb_ci_val,
            "assignment_group": assignment_group_val,
            "description_used": desc,
            "children_correlated_count": len(child_incs),
            "message": f"ServiceNow ticket {sn_ticket_number} created successfully."
       }

    except Exception as e:
        print(f"[SN-CREATE] Unexpected server error: {str(e)}")
        return {
            "success": False, 
            "error": f"Unexpected server error while creating ticket: {str(e)}"
        }
