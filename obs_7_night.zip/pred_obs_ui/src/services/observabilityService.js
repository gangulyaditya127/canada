import { journeys as mockJourneys, subJourneys as mockSubJourneys, correlationCluster, ruleDiscoveryData } from '../data/mockData';

// const API_BASE = 'http://localhost:8000/api';

// After:
const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api';
export const observabilityService = {
  getAll: async () => {
    try {
      const res = await fetch(`${API_BASE}/journeys`);
      if (!res.ok) throw new Error("Failed to fetch journeys");
      const fetchedJourneys = await res.json();
      return {
        journeys: fetchedJourneys,
        subJourneys: mockSubJourneys,
        corrData: correlationCluster,
        rules: ruleDiscoveryData
      };
    } catch (e) {
      console.error("API failed, falling back to mock data", e);
      return {
        journeys: mockJourneys,
        subJourneys: mockSubJourneys,
        corrData: correlationCluster,
        rules: ruleDiscoveryData
      };
    }
  },
  getSubJourneys: async (jid) => {
    try {
      const res = await fetch(`${API_BASE}/journeys/${jid}/subjourneys`);
      if (!res.ok) throw new Error("Failed to fetch subjourneys");
      const fetchedSubJourneys = await res.json();
      
      const journeyRes = await fetch(`${API_BASE}/journeys`);
      const allJourneys = await journeyRes.json();
      const parentJourney = allJourneys.find(j => j.id === jid) || { name: 'Journey' };
      
      return {
        [jid]: {
          title: parentJourney.name,
          steps: fetchedSubJourneys.map(s => ({
            id: s.id,
            name: s.name,
            status: s.status,
            hu: [s.happy || 0, s.unhappy || 0, s.frustrated || 0],
            critical: s.status === 'warning' || s.status === 'critical',
            // --- Map nested services from backend table ---
            services: (s.service_mappings || []).map(svc => ({
              id: svc.id,
              name: svc.service_name,
              shortName: svc.short_name,
              avg: svc.resp || 0,
              p95: svc.p95 || 0,
              err: svc.errRate || 0,
              avail: svc.avail || 100.0,
              components: (svc.component_mappings || []).map(cm => cm.component.component_name).join(', ')
            }))
          }))
        }
      };
    } catch (e) {
      console.error("API failed, falling back to mock data", e);
      return { [jid]: mockSubJourneys[jid] };
    }
  },

  getCorrData: async (serviceId, openedDatetime) => {
    try {
      // 1. Fetch Vertical Correlation Cluster by service_id
      const timeParam = openedDatetime || '2026-06-15T12:00:00';
      // Ensure svcParam is an integer to avoid FastAPI 422 validation errors.
      // If serviceId is a string like "s3" from the step ID, we default to 12.
      let svcParam = parseInt(serviceId, 10);
      if (isNaN(svcParam)) {
        svcParam = 12;
      }
      
      const res = await fetch(`${API_BASE}/correlation/top_cluster?service_id=${svcParam}&opened_datetime=${timeParam}`);
      
      if (!res.ok) {
        if (res.status === 404) return null;
        console.warn('API error fetching correlation, falling back to mock.', res.statusText);
        return correlationCluster;
      }
      const data = await res.json();
      
      if (data.error) {
        console.warn('Backend returned error:', data.error);
        // return correlationCluster;
        return null
      }

      // 2. RESTORED: Fetch Splunk children to flag missed incidents
      try {
        const splunkRes = await fetch(`${API_BASE}/correlation/splunk_children?parent_id=${encodeURIComponent(data.parent.id)}`);
        if (splunkRes.ok) {
          const splunkChildrenIds = await splunkRes.json();
          if (data.children && Array.isArray(data.children)) {
            data.children = data.children.map(c => ({
              ...c,
              missedBySplunk: !splunkChildrenIds.includes(c.id)
            }));
          }
        }
      } catch (splunkErr) {
        console.error('Failed to fetch splunk children:', splunkErr);
      }

      return data;
    } catch (e) {
      console.error("API failed for getCorrData, falling back to mock data", e);
      return correlationCluster;
    }
  },
  getRules: async () => {
    return ruleDiscoveryData;
  },
  minePatterns: async () => { return true; },
  listPatterns: async () => { return []; },
  synthesizePattern: async () => { return {}; },
  listProposals: async () => { return []; },
  approveProposal: async () => { return true; },
  rejectProposal: async () => { return true; },
  getHorizontalTopCluster: async () => {
    try {
      const res = await fetch(`${API_BASE}/correlation/horizontal_top_cluster?opened_datetime=2026-08-06T14:59:00`);
      if (!res.ok) throw new Error("Failed to fetch horizontal top cluster");
      const data = await res.json();
      if (data.error) return null;
      return data.top_cluster;
    } catch (e) {
      console.error("API failed for getHorizontalTopCluster", e);
      return null;
    }
  },
  createServiceNowTicket: async (incidentId, llmDescription = null, childAlertIds = []) => {
    try {
      const params = new URLSearchParams({ incident_id: incidentId });
      if (llmDescription) {
        params.append('llm_description', llmDescription);
      }
      if (childAlertIds && childAlertIds.length > 0) {
        childAlertIds.forEach(id => params.append('child_alert_ids', id));
      }

      const res = await fetch(`${API_BASE}/correlation/create_servicenow_ticket?${params.toString()}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!res.ok) throw new Error(`Failed to create ServiceNow ticket: ${res.status}`);
      return await res.json();
    } catch (e) {
      console.error("API failed for createServiceNowTicket:", e);
      return {
        success: false,
        error: e.message || "Failed to create ServiceNow ticket."
      };
    }
  },
};