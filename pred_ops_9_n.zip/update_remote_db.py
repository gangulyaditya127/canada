import psycopg2
import urllib.parse

# Database configuration
DB_USER = "postgres"
# If your password has special characters, urllib.parse.quote_plus helps, but 'StrongPassword123' is fine as is.
DB_PASS = "StrongPassword123"
DB_HOST = "10.73.74.37"
DB_PORT = "5432"
DB_NAME = "observability"

SQL_QUERIES = [
    # 1. Add the new column to the table
    """
    ALTER TABLE sub_journey_services 
    ADD COLUMN IF NOT EXISTS open_alerts INTEGER DEFAULT NULL;
    """,

    # 2. Set 'open_alerts' to 24 for Benefit-AS
    """
    UPDATE sub_journey_services 
    SET open_alerts = 24 
    WHERE service_name ILIKE '%Benefit%AS%' OR short_name ILIKE 'BEN%';
    """,

    # 3. Set 'open_alerts' to 4 for eclaims
    """
    UPDATE sub_journey_services 
    SET open_alerts = 4 
    WHERE service_name ILIKE '%eclaims%' OR short_name ILIKE 'ECL%';
    """,

    # 4. Set 'open_alerts' to 3 for debs
    """
    UPDATE sub_journey_services 
    SET open_alerts = 3 
    WHERE service_name ILIKE '%debs%' OR short_name ILIKE 'DEBS%';
    """,

    # 5. Insert Incidents
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46293', '2026-08-09T09:00:12', 'ITSI Event Management', 'PAGER79 309B 79-501 _P3 DFHAP0001 CICSCN AN ABEND CODE 0C7/ASRA HAS OCCURRED IN TRANSACTION DEPR PROGRAM GH21DEPR01', '2 - Medium', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:00:12', 'Monitoring', 'CICSCN', '2026-08-09T09:00:12', 'PAGER79 309B 79-501 _P3 DFHAP0001 CICSCN AN ABEND CODE 0C7/ASRA HAS OCCURRED IN TRANSACTION DEPR PROGRAM GH21DEPR01', '1 - High', 'New', 'Benefits - AS', '2 - Medium');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46294', '2026-08-09T09:03:24', 'ITSI Event Management', 'PAGER79 309B 79-502 _P3 DFHAP0001 CICSCN AN ABEND CODE 0C4/ASRA HAS OCCURRED IN TRANSACTION KHI1 PROGRAM GH20KHI101', '2 - Medium', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:03:24', 'Monitoring', 'CICSCN', '2026-08-09T09:03:24', 'PAGER79 309B 79-502 _P3 DFHAP0001 CICSCN AN ABEND CODE 0C4/ASRA HAS OCCURRED IN TRANSACTION KHI1 PROGRAM GH20KHI101', '1 - High', 'New', 'Benefits - AS', '2 - Medium');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46295', '2026-08-09T09:05:58', 'ITSI Event Management', 'PAGER79 309B 79-503 _P3 DFHAP0001 CICSCN AN ABEND CODE 0C9/ASRA HAS OCCURRED IN TRANSACTION LK2D PROGRAM GH20LK2D01', '1 - High', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:05:58', 'Monitoring', 'CICSCN', '2026-08-09T09:05:58', 'PAGER79 309B 79-503 _P3 DFHAP0001 CICSCN AN ABEND CODE 0C9/ASRA HAS OCCURRED IN TRANSACTION LK2D PROGRAM GH20LK2D01', '1 - High', 'New', 'Benefits - AS', '1 - High');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46296', '2026-08-09T09:08:35', 'ITSI Event Management', 'PAGER79 309B 79-504 _P3 DFHAP0001 CICSCN AN ABEND CODE 0C1/ASRA HAS OCCURRED IN TRANSACTION R05P PROGRAM GH20R05P01', '1 - High', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:08:35', 'Monitoring', 'CICSCN', '2026-08-09T09:08:35', 'PAGER79 309B 79-504 _P3 DFHAP0001 CICSCN AN ABEND CODE 0C1/ASRA HAS OCCURRED IN TRANSACTION R05P PROGRAM GH20R05P01', '1 - High', 'New', 'Benefits - AS', '1 - High');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46297', '2026-08-09T09:11:37', 'ITSI Event Management', 'PAGER79 309B 79-601 _P3 DFHAC2206 CICSCN SOFT RLEL WARNING — TRANSACTION RDLU AT 78% OF RESOURCE LIMIT, PROGRAM GH20RDLU02', '3 - Low', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:11:37', 'Monitoring', 'CICSCN', '2026-08-09T09:11:37', 'PAGER79 309B 79-601 _P3 DFHAC2206 CICSCN SOFT RLEL WARNING — TRANSACTION RDLU AT 78% OF RESOURCE LIMIT, PROGRAM GH20RDLU02', '1 - High', 'New', 'Benefits - AS', '3 - Low');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46298', '2026-08-09T09:14:40', 'ITSI Event Management', 'PAGER79 309B 79-602 _P3 DFHAC2206 CICSCN TRANSACTION WAIT ABEND RLEL — RUNAWAY TASK, ELAPSED TIME LIMIT EXCEEDED, PROGRAM GH20WAIT01', '2 - Medium', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:14:40', 'Monitoring', 'CICSCN', '2026-08-09T09:14:40', 'PAGER79 309B 79-602 _P3 DFHAC2206 CICSCN TRANSACTION WAIT ABEND RLEL — RUNAWAY TASK, ELAPSED TIME LIMIT EXCEEDED, PROGRAM GH20WAIT01', '1 - High', 'New', 'Benefits - AS', '2 - Medium');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46299', '2026-08-09T09:17:24', 'ITSI Event Management', 'PAGER79 309B 79-604 _P3 DFHAC2206 CICSCN TRANSACTION TFIX ABEND RLEL — VSAM FILE CONTROL ENQUEUE WAIT EXCEEDED, PROGRAM GH21TFIX01', '1 - High', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:17:24', 'Monitoring', 'CICSCN', '2026-08-09T09:17:24', 'PAGER79 309B 79-604 _P3 DFHAC2206 CICSCN TRANSACTION TFIX ABEND RLEL — VSAM FILE CONTROL ENQUEUE WAIT EXCEEDED, PROGRAM GH21TFIX01', '1 - High', 'New', 'Benefits - AS', '1 - High');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46300', '2026-08-09T09:19:31', 'ITSI Event Management', 'PAGER79 309B 79-605 _P3 DFHAC2206 CICSCN TRANSACTION DEBP ABEND RLEL — MQ GET WAIT EXCEEDED THRESHOLD, PROGRAM GH21DEBP01', '1 - High', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:19:31', 'Monitoring', 'CICSCN', '2026-08-09T09:19:31', 'PAGER79 309B 79-605 _P3 DFHAC2206 CICSCN TRANSACTION DEBP ABEND RLEL — MQ GET WAIT EXCEEDED THRESHOLD, PROGRAM GH21DEBP01', '1 - High', 'New', 'Benefits - AS', '1 - High');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46301', '2026-08-09T09:21:39', 'ITSI Event Management', 'PAGER79 309B CICSCN MAY BE DOWN, PLEASE CHECK — MULTIPLE RLEL TRANSACTIONS SUSPENDED', '1 - Critical', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:21:39', 'Monitoring', 'CICSCN', '2026-08-09T09:21:39', 'PAGER79 309B CICSCN MAY BE DOWN, PLEASE CHECK — MULTIPLE RLEL TRANSACTIONS SUSPENDED', '1 - High', 'New', 'Benefits - AS', '1 - Critical');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46302', '2026-08-09T09:24:23', 'ITSI Event Management', 'EClaims health score is MEDIUM — average response time trending above baseline following Ben CICSCN RLEL cluster', '2 - Medium', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:24:23', 'Monitoring', 'CICSCN', '2026-08-09T09:24:23', 'EClaims health score is MEDIUM — average response time trending above baseline following Ben CICSCN RLEL cluster', '1 - High', 'New', 'eClaims - AS', '2 - Medium');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46303', '2026-08-09T09:27:07', 'ITSI Event Management', 'SAXParseException is greater than 40 — inbound claims XML parse failures rising as Ben dependency slows downstream processing', '1 - High', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:27:07', 'Monitoring', 'CICSCN', '2026-08-09T09:27:07', 'SAXParseException is greater than 40 — inbound claims XML parse failures rising as Ben dependency slows downstream processing', '1 - High', 'New', 'eClaims - AS', '1 - High');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46304', '2026-08-09T09:29:33', 'ITSI Event Management', 'SAXParseException is greater than 40 — parse failure count continuing to climb, claims intake queue growing', '1 - High', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:29:33', 'Monitoring', 'CICSCN', '2026-08-09T09:29:33', 'SAXParseException is greater than 40 — parse failure count continuing to climb, claims intake queue growing', '1 - High', 'New', 'eClaims - AS', '1 - High');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46305', '2026-08-09T09:32:17', 'ITSI Event Management', 'EClaims health score is CRITICAL — average response time exceeds SLA threshold, claims submission queue backing up', '1 - Critical', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:32:17', 'Monitoring', 'CICSCN', '2026-08-09T09:32:17', 'EClaims health score is CRITICAL — average response time exceeds SLA threshold, claims submission queue backing up', '1 - High', 'New', 'eClaims - AS', '1 - Critical');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46306', '2026-08-09T09:35:01', 'ITSI Event Management', 'DEBS - Middleware - MESH showing Medium on Glass table — downstream data-entry feed queuing behind the Ben/EClaims slowdown', '2 - Medium', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:35:01', 'Monitoring', 'CICSCN', '2026-08-09T09:35:01', 'DEBS - Middleware - MESH showing Medium on Glass table — downstream data-entry feed queuing behind the Ben/EClaims slowdown', '1 - High', 'New', 'Data Entry Benefits System - AS', '2 - Medium');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46307', '2026-08-09T09:37:46', 'ITSI Event Management', 'DEBS - Middleware - MESH showing High on Glass table — message backlog continuing to grow, benefits data entry delayed', '1 - High', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:37:46', 'Monitoring', 'CICSCN', '2026-08-09T09:37:46', 'DEBS - Middleware - MESH showing High on Glass table — message backlog continuing to grow, benefits data entry delayed', '1 - High', 'New', 'Data Entry Benefits System - AS', '1 - High');",
    "INSERT INTO incidents (number, opened, caller, short_description, priority, state, assignment_group, updated, channel, configuration_item, created, description, impact, incident_state, service, severity) VALUES ('EVT46308', '2026-08-09T09:40:12', 'ITSI Event Management', 'DEBS - Middleware - MESH showing Critical on Glass table — backlog threshold breached, benefits data entry SLA at risk', '1 - Critical', 'New', 'Group Cust Tech - GLH Benefits', '2026-08-09T09:40:12', 'Monitoring', 'CICSCN', '2026-08-09T09:40:12', 'DEBS - Middleware - MESH showing Critical on Glass table — backlog threshold breached, benefits data entry SLA at risk', '1 - High', 'New', 'Data Entry Benefits System - AS', '1 - Critical');",

    # 6. Update journeys table
    """
    UPDATE journeys 
    SET alerts = 26 
    WHERE name = 'Health and Dental Claims';
    """,

    # 7. Update active users for all journeys
    """
    UPDATE journeys SET users = 85 WHERE id = 'J1';
    """,
    """
    UPDATE journeys SET users = 119 WHERE id = 'J2';
    """,
    """
    UPDATE journeys SET users = 111 WHERE id = 'J3';
    """,
    """
    UPDATE journeys SET users = 76 WHERE id = 'J4';
    """,
    """
    UPDATE journeys SET users = 140 WHERE id = 'J5';
    """
]

def update_database():
    print("Connecting to the PostgreSQL database...")
    try:
        conn = psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASS,
            host=DB_HOST,
            port=DB_PORT
        )
        conn.autocommit = False
        cur = conn.cursor()
        print("Successfully connected.")

        for i, query in enumerate(SQL_QUERIES):
            try:
                print(f"Executing query {i + 1}/{len(SQL_QUERIES)}...")
                cur.execute(query)
                # For INSERTs we could check rowcount if we wanted, but not strictly necessary here.
                if cur.rowcount >= 0:
                    print(f"Query {i + 1} completed. Rows affected: {cur.rowcount}")
                else:
                    print(f"Query {i + 1} completed.")
            except Exception as e:
                # If an error happens (e.g. duplicate key for inserts), catch it and decide whether to rollback
                print(f"Error executing query {i + 1}: {e}")
                # We'll rollback the transaction if we want all-or-nothing, but sometimes users re-run scripts.
                # Let's rollback and re-raise.
                conn.rollback()
                raise e

        # Commit all changes if successful
        conn.commit()
        print("All queries executed successfully. Changes committed.")

    except Exception as e:
        print(f"Database operation failed: {e}")
    finally:
        if 'conn' in locals() and conn:
            cur.close()
            conn.close()
            print("Database connection closed.")

if __name__ == "__main__":
    update_database()
