import React, { useState } from "react";
import { useModal } from "../context/ModalContext";
import { useToast } from "../context/ToastContext";
import { observabilityService } from "../services/observabilityService";

export default function VerticalCorrelation({ corrData, isEvent2, createdTickets = {}, onTicketCreated }) {
  const { openModal, closeModal } = useModal();
  const { showToast } = useToast();

  const [isCreatingTicket, setIsCreatingTicket] = useState(false);
  const [createdTicketNumber, setCreatedTicketNumber] = useState(null);
  const [createdTicketUrl, setCreatedTicketUrl] = useState(null);

  if (!corrData) return <div>No vertical correlation data available.</div>;
  const incident = corrData.incident;

  // Use unique ID for this specific cluster
  const rootCauseId = corrData.parent?.id || corrData.parent?.incident_number || incident?.id || 'VERTICAL_CLUSTER';

  // STRICT CHECK: Only show ticket badge if created for THIS specific rootCauseId
  const existingTicket = createdTickets[rootCauseId] || 
                         (createdTicketNumber ? { ticketNumber: createdTicketNumber, url: createdTicketUrl } : null);

  // --- HANDLER FOR VERTICAL SERVICENOW TICKET CREATION ---
  const handleCreateServiceNowTicket = async () => {
    const childIds = (corrData.children || []).map(c => c.id).filter(Boolean);
    const llmDesc = incident?.root_cause_desc || corrData.parent?.description || "";

    setIsCreatingTicket(true);
    try {
      const res = await observabilityService.createServiceNowTicket(rootCauseId, llmDesc, childIds);
      
      if (!res.success || res.error) {
        showToast(`<b>Error:</b> ${res.error || 'Failed to create ServiceNow ticket.'}`);
        return;
      }

      const snNum = res.servicenow_ticket_number;
      const snUrl = res.servicenow_url || `https://tataconsultancyservicesdemo5.service-now.com/now/nav/ui/classic/params/target/incident.do%3Fsys_id%3D${res.sys_id}`;
      
      setCreatedTicketNumber(snNum);
      setCreatedTicketUrl(snUrl);
      if (onTicketCreated) {
        onTicketCreated(rootCauseId, snNum, snUrl);
      }

      openModal({
        title: 'ServiceNow Ticket Created Successfully (Vertical Cluster)',
        id: `Ticket Number: ${snNum}`,
        body: (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{
              background: 'var(--green-tint)',
              border: '1px solid var(--green)',
              borderLeft: '4px solid var(--green)',
              padding: '14px',
              borderRadius: '6px',
              color: 'var(--text-main)',
              fontSize: '13.5px'
            }}>
              <strong>ServiceNow Incident {snNum}</strong> created for root cause alert <strong>{rootCauseId}</strong>. Column <code>correlated_parent</code> has been stamped as <strong>{rootCauseId}</strong> across <strong>{childIds.length}</strong> child alert(s).
            </div>

            <table className="aa-table" style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
              <tbody>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Created SN Ticket</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)' }}>
                    <a 
                      href={snUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      style={{ 
                        color: 'var(--green-dark)', 
                        textDecoration: 'underline',
                        cursor: 'pointer'
                      }}
                      title="Click to open this Incident in ServiceNow in a new tab"
                    >
                      {snNum} ↗
                    </a>
                  </td>
                </tr>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Root Cause Alert</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)', color: 'var(--status-critical)' }}>{rootCauseId}</td>
                </tr>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Children Stamped</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)' }}>{childIds.length} alerts</td>
                </tr>
                <tr>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Application CI</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)' }}>{res.cmdb_ci || 'Benefit - AS'}</td>
                </tr>
                {/* ADD THIS NEW PRIORITY ROW */}
                <tr>
                  <td style={{ padding: '10px', fontWeight: 600, color: 'var(--text-muted)' }}>Priority</td>
                  <td style={{ padding: '10px', fontWeight: 700, fontFamily: 'var(--mono)' }}>{res.priority || '3 - Moderate'}</td>
                </tr>
              </tbody>
            </table>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '10px' }}>
              <button
                className="cta-btn"
                style={{ padding: '8px 18px', fontSize: '12px', background: 'var(--green)', borderColor: 'var(--green)' }}
                onClick={() => closeModal()}
              >
                Close &amp; Continue
              </button>
            </div>
          </div>
        )
      });

      showToast(`<b>ServiceNow Ticket Created:</b> <b>${snNum}</b> linked to vertical cluster <b>${rootCauseId}</b>.`);
    } catch (e) {
      console.error(e);
      showToast(`<b>Error:</b> ${e.message || 'Could not create ServiceNow ticket.'}`);
    } finally {
      setIsCreatingTicket(false);
    }
  };

  return (
    <>
      {/* ACTION BAR: SHOWS TICKET BADGE OR CREATE BUTTON */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
        {existingTicket ? (
          <span style={{
            background: 'var(--green-tint)',
            color: 'var(--green-dark)',
            border: '1px solid var(--green)',
            padding: '6px 12px',
            borderRadius: '20px',
            fontSize: '12px',
            fontWeight: 700,
            fontFamily: 'var(--mono)'
          }}>
            ✓ Ticket Created: {' '}
            <a 
              href={existingTicket.url} 
              target="_blank" 
              rel="noopener noreferrer"
              style={{ color: 'var(--green-dark)', textDecoration: 'underline' }}
            >
              {existingTicket.ticketNumber} ↗
            </a>
          </span>
        ) : (
          <button
            className="cta-btn"
            disabled={isCreatingTicket}
            onClick={handleCreateServiceNowTicket}
            style={{
              padding: '8px 18px',
              fontSize: '12px',
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              background: isCreatingTicket ? 'var(--text-muted)' : 'var(--cl-red)',
              borderColor: isCreatingTicket ? 'var(--text-muted)' : 'var(--cl-red)',
              cursor: isCreatingTicket ? 'wait' : 'pointer',
              boxShadow: 'var(--shadow-sm)'
            }}
          >
            <span>{isCreatingTicket ? '⏳' : '🚀'}</span>
            {isCreatingTicket ? 'Creating Ticket...' : 'Create ServiceNow Ticket'}
          </button>
        )}
      </div>

      {!isEvent2 ? (
        <div className="exec-row">
          <div className="exec-card rc">
            <span className="exec-badge">Root Cause</span>
            <h2>
              {incident?.root_cause || "Unknown Root Cause"}
            </h2>
            <p className="exec-desc" dangerouslySetInnerHTML={{ __html: incident?.root_cause_desc || "Loading alert details..." }}>
            </p>
            <div className="exec-metrics">
              <div className="exec-metric">
                <div className="m-val">{(corrData?.children?.length ?? 0) + 1}</div>
                <div className="m-lbl">raw alerts grouped</div>
              </div>
              <div className="exec-metric">
                <div className="m-val">{incident?.tools_contributing ?? "-"}</div>
                <div className="m-lbl">tools contributing</div>
              </div>
              <div className="exec-metric">
                <div className="m-val">{incident?.correlation_confidence_pct ?? "-"}%</div>
                <div className="m-lbl">correlation confidence</div>
              </div>
            </div>
          </div>
          <div className="exec-side">
            <h3>Business Impact</h3>
            <div className="impact-row">
              <span className="lb2">Journey affected</span>
              <span className="vv">Health & Dental Claims</span>
            </div>
            <div className="impact-row">
              <span className="lb2">Sub-journey</span>
              <span className="vv">Claims Adjudication</span>
            </div>
            <div className="impact-row">
              <span className="lb2">Availability</span>
              <span className="vv bad">94.20 %</span>
            </div>
            <div className="impact-row">
              <span className="lb2">Frustrated users</span>
              <span className="vv bad">10 %   {incident?.frustrated_user_count ?? 152} members</span>
            </div>
            <div className="impact-row">
              <span className="lb2">Alert ID</span>
              <span className="vv">{incident?.id ?? "INC0048291"}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="card" style={{ display: 'flex', gap: '2rem', background: '#fef2f2', border: '1px solid #fca5a5' }}>
          <div style={{ flex: 1, borderRight: '1px dashed #fca5a5', paddingRight: '2rem' }}>
            <span className="badge critical" style={{ background: 'var(--status-critical)', color: 'white', border: 'none', marginBottom: '1rem', display: 'inline-block', padding: '4px 8px', borderRadius: '4px', fontSize: '10px', fontWeight: 'bold' }}>ROOT CAUSE</span>
            <div style={{ color: 'var(--status-critical)', fontWeight: 700, fontSize: '1.1rem', marginBottom: '0.5rem', fontFamily: 'var(--disp)' }}>
              {incident?.root_cause || corrData.parent?.description || "Unknown Root Cause"}
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-main)', marginTop: '0.5rem' }} dangerouslySetInnerHTML={{ __html: incident?.root_cause_desc || "Loading alert details..." }}></div>
          </div>
                     
          <div style={{ width: '300px', display: 'flex', flexDirection: 'column', gap: '1rem', justifyContent: 'center' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px dashed #fca5a5', paddingBottom: '0.5rem' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Raw Alerts Grouped</span>
              <span style={{ fontWeight: 700, color: 'var(--status-critical)' }}>{(corrData?.children?.length ?? 0) + 1}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px dashed #fca5a5', paddingBottom: '0.5rem' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Tools Contributing</span>
              <span style={{ fontWeight: 700, color: 'var(--status-critical)' }}>{incident?.tools_contributing ?? "-"}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>Correlation Confidence</span>
              <span style={{ fontWeight: 700, color: 'var(--status-critical)' }}>{incident?.correlation_confidence_pct ?? "-"}%</span>
            </div>
          </div>
        </div>
      )}
      <section className="analysis-section" style={{ marginTop: '24px' }}>
        <div className="sec-head">
          <div className="sec-step" style={{ background: 'var(--text-muted)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
          </div>
          <div>
            <h2 className="sec-title">Clustered Alerts Timeline</h2>
            <p className="sec-sub">
              Cluster: {corrData.parent?.extractedJob} | Pattern: {corrData.parent?.grammar} | Application: {corrData.parent?.service}
            </p>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {/* PARENT ROW */}
          {corrData.parent && (
            <div style={{ 
               background: 'var(--bg-panel)', 
               border: '1px solid var(--status-warning)', 
               borderRadius: '8px', 
               padding: '16px' 
             }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontWeight: 'bold', color: 'var(--status-warning)' }}>{corrData.parent.id} (PARENT)</span>
                <span style={{ color: 'var(--text-muted)' }}>{corrData.parent.time}</span>
              </div>
              <div style={{ fontFamily: 'monospace', color: 'var(--text-main)' }}>
                {corrData.parent.description}
              </div>
            </div>
          )}
          {/* CHILDREN ROWS */}
          {(corrData.children || []).map(child => (
            <div key={child.id} style={{ 
               background: 'var(--bg-panel)', 
               border: '1px solid var(--border)', 
               borderRadius: '8px', 
               padding: '16px', 
              marginLeft: '40px', 
              position: 'relative'
            }}>
              <div style={{
                position: 'absolute',
                left: '-24px',
                top: '24px',
                width: '24px',
                height: '2px',
                background: 'var(--border)'
              }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <span style={{ fontWeight: 'bold', color: 'var(--status-ok)' }}>{child.id} (CHILD)</span>
                  {child.missedBySplunk && (
                    <span style={{
                      background: 'var(--status-critical)',
                      color: '#fff',
                      padding: '2px 8px',
                      borderRadius: '12px',
                      fontSize: '10px',
                      fontWeight: 'bold',
                      letterSpacing: '0.5px'
                    }}>MISSED BY SPLUNK</span>
                  )}
                </div>
                <div style={{ display: 'flex', gap: '16px', color: 'var(--text-muted)' }}>
                  <span>Delta: {child.delta}</span>
                  <span>{child.time}</span>
                </div>
              </div>
              <div style={{ fontFamily: 'monospace', color: 'var(--text-main)', marginBottom: '12px' }}>
                {child.description}
              </div>
                             
              {/* CONFIDENCE BAR */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '12px' }}>
                <span style={{ color: 'var(--text-muted)' }}>Confidence Score:</span>
                <div style={{ flex: 1, background: 'var(--bg)', height: '6px', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ 
                     width: `${child.confidence * 100}%`, 
                     background: child.confidence >= 0.9 ? 'var(--status-ok)' : 'var(--status-warning)', 
                     height: '100%' 
                   }} />
                </div>
                <span style={{ fontWeight: 'bold' }}>{(child.confidence * 100).toFixed(0)}%</span>
              </div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '4px' }}>
                Boosters: {(child.boosters || []).join(', ')}
              </div>
            </div>
          ))}
        </div>
        
        {/* --- TIGHTENED BACK TO TOP BUTTON --- */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'flex-end', 
          alignItems: 'center', 
          marginTop: '8px', 
          paddingTop: '6px', 
          borderTop: '1px dashed var(--border)' 
        }}>
          <button
            className="back-btn"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            style={{
              fontSize: '12px',
              fontWeight: 600,
              color: 'var(--cl-red)',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            <span>↑</span> Back to Top
          </button>
        </div>
        {/* ------------------------------------ */}
      </section>
    </>
  );
}